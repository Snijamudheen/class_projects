import sys
import numpy as np
import random

# Define a class for the decision tree nodes
class Tree:
    def __init__(self, attribute = -1, threshold = -1, left = None, right = None, data = -1, gain = 0):
        self.attribute = attribute
        self.threshold = threshold
        self.left = left
        self.right = right
        self.data = data
        self.gain = gain

# Define the main decision tree function
def decision_tree(training_file, test_file, option, pruning_thr):
    # Define the Decision Tree Learning top-level function
    def DTL_TopLevel(examples, attributes):
        default = calculate_class_distribution(examples)[1]
        return DTL(examples, attributes, default)

    # Define the main Decision Tree Learning function
    def DTL(examples, attributes, default):
        if len(examples) < pruning_thr:
            return Tree(data = default) 
        
        elif 1 in calculate_class_distribution(examples):
            return Tree(data = calculate_class_distribution(examples))
        
        else:
            best_attribute, best_threshold, gain = choose_attribute(examples, attributes)
            tree = Tree(best_attribute, best_threshold, gain = gain)
            examples_left = [x for x in examples if x[best_attribute] < best_threshold]
            examples_right = [x for x in examples if x[best_attribute] >= best_threshold]
            tree.left = DTL(examples_left, attributes, calculate_class_distribution(examples))
            tree.right = DTL(examples_right, attributes, calculate_class_distribution(examples))

            return tree

    # Function to choose the best attribute for splitting the data
    def choose_attribute(examples, attributes):
        if option == "optimized":
            max_gain = best_attribute = best_threshold = -1

            for A in attributes:
                attribute_values = [x[A] for x in examples]
                L = min(attribute_values)
                M = max(attribute_values)

                for K in range(1, 51):
                    threshold = L + K * (M - L) / 51
                    gain = information_gain(examples, A, threshold)

                    if gain > max_gain:
                        max_gain = gain
                        best_attribute = A
                        best_threshold = threshold

            return (best_attribute, best_threshold, max_gain)
        
        elif option == "randomized":
            max_gain = best_threshold = -1
            A = random.choice(attributes)
            attribute_values = [x[A] for x in examples]
            L = min(attribute_values)
            M = max(attribute_values)

            for K in range(1, 51):
                threshold = L + K * (M - L) / 51
                gain = information_gain(examples, A, threshold)

                if gain > max_gain:
                    max_gain = gain
                    best_threshold = threshold

            return (A, best_threshold, max_gain)

    # Function to calculate class labels
    def calculate_classes(examples):
        classes = []
        counter = 0

        for i in range(len(examples)):
            if examples[i][-1] not in classes:
                classes.append(examples[i][-1])

        temp = dict.fromkeys(classes, 0)

        for i in sorted(temp.keys()):
            temp[i] = counter
            counter += 1

        return temp

    # Function to calculate the distribution of class labels
    def calculate_class_distribution(examples):
        distribution_array = np.zeros(len(distribution))

        for i in range(len(examples)):
            distribution_array[distribution[examples[i][-1]]] += 1

        for i in range(len(distribution_array)):
            if len(examples) > 0:
                distribution_array[i] /= len(examples)

        return distribution_array

    # Function to calculate information gain
    def information_gain(examples, attr, threshold):
        H_E = H_E1 = H_E2 = 0
        examples_left = []
        examples_right = []

        for i in examples:
            if i[attr] < threshold:
                examples_left.append(i)
            else:
                examples_right.append(i)

        dist = calculate_class_distribution(examples)
        left = calculate_class_distribution(examples_left)
        right = calculate_class_distribution(examples_right)

        for num in dist:
            if num > 0:
                H_E -= (num * np.log2(num))

        for num in left:
            if num > 0:
                H_E1 -= (num * np.log2(num))

        for num in right:
            if num > 0:
                H_E2 -= (num * np.log2(num))

        K = len(examples)
        K1 = len(examples_left)
        K2 = len(examples_right)

        final_entropy = H_E - ((K1 / K) * H_E1) - ((K2 / K) * H_E2)

        return final_entropy

    # Function to predict the class of a test instance
    def predict(tree, test_data):
        if tree.left is None and tree.right is None:
            return tree.data

        if test_data[tree.attribute] < tree.threshold:
            return predict(tree.left, test_data)
        else:
            return predict(tree.right, test_data)

    # Function to perform a breadth-first traversal of the tree
    def breadth_first_order(root, i, node_number):
        if not root:
            return

        queue = []
        queue.append((root, i, node_number))

        while queue:
            current_node, i, node_number = queue.pop(0)

            print("tree=%2d, node=%3d, feature=%2d, thr=%6.2f, gain=%f" % (i + 1, node_number, current_node.attribute, current_node.threshold, current_node.gain))

            node_number += 1

            if current_node.left:
                queue.append((current_node.left, i, node_number))
            if current_node.right:
                queue.append((current_node.right, i, node_number))

    # Function to process a file and return data as a NumPy array
    def file_process(filepath):
        array = []

        with open(filepath, 'r') as file:
            for line in file:
                line_split = line.split()
                float_line = [float(token) for token in line_split]
                array.append(float_line)
                
        return np.array(array, dtype = np.float64)

    # Check for the correct number of command line arguments
    if len(sys.argv) != 5:
        print("Error: Incorrect run command. Try: python .\decision_tree_main.py .\[path of training file] .\[path of test file] [option] [pruning_thr]")
        exit(0)

    # Parse command line arguments
    training_file = sys.argv[1]
    test_file = sys.argv[2]
    option = sys.argv[3]
    pruning_thr = int(sys.argv[4])

    # Process training and test data from files
    train_data = file_process(training_file)
    test_data = file_process(test_file)

    # Get the range of attribute indices
    attributes = range(len(train_data[0][:-1]))

    # Calculate class distribution from training data
    distribution = calculate_classes(train_data)

    # Initialize a list to store decision trees
    trees = []

    # Build decision trees based on the specified option
    if option == "optimized":
        trees.append(DTL_TopLevel(train_data, attributes))

    elif option == "1":
        option = "randomized"

        for i in range(1):
            trees.append(DTL_TopLevel(train_data, attributes))

    elif option == "3":
        option = "randomized"

        for i in range(3):
            trees.append(DTL_TopLevel(train_data, attributes))

    elif option == "15":
        option = "randomized"

        for i in range(15):
            trees.append(DTL_TopLevel(train_data, attributes))

    else:
        print("Invalid option. Enter: python .\decision_tree_main.py .\[path of training file] [option] [pruning_thr]")
        exit(0)

    # Print the structure of decision trees using breadth-first traversal
    for i in range(len(trees)):
        breadth_first_order(trees[i], i, node_number = 1)

    # Evaluate the classification accuracy on test data
    total_correct = 0

    for n in range(len(test_data)):
        accuracy = 0
        distance = []

        for i in range(len(trees)):
            distance.append(predict(trees[i], test_data[n]))  

        predicted_class_index = np.argmax(distance)
        predicted_class = predicted_class_index

        if predicted_class_index >= len(distance[0]):
            predicted_class = predicted_class_index % len(distance[0])

        if predicted_class == test_data[n][-1]:
            accuracy = 1

        total_correct += accuracy
        print("ID=%5d, predicted=%3d, true=%3d, accuracy=%4.2f" % (n + 1, predicted_class, int(test_data[n][-1]), accuracy))

    # Print the classification accuracy
    print("classification accuracy= %6.4f" % (total_correct/len(test_data)))