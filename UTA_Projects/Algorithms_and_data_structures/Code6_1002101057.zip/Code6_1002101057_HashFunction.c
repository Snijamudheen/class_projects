#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define HASHTABLESIZE 30

// Function to calculate the hash value of the given key
int MyHashFunction(char *key) 
{
    int hash = 0;

    // Loop through each character of the key and sum their ASCII values
    for (int i = 0; key[i] != '\0'; i++) 
    {
        hash += key[i];
    }

    // Calculate the index in the hash table by taking the modulo with HASHTABLESIZE
    return hash % HASHTABLESIZE;
}

int main()
{
    // Declare an array to store the input key (string)
    char HashValue[20];

    printf("Enter value: ");
    fgets(HashValue, sizeof(HashValue), stdin);

    if (HashValue[strlen(HashValue) - 1] == '\n') 
    {
        HashValue[strlen(HashValue) - 1] = '\0';
    }

    printf("The hash value for %s is %d\n", HashValue, MyHashFunction(HashValue));

    return 0;
}