# Nijamudheen, Shaheen
# 1002_101_057
# 2024_10_20
# Assignment_03_03

import numpy as np

class cl_world:
    def __init__(self, objects=[], canvases=[]):
        self.objects = objects
        self.canvases = canvases
        
        self.width = 0
        self.height = 0

        self.data = []
        self.vertex_list = []
        self.original_vertex_list = []
        self.edge_list = []
        self.translated_points = []
        self.draw_list = []
        
        self.window_dimension = [-1, -1, 1, 1]
        self.view_dimension = []
        self.viewport_dimension = []

        self.cam_info = []
        self.cam_frames = []
        self.cam_num = 0
        self.initial_camera = []
        
        self.camera_name = ''
        self.camera_type = "parallel"
        
        self.VRP = [0, 0, 0]
        self.VPN = [0, 0, 1]
        self.VUP = [0, 1, 0]
        self.PRP = [0, 0, 1]
        self.VRC = [-1, 1, -1, 1, -1, 1]

        self.viewport = [0.1, 0.1, 0.4, 0.4]
        self.parallel_mat = []

    # -------------------------SET CAMERA-----------------------------------
    
    def add_cameras(self, data, canvas):
        self.cam_info = data
        self.cam_num = len(data)
        self.width = canvas.cget("width")
        self.height = canvas.cget("height")

        # Extract view dimensions from camera data
        for camera_group in data:
            for camera in camera_group:
                if camera[0] == 's':
                    view_dims = self.extract_list_data(camera)
                    self.view_dimension.append(view_dims)

        # Create rectangles on the canvas for each view dimension
        for view_dims in self.view_dimension:
            dimensions = self.viewport_dimensions(*view_dims[:4])
            self.objects.append(canvas.create_rectangle(
                dimensions[0], dimensions[1], dimensions[2], dimensions[3],
                outline='black', fill='white'
            ))

        # Process camera data and update camera attributes
        for camera_group in data:
            first_camera_flag = False
            for camera in camera_group:
                if camera[0] == 'c':
                    first_camera_flag = True

                if first_camera_flag:
                    if camera[0] == 'i':
                        self.camera_name = camera[1]
                    elif camera[0] == 't':
                        self.camera_type = camera[1]
                    elif camera[0] == 'r':
                        self.VRP = self.extract_list_data(camera)
                    elif camera[0] == 'n':
                        self.VPN = self.extract_list_data(camera)
                    elif camera[0] == 'u':
                        self.VUP = self.extract_list_data(camera)
                    elif camera[0] == 'p':
                        self.PRP = self.extract_list_data(camera)
                    elif camera[0] == 'w':
                        self.VRC = self.extract_list_data(camera)

            # Set the first camera as the initial_camera if it hasn't been set yet
            if not self.initial_camera:
                self.initial_camera = camera_group

            # Append the appropriate projection matrix based on camera type
            if self.camera_type == 'parallel':
                self.parallel_mat.append(self.parallel_projection(0))
            else:
                self.parallel_mat.append(self.get_perparallel_mat(0))
                
    # -----------------------------ROTATION----------------------------------
                
    def rotation_matrix(self, A, B, axis, angle):
        # Convert angle to radians
        angle_rad = np.radians(angle)
        s, c = np.sin(angle_rad), np.cos(angle_rad)

        # Ensure axis is a numpy array
        axis = np.array(axis)

        # Rodrigues' rotation formula for arbitrary axis
        K = np.array([
            [0, -axis[2], axis[1]],
            [axis[2], 0, -axis[0]],
            [-axis[1], axis[0], 0]
        ])
        R = np.eye(3) + s * K + (1 - c) * np.dot(K, K)

        # Extend R to a 4x4 matrix for homogeneous coordinates
        R_homogeneous = np.eye(4)
        R_homogeneous[:3, :3] = R

        # Translation matrices to move A to origin and back
        T = np.eye(4)
        T_inv = np.eye(4)
        T[:3, 3] = -np.array(A)
        T_inv[:3, 3] = np.array(A)

        # Combine the transformations
        return T_inv.dot(R_homogeneous).dot(T)

    def apply_rotation_ui(self, axis, A, B, degree, steps, canvas):
        # Determine the rotation axis
        axis_map = {
            "X": [1, 0, 0],  # Rotate around X-axis
            "Y": [0, 1, 0],  # Rotate around Y-axis
            "Z": [0, 0, 1]   # Rotate around Z-axis
        }

        if axis in axis_map:
            N = axis_map[axis]
        elif axis == "AB":
            # Calculate the normalized direction vector N from points A and B
            N = np.array(B) - np.array(A)
            N /= np.linalg.norm(N)  # Normalize the direction vector
        else:
            print("Invalid axis")
            return

        # Perform the rotation in steps
        for step in range(1, steps + 1):
            current_degree = (degree / steps) * step
            self.rotate_vertices(A, B, N, current_degree, canvas)

    def rotate_vertices(self, A, B, axis, angle, canvas):
        # Construct the rotation matrix around the specified axis
        rotation_matrix = self.rotation_matrix(A, B, axis, angle)

        # Convert original vertices to float, apply the rotation, and store the results
        rotated_points = [np.dot(np.array([float(i) for i in vertex]), rotation_matrix).tolist() 
                        for vertex in self.original_vertex_list]

        # Update vertex lists with rotated points
        self.vertex_list = rotated_points
        self.original_vertex_list = rotated_points

        # Recalculate the projected vertices and redraw the canvas
        self.calculate_projected_vertices()
        canvas.delete("all")

        # Draw the updated vertices
        for i, element in enumerate(self.vertex_list):
            self.draw(canvas, element, self.view_dimension[i])

    # -----------------------------SCALING------------------------------------------------
    
    def scaling(self, factors, ref_point, steps, canvas):
        # Unpack scaling factors, ensuring all axes have the same factor if only one is provided
        sx, sy, sz = factors if len(factors) > 1 else (factors[0],) * 3

        # Convert reference point to float values
        ref_x, ref_y, ref_z = map(float, ref_point)

        # Translate the object to the origin using the reference point
        self.translate_vertices(-ref_x, -ref_y, -ref_z)

        # Perform the scaling operation
        self.scale_vertices(sx, sy, sz, steps, canvas)

        # Translate the object back to its original position
        self.translate_vertices(ref_x, ref_y, ref_z)

        # Clear and redraw the canvas with the updated vertex list
        canvas.delete("all")
        for i, element in enumerate(self.vertex_list):
            self.draw(canvas, element, self.view_dimension[i])

    def scale_vertices(self, sx, sy, sz, steps, canvas):
        # Initialize scaling factors and points
        scale_factors = np.array([sx, sy, sz, 1.0])
        scaled_points = np.array(self.original_vertex_list, dtype=float)

        # Calculate the per-step scaling factors
        step_scale_factors = np.power(scale_factors, 1 / steps)

        # Apply scaling in multiple steps
        for step in range(steps):
            # Scale all points for the current step
            scaled_points *= step_scale_factors

            # Update vertex lists
            self.vertex_list = scaled_points.tolist()
            self.original_vertex_list = self.vertex_list

            # Recalculate projected vertices
            self.calculate_projected_vertices()

            # Clear the canvas and redraw
            canvas.delete("all")
            for i, element in enumerate(self.vertex_list):
                self.draw(canvas, element, self.view_dimension[i])
                
    # -----------------------------TRANSLATION--------------------------------------------
    
    def translation(self, tPoints, steps, canvas):
        """
        Translates the object in steps. Each step translates by a fraction of the total amount (Dx, Dy, Dz).
        """
        # Calculate the per-step translation values
        Dx, Dy, Dz = [float(t) / steps for t in tPoints]

        # Apply the translation in multiple steps
        for step in range(steps):
            self.translate_vertices(Dx, Dy, Dz)

            # Redraw the canvas after each step
            canvas.delete("all")
            for i, element in enumerate(self.vertex_list):
                self.draw(canvas, element, self.view_dimension[i])

    def translate_vertices(self, x, y, z):
        # Create translation vector and apply it to the original vertices
        tPoints = np.array([x, y, z, 0], dtype=float)
        points = np.array(self.original_vertex_list, dtype=float)
        
        # Update vertex list with translated points
        translated_points = points + tPoints
        self.vertex_list = translated_points.tolist()

        # Update the original vertex list and recalculate the projections
        self.original_vertex_list = self.vertex_list
        self.calculate_projected_vertices()
        
    def translate_points(self, vList, vPort):
        # Translate each point in vList based on the viewport dimensions
        return [self.translate_coordinate(point[0], point[1], vPort) for point in vList]

    def translate_coordinate(self, pwx, pwy, vd):
        # Extract window and viewport dimensions
        xwmin, ywmin, xwmax, ywmax = map(float, self.window_dimension)
        nxvmin, nyvmin, nxvmax, nyvmax = map(float, vd)
        
        # Convert point coordinates to float
        pwx, pwy = float(pwx), float(pwy)

        # Get screen dimensions
        screen_width, screen_height = float(self.width), float(self.height)

        # Calculate viewport bounds on the screen
        xvmin, xvmax = nxvmin * screen_width, nxvmax * screen_width
        yvmin, yvmax = nyvmin * screen_height, nyvmax * screen_height

        # Calculate scaling factors
        sx = (xvmax - xvmin) / (xwmax - xwmin)
        sy = (yvmax - yvmin) / (ywmax - ywmin)

        # Translate the coordinates
        psx = xvmin + sx * (pwx - xwmin)
        psy = yvmin + sy * (ywmax - pwy)

        return [psx, psy]
        
    # -----------------------------PARALLEL PROJECTION------------------------------------
    
    def parallel_projection(self, flg):
        # Append homogeneous coordinate if flg is 0
        VRP = self.VRP + [1]
        VPN = self.VPN + ([1] if flg == 0 else [])
        VUP = self.VUP + ([1] if flg == 0 else [])
        PRP = self.PRP + ([1] if flg == 0 else [])
        UVN = self.VRC

        # Convert lists to numpy arrays
        VRP, VPN, VUP, PRP = map(np.array, [VRP, VPN, VUP, PRP])

        # Translation to move VRP to the origin
        tranVRP_ORJ = np.array([
            [1.0, 0.0, 0.0, -VRP[0]],
            [0.0, 1.0, 0.0, -VRP[1]],
            [0.0, 0.0, 1.0, -VRP[2]],
            [0.0, 0.0, 0.0, 1.0]
        ])
        VRP = np.dot(tranVRP_ORJ, VRP)

        # Calculate the rotation matrices to align VPN and VUP
        def create_rotation_matrix_x(VPN):
            hyp = np.hypot(VPN[1], VPN[2])
            a, b = (VPN[2] / hyp, VPN[1] / hyp) if hyp != 0 else (1, 0)
            return np.array([
                [1.0, 0.0, 0.0, 0.0],
                [0.0, a, -b, 0.0],
                [0.0, b, a, 0.0],
                [0.0, 0.0, 0.0, 1.0]
            ])

        def create_rotation_matrix_y(VPN):
            hyp = np.hypot(VPN[0], VPN[2])
            a, b = (VPN[2] / hyp, VPN[0] / hyp) if hyp != 0 else (1, 0)
            return np.array([
                [a, 0.0, -b, 0.0],
                [0.0, 1.0, 0.0, 0.0],
                [b, 0.0, a, 0.0],
                [0.0, 0.0, 0.0, 1.0]
            ])

        def create_rotation_matrix_z(VUP):
            hyp = np.hypot(VUP[0], VUP[1])
            a, b = (VUP[1] / hyp, VUP[0] / hyp) if hyp != 0 else (1, 0)
            return np.array([
                [a, -b, 0.0, 0.0],
                [b, a, 0.0, 0.0],
                [0.0, 0.0, 1.0, 0.0],
                [0.0, 0.0, 0.0, 1.0]
            ])

        # Apply the rotations to align the coordinate system
        Rx = create_rotation_matrix_x(VPN)
        Ry = create_rotation_matrix_y(np.dot(Rx, VPN))
        Rz = create_rotation_matrix_z(np.dot(Ry, VUP))

        VPN = np.dot(Ry, np.dot(Rx, VPN))
        VUP = np.dot(Rz, np.dot(Ry, np.dot(Rx, VUP)))

        # Shear matrix to adjust the view
        a = -(PRP[0] - (UVN[1] + UVN[0]) / 2) / PRP[2]
        b = -(PRP[1] - (UVN[3] + UVN[2]) / 2) / PRP[2]
        shear = np.array([[1, 0, a, 0], [0, 1, b, 0], [0, 0, 1, 0], [0, 0, 0, 1]])

        VRP = np.dot(shear, VRP)
        PRP = np.dot(shear, PRP)

        # Translation to center the view volume
        tran2 = np.array([
            [1, 0, 0, -(UVN[0] + UVN[1]) / 2],
            [0, 1, 0, -(UVN[2] + UVN[3]) / 2],
            [0, 0, 1, -min(UVN[4], UVN[5])],
            [0, 0, 0, 1]
        ])
        VRP = np.dot(tran2, VRP)
        PRP = np.dot(tran2, PRP)

        # Scaling matrix to normalize the view volume
        scale = np.array([
            [2 / abs(UVN[1] - UVN[0]), 0, 0, 0],
            [0, 2 / abs(UVN[3] - UVN[2]), 0, 0],
            [0, 0, 1 / abs(UVN[5] - UVN[4]), 0],
            [0, 0, 0, 1]
        ])

        # Combine all the transformations
        parallel_mat = np.dot(scale, np.dot(tran2, np.dot(shear, np.dot(Rz, np.dot(Ry, np.dot(Rx, tranVRP_ORJ))))))

        return parallel_mat
    
    # -----------------------------FLYING-------------------------------------------------
    
    def fly(self, canvas, point_a, point_b, steps=100):
        # Calculate step increments for each coordinate
        step_size = [(end - start) / steps for start, end in zip(point_a, point_b)]

        # Iterate over each step to update VRP incrementally
        for step in range(steps):
            # Update VRP by adding the incremental change for each step
            self.VRP = [start + step * increment for start, increment in zip(point_a, step_size)]

            # Retain other camera properties from the initial camera setup
            for camera_param in self.initial_camera:
                key, value = camera_param[0], camera_param[1:]
                if key == 'i':
                    self.camera_name = value[0]
                elif key == 't':
                    self.camera_type = value[0]
                elif key == 'n':
                    self.VPN = self.extract_list_data(camera_param)
                elif key == 'u':
                    self.VUP = self.extract_list_data(camera_param)
                elif key == 'p':
                    self.PRP = self.extract_list_data(camera_param)
                elif key == 'w':
                    self.VRC = self.extract_list_data(camera_param)

            # Update projection matrix based on camera type
            self.parallel_mat[0] = self.parallel_projection(0) if self.camera_type == 'parallel' else self.get_perparallel_mat(0)

            # Update projected vertices
            self.vertex_list = self.original_vertex_list
            self.calculate_projected_vertices()

            # Redraw the updated scene
            for i, vertex in enumerate(self.vertex_list):
                self.draw(canvas, vertex, self.view_dimension[i])

    # -----------------------------CLIPPING-----------------------------------------------
        
    def clipping(self, p1, p2):
        # Ensure only the first three coordinates (x, y, z) are used
        x1, y1, z1 = p1[:3]
        x2, y2, z2 = p2[:3]
        
        def clip_with_plane(value1, value2, min_val, max_val):
            t = None
            if value1 < min_val and value2 >= min_val:
                t = (min_val - value1) / (value2 - value1)
            elif value1 > max_val and value2 <= max_val:
                t = (max_val - value1) / (value2 - value1)
            return t

        def compute_intersection(x1, y1, z1, x2, y2, z2, t):
            x_new = x1 + t * (x2 - x1)
            y_new = y1 + t * (y2 - y1)
            z_new = z1 + t * (z2 - z1)
            return x_new, y_new, z_new

        # If both points are inside, no need for clipping
        if not self.is_outside_parallel(x1, y1, z1) and not self.is_outside_parallel(x2, y2, z2):
            return [[x1, y1, z1], [x2, y2, z2]]

        while True:
            if self.is_outside_parallel(x1, y1, z1) and self.is_outside_parallel(x2, y2, z2):
                return []  # Entire line is outside

            # For each boundary (left, right, bottom, top, near, far), clip if necessary
            t_values = []

            # Clip against right (x = 1) and left (x = -1) boundary
            t = clip_with_plane(x1, x2, -1, 1)
            if t is not None:
                t_values.append(t)

            # Clip against top (y = 1) and bottom (y = -1) boundary
            t = clip_with_plane(y1, y2, -1, 1)
            if t is not None:
                t_values.append(t)

            # Clip against far (z = 1) and near (z = 0) boundary
            t = clip_with_plane(z1, z2, 0, 1)
            if t is not None:
                t_values.append(t)

            if t_values:
                t_min = min(t_values)  # Find the smallest t to clip at
                x1, y1, z1 = compute_intersection(x1, y1, z1, x2, y2, z2, t_min)
            else:
                # If no further clipping is needed, return the clipped points
                return [[x1, y1, z1], [x2, y2, z2]]

            if not self.is_outside_parallel(x1, y1, z1) and not self.is_outside_parallel(x2, y2, z2):
                return [[x1, y1, z1], [x2, y2, z2]]
            
    def is_outside_parallel(self, x, y, z):
        # Check if the point is outside the viewing volume
        if x < -1 or x > 1 or y < -1 or y > 1 or z < 0 or z > 1:
            return True
        return False
            
    # -----------------------------HELPER FUNCTIONS---------------------------------------

    def extract_list_data(self, data_list):
        # Use list comprehension to create the return list from the second element onward
        return [float(item) for item in data_list[1:]]

    def add_canvas(self, canvas):
        # Simplify the addition of a canvas and set the world reference
        self.canvases.append(canvas)
        canvas.world = self
        
    def calculate_projected_points(self):
        # Use list comprehension to project each point and remove the last element
        self.vertex_list = [
            self.parallel_mat.dot(np.array(vertex, dtype=float))[:-1].tolist()
            for vertex in self.vertex_list
        ]

    def create_graphic_objects(self, canvas, data):
        # Clear the canvas and store the new data
        canvas.delete("all")
        self.data = data
        self.width = canvas.cget("width")
        self.height = canvas.cget("height")

        # Generate edges and vertices
        self.generate_edge_list()
        self.generate_vertex_list()

        # Draw each vertex using the corresponding view dimension
        for i, element in enumerate(self.vertex_list):
            self.draw(canvas, element, self.view_dimension[i])

    def draw(self, canvas, vList, vPort):
        # Translate points and create the drawing list
        tpoints = self.translate_points(vList, vPort)
        drawing = self.create_draw_list(vList, tpoints)

        # Get viewport dimensions
        dimension = self.viewport_dimensions(*vPort[:4])

        # Create the rectangle for the viewport and add text
        self.objects.append(canvas.create_rectangle(*dimension, outline='black', fill='white'))
        self.objects.append(canvas.create_text(dimension[0] + 5, dimension[1] + 5, anchor='nw', text="Parallel view"))

        # Draw the lines based on the draw list
        self.objects.extend(canvas.create_line(elements) for elements in drawing)

    def generate_vertex_list(self):
        # Extract vertex data, convert to float, and store it
        self.original_vertex_list = [
            [float(element[1]), float(element[2]), float(element[3]), 1.0] 
            for element in self.data if element[0] == 'v'
        ]
        self.calculate_projected_vertices()

    def calculate_projected_vertices(self):
        # Create the projected vertices using matrix multiplication
        self.vertex_list = [
            [np.dot(mat, np.array(vertex)).tolist() for vertex in self.original_vertex_list]
            for mat in self.parallel_mat
        ]

    def generate_edge_list(self):
        # Generate the edge list by filtering the elements that start with 'f'
        self.edge_list = [element for element in self.data if element[0] == 'f']

    def viewport_dimensions(self, xmin, ymin, xmax, ymax):
        # Calculate dimensions based on the viewport and canvas size
        screen_width, screen_height = float(self.width), float(self.height)
        x = xmin * screen_width
        y = ymin * screen_height
        width = (xmax - xmin) * screen_width
        height = (ymax - ymin) * screen_height
        u, v = x + width, y + height

        # Store and return the dimensions
        self.viewport_dimension = [x, y, u, v]
        return self.viewport_dimension

    def create_draw_list(self, vList, tList):
        drawing = []

        for elements in self.edge_list:
            # Remove the first element if it is 'f'
            if elements[0] == 'f':
                elements = elements[1:]

            # Loop through each vertex in the face
            for i in range(3):
                x = int(elements[i]) - 1
                y = int(elements[0]) - 1 if i == 2 else int(elements[i + 1]) - 1

                point1, point2 = tList[x], tList[y]
                p1, p2 = vList[x], vList[y]

                # Check if the line needs to be clipped
                clip = self.clipping(p1, p2)

                # Add the line segment to the draw list if it isn't clipped
                if clip:
                    drawing.append([point1[0], point1[1], point2[0], point2[1]])

        return drawing

    def refresh_display(self, canvas, event):
        if self.objects:
            # Update canvas dimensions
            self.width = float(event.width)
            self.height = float(event.height)

            # Clear the canvas
            canvas.delete("all")

            # Redraw all the vertex elements
            for i, element in enumerate(self.vertex_list):
                self.draw(canvas, element, self.view_dimension[i])

            # Draw viewport rectangles
            for vPort in self.view_dimension:
                dimension = self.viewport_dimensions(*vPort[:4])
                self.objects.append(canvas.create_rectangle(*dimension, outline='black'))

            # Draw polygons from the draw list
            for polygon in self.draw_list:
                self.objects.append(canvas.create_polygon(polygon, outline='black', fill='red'))