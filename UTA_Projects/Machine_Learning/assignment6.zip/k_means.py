# Name: Shaheen Nijamudheen
# UTA ID: 1002101057
# Run command on anaconda: python .\k_means_main.py [data_file] [K] [initialization] 

import sys
import numpy as np
import random

# Function that performs k-means
def k_means(data_file, k, initialization):
    # Opens files and parses data into an array. Optionally assigns cluster numbers using round-robin.
    def process_file(filepath, k, initialization):
        data_array = []
        with open(filepath, 'r') as file:
            cluster_number = 0
            for line in file:
                if initialization == "round_robin":
                    cluster_number += 1
                line_split = line.split()
                data_point = [float(x) for x in line_split]
                data_array.append([data_point, cluster_number]) 
                if initialization == "round_robin":
                    cluster_number = cluster_number % k
        return data_array
    
    # Open file, parse data into an array, optionally assign cluster numbers using round-robin or random
    data = process_file(data_file, k, initialization)

    if initialization == "random":
        # Initialize cluster assignments randomly
        for i in range(len(data)):
            data[i][1] = random.randint(1, k)

    same_cluster = False

    while not same_cluster:
        new_cluster = []

        # Group data based on cluster numbers
        cluster_dict = {}
        for item in data:
            if item[1] in cluster_dict:
                cluster_dict[item[1]].append(item[0])
            else:
                cluster_dict[item[1]] = [item[0]]

        # Calculate cluster means
        cluster_means = [np.mean(cluster_dict[i], axis=0) for i in range(1, k+1)]

        for i in range(len(data)):
            smallest_distance = float('inf')  # Set to a large value to ensure the smallest distance can be detected
            cluster_number = 1
            for x in range(len(cluster_means)):
                # Calculate the Euclidean distance between data point and cluster mean
                distance = np.sqrt(np.sum((data[i][0] - cluster_means[x])**2)) 
                if distance < smallest_distance:
                    cluster_number = x + 1
                    smallest_distance = distance
            new_cluster.append([data[i][0], cluster_number])

        same_cluster = True
        for i in range(len(data)):
            if data[i][1] != new_cluster[i][1]:
                same_cluster = False
                break

        data = new_cluster.copy()

    # Print the output of k-means
    for i in range(len(data)):
        if len(data[i][0]) == 1:
            print("%10.4f --> cluster %d" % (data[i][0][0], data[i][1]))
        else:
            print("(%10.4f, %10.4f) --> cluster %d" % (data[i][0][0], data[i][0][1], data[i][1]))

# Main function
if __name__ == "__main__":
    if len(sys.argv) != 4:
        print("Incorrect arguments!")
    else:
        k_means(sys.argv[1], int(sys.argv[2]), sys.argv[3])