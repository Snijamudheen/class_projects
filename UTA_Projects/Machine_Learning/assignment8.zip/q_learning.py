import numpy as np
import random

# Load the environment from the file
def load_environment(file_path):
    environment = []
    with open(file_path, 'r') as file:
        for line in file:
            row = line.strip().split(',')
            row = [cell.strip() for cell in row]  # Remove extra spaces around the cells
            environment.append(row)
    return environment

# Initialize Q-table with zeros
def initialize_q_table(environment):
    num_rows = len(environment)
    num_cols = len(environment[0])
    q_table = np.zeros((num_rows, num_cols, 4))  # Assuming there are 4 actions: up, down, left, right
    return q_table

# Simulate the SenseStateAndReward function
def sense_state_and_reward(state, environment):
    row, col = state

    if environment[row][col] == 'I':  # Check if it's the initial state
        return 0.0  # Non-terminal state reward (initial state)

    if environment[row][col] == '.' or environment[row][col] == 'X':
        return 0.0  # Non-terminal state reward for '.' or 'X'

    # Return reward for terminal states
    return float(environment[row][col])

# Function to execute an action based on the state transition model
def execute_action(current_state, action, environment):  # Add 'environment' as an argument
    row, col = current_state
    if action == 0:  # Move up
        return (row - 1, col) if row > 0 and environment[row - 1][col] != 'X' else (row, col)
    elif action == 1:  # Move down
        return (row + 1, col) if row < len(environment) - 1 and environment[row + 1][col] != 'X' else (row, col)
    elif action == 2:  # Move left
        return (row, col - 1) if col > 0 and environment[row][col - 1] != 'X' else (row, col)
    elif action == 3:  # Move right
        return (row, col + 1) if col < len(environment[0]) - 1 and environment[row][col + 1] != 'X' else (row, col)

# Calculate the utility value for a state-action pair
def calculate_utility(q_table, state, action, reward, next_state, gamma, ne):
    row, col = state
    next_row, next_col = next_state

    max_next_action = np.argmax(q_table[next_row][next_col])
    f_value = 1 if random.uniform(0, 1) < ne else q_table[row][col][action]

    q_table[row][col][action] += f_value * (reward + gamma * q_table[next_row][next_col][max_next_action] - q_table[row][col][action])

# AgentModel_Q_Learning function
def AgentModel_Q_Learning(environment_file, non_terminal_reward, gamma, number_of_moves, ne):
    # Load the environment
    environment = load_environment(environment_file)

    # Initialize Q-table
    q_table = initialize_q_table(environment)

    # Set exploration parameters
    epsilon = 1.0
    min_epsilon = 0.01
    decay_rate = 0.0005  # Adjust the decay rate as needed

    # Loop for the specified number of moves
    for move in range(number_of_moves):
        # Update epsilon for exploration-exploitation trade-off
        epsilon = max(min_epsilon, epsilon - decay_rate)

        # Randomly select an initial state
        initial_state = (random.randint(0, len(environment) - 1), random.randint(0, len(environment[0]) - 1))

        # Loop until reaching terminal state or specified limit
        while environment[initial_state[0]][initial_state[1]] != 'I':
            # Choose an action based on epsilon-greedy policy
            if random.uniform(0, 1) < epsilon:
                action = random.randint(0, 3)  # Explore: choose a random action
            else:
                action = np.argmax(q_table[initial_state[0]][initial_state[1]])  # Exploit: choose the best action

            # Sense state and get reward, passing the environment
            reward = sense_state_and_reward(initial_state, environment)

            # Execute action and get next state, passing the environment
            next_state = execute_action(initial_state, action, environment)

            # Update Q-value based on the Q-Learning formula
            calculate_utility(q_table, initial_state, action, reward, next_state, gamma, ne)

            # Move to the next state
            initial_state = next_state

    # Calculate and print utilities and optimal policy
    print_utilities_and_policy(q_table, environment)

# Utility function to print utilities and policy
def print_utilities_and_policy(q_table, environment):
    print("utilities:")
    for row in range(len(environment)):
        for col in range(len(environment[0])):
            if environment[row][col] == 'X':
                print('%6.3f' % 0, end=' ')  # Blocked state with utility 0
            else:
                max_action = np.argmax(q_table[row][col])
                print('%6.3f' % q_table[row][col][max_action], end=' ')
        print()

    print("\npolicy:")
    for row in range(len(environment)):
        for col in range(len(environment[0])):
            if environment[row][col] == 'X':
                print('%6s' % 'x', end=' ')  # Blocked state
            elif environment[row][col] == 'I':
                print('%6s' % 'o', end=' ')  # Initial state
            else:
                max_action = np.argmax(q_table[row][col])
                actions = ['^', 'v', '<', '>']
                print('%6s' % actions[max_action], end=' ')
        print()