#include <assert.h>
#include <stdio.h>
#include <stdbool.h>
#include <stdint.h>
#include <unistd.h>
#include <stdlib.h>
#include <string.h>

#define ALIGN4(s)         (((((s) - 1) >> 2) << 2) + 4)
#define BLOCK_DATA(b)     ((b) + 1)
#define BLOCK_HEADER(ptr) ((struct _block *)(ptr) - 1)

static int atexit_registered = 0;
static int num_mallocs       = 0;
static int num_frees         = 0;
static int num_reuses        = 0;
static int num_grows         = 0;
static int num_splits        = 0;
static int num_coalesces     = 0;
static int num_blocks        = 0; 
static int num_requested     = 0;
static int max_heap          = 0;


/*
 *  \brief printStatistics
 *
 *  \param none
 *
 *  Prints the heap statistics upon process exit.  Registered
 *  via atexit()
 *
 *  \return none
 */
void printStatistics( void )
{
  printf("\nheap management statistics\n");
  printf("mallocs:\t%d\n", num_mallocs );
  printf("frees:\t\t%d\n", num_frees );
  printf("reuses:\t\t%d\n", num_reuses );
  printf("grows:\t\t%d\n", num_grows );
  printf("splits:\t\t%d\n", num_splits );
  printf("coalesces:\t%d\n", num_coalesces );
  printf("blocks:\t\t%d\n", num_blocks );
  printf("requested:\t%d\n", num_requested );
  printf("max heap:\t%d\n", max_heap );
}

struct _block 
{
   size_t  size;         /* Size of the allocated _block of memory in bytes */
   struct _block *next;  /* Pointer to the next _block of allcated memory   */
   bool   free;          /* Is this _block free?                            */
   char   padding[3];    /* Padding: IENTRTMzMjAgU3ByaW5nIDIwMjM            */
};


struct _block *heapList = NULL; /* Free list to track the _blocks available */

/*
 * \brief findFreeBlock
 *
 * \param last pointer to the linked list of free _blocks
 * \param size size of the _block needed in bytes 
 *
 * \return a _block that fits the request or NULL if no free _block matches
 
 */
struct _block *findFreeBlock(struct _block **last, size_t size) 
{
   struct _block *curr = heapList;

   #if defined FIT && FIT == 0
      /* First fit */
      //
      // While we haven't run off the end of the linked list and
      // while the current node we point to isn't free or isn't big enough
      // then continue to iterate over the list.  This loop ends either
      // with curr pointing to NULL, meaning we've run to the end of the list
      // without finding a node or it ends pointing to a free node that has enough
      // space for the request.
      // 
      while (curr && !(curr->free && curr->size >= size)) 
      {
         *last = curr;
         curr  = curr->next;
      }
      return curr;
   #endif

   #if defined BEST && BEST == 0

      struct _block * best = NULL;

      //loop through all the blocks in the list
      while (curr != NULL) 
      {
         // check if the current block is free, has enough space, and is a better fit than the previous best block
         if(curr->free && curr->size >= size && (best == NULL || curr->size < best->size))
         {
            best = curr;
         }

         // update the last block pointer to the current block and move to the next block
         *last = curr;
         curr  = curr->next;
      }

      return best;
   #endif


   #if defined WORST && WORST == 0
      struct _block * worst = NULL;

      // Iterate through the linked list of memory blocks
      while (curr != NULL) 
      {
         // check if the current block is free, has enough size, and is larger than the worst block found so far
         if(curr->free && curr->size >= size && (worst == NULL || curr->size > worst->size))
         {
            // Update the worst block found to the current block
            worst = curr;
         }

         // Move the last pointer to the current block and move to the block
         *last = curr;
         curr  = curr->next;
      }

      return worst;
   #endif

   #if defined NEXT && NEXT == 0
      
      static struct _block *nextfit = NULL; // A static pointer to the last block allocated
      struct _block * start = NULL; // A temporary pointer used to store the block to start the search from
      *last = NULL; // Pointer to the last block visited

      // If no blocks have been allocated yet then set the next block to allocate to the current block
      if(nextfit == NULL)
      {
         nextfit = curr;
      }

      /* If there are already allocated blocks, set last to the current nextfit block, 
      move nextfit to the next block, Set start to the current nextfit block */
      else
      {  
         *last = nextfit;
         nextfit = nextfit->next;
         start = nextfit;

         // If nextfit is not the end of the linked list then set last to the current nextfit block
         if(nextfit != NULL)
         {
            *last = nextfit;
         }
      }

      /* Search for the next free block with sufficient size then
      set last to the current nextfit block and move nextfit to the next block */ 
      while (nextfit && !(nextfit->free && nextfit->size >= size)) 
      {
         *last = nextfit;
         nextfit = nextfit->next;
      }

      // If there was no free block found from the nextfit block to the end of the linked list
      // Set the next block to allocate to the current block
      if(start != NULL && nextfit == NULL)
      {
         nextfit = curr;

         // Search for the next free block with sufficient size starting from the current block
         // Move nextfit to the next block
         while (nextfit && !(nextfit->free && nextfit->size >= size))
         {
            nextfit = nextfit->next;
         }
      }

      return nextfit;
   #endif

   return NULL;
}

/*
 * \brief growheap
 *
 * Given a requested size of memory, use sbrk() to dynamically 
 * increase the data segment of the calling process.  Updates
 * the free list with the newly allocated memory.
 *
 * \param last tail of the free _block list
 * \param size size in bytes to request from the OS
 *
 * \return returns the newly allocated _block of NULL if failed
 */
struct _block *growHeap(struct _block *last, size_t size) 
{
   /* Request more space from OS */
   struct _block *curr = (struct _block *)sbrk(0);
   struct _block *prev = (struct _block *)sbrk(sizeof(struct _block) + size);

   assert(curr == prev);

   /* OS allocation failed */
   if (curr == (struct _block *) - 1) 
   {
      return NULL;
   }

   /* Update heapList if not set */
   if (heapList == NULL) 
   {
      heapList = curr;
   }

   /* Attach new _block to previous _block */
   else if (last) 
   {
      last->next = curr;
   }

   /* Update _block metadata:
      Set the size of the new block and initialize the new block to "free".
      Set its next pointer to NULL since it's now the tail of the linked list.
   */
   curr->size = size - sizeof(struct _block);
   curr->next = NULL;
   curr->free = true; 
   num_blocks++;

   return curr;
}

/*
 * \brief malloc
 *
 * finds a free _block of heap memory for the calling process.
 * if there is no free _block that satisfies the request then grows the 
 * heap and returns a new _block
 *
 * \param size size of the requested memory in bytes
 *
 * \return returns the requested memory allocation to the calling process 
 * or NULL if failed
 */
void *malloc(size_t size) 
{
   
   num_mallocs++;
   num_requested += size;

   if( atexit_registered == 0 )
   {
      atexit_registered = 1;
      atexit( printStatistics );
   }

   /* Align to multiple of 4 */
   size = ALIGN4(size);

   /* Handle 0 size */
   if (size == 0) 
   {
      return NULL;
   }

   struct _block *last = heapList;
   struct _block *next = findFreeBlock(&last, size);

   if(next != NULL && next->size > size + sizeof(struct _block)+4)
   {
      //Split block and put it in the free block
      num_blocks++;
      num_splits++;
      struct _block * leftover = (struct _block*)(((char*)next) + sizeof(struct _block) + size);
      leftover->size = next->size - size - sizeof(struct _block);
      next->size = size;
      leftover->free = true;
      leftover->next = next->next;
      next->next = leftover;
   }

   /* Could not find free _block, so grow heap */
   if (next == NULL) 
   {
      next = growHeap(last, size);
      num_grows++;
      max_heap += size;

   }else{

      num_reuses++;
   }

   /* Could not find free _block or grow heap, so just return NULL */
   if (next == NULL) 
   {
      return NULL;
   }
   
   /* Mark _block as in use */
   next->free = false;

   /* Return data address associated with _block to the user */
   return BLOCK_DATA(next);
}

/* frees the memory _block pointed to by pointer. if the _block is adjacent
  to another _block then coalesces (combines) them*/
 
void free(void *ptr) 
{
   // increment the number of times memory has been freed
   num_frees++;

   if (ptr == NULL) 
   {
      return;
   }

   // Get the corresponding block header from the given pointer
   // check if the block is already free
   // mark the block as free
   struct _block *curr = BLOCK_HEADER(ptr);
   assert(curr->free == 0);
   curr->free = true;
   
   struct _block* prev = heapList;

   // if the previous block pointer is not the same as the current block pointer
   if(prev != curr)
   {
      // search for the previous block in the free list
      while(prev != NULL && prev->next != curr)
      {
         prev = prev->next;
      }

      // if the previous block is not found, then print an error message
      if(prev == NULL)
      {
         printf("error: unable to find previous node in free list.\n");
      }
      
      // if the previous block is found
      else
      {
         if(prev->free)
         {
            num_blocks--;
            num_coalesces++;
            prev->size += curr->size + sizeof(struct _block);
            prev->next = curr->next;
            curr = prev;
         }
      }
   }
   
   // if the previous block pointer is the same as the current block pointer
   else
   {
      prev = NULL;
   }

   // coalesce the current block with the next block, if it is also free
   if(curr->next != NULL && curr->next->free)
   {
      num_blocks--;
      num_coalesces++;
      curr->size += curr->next->size + sizeof(struct _block);
      curr->next = curr->next->next;
   }
}

void *calloc( size_t nmemb, size_t size )
{
   // allocate memory for an array of nmemb elements, each of size bytes
   void * request = malloc(nmemb * size);

   // initialize the allocated memory to zero
   memset(request, 0, size * nmemb);

   // return the pointer to the allocated memory
   return request;
}

void *realloc( void *ptr, size_t size )
{
   // if new size is zero, free the memory and return NULL
   if(size == 0)
   {
      free(ptr);

      return NULL;
   }
   
   // if ptr is NULL, allocate new memory of given size and return its pointer
   else if(ptr == NULL)
   {
      return malloc(size);
   }

   else
   {
      struct _block *curr = BLOCK_HEADER(ptr);

      if (curr->size == size)
      {
        //size remains the same, do not change anything and return the original pointer
        return ptr;
      }

      //handle size increasing and decreasing.
      if(curr->size < size)
      {
         // we need more memory
         struct _block * newblock = (struct _block*)malloc(size);

         // copy the contents of the old memory block to the new block
         char * data = (char *)BLOCK_DATA(newblock);
         memcpy(data, ptr, curr->size);

         // free the old block of memory
         free(ptr);

         // return the pointer to the new block of memory
         return data;
      }
      
      else
      {
         if(curr->size - size > sizeof(struct _block)+4)
         {
            //Split the current block and put leftover block in the free block list
            num_blocks++;
            num_splits++;
            struct _block * leftover = (struct _block*)(((char*)curr) + sizeof(struct _block) + size);
            leftover->size = curr->size - size - sizeof(struct _block);
            curr->size = size;
            leftover->free = true;
            leftover->next = curr->next;
            curr->next = leftover;

            // return the pointer to the current block
            return curr;
         }
      }
   }

   return NULL;
}

