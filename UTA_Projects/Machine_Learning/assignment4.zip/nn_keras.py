# Name: Shaheen Nijamudheen
# UTA ID: 1002101057
# Run command on anaconda: python .\nn_keras.py [path of training file] [path of test file] [layers] [units_per_layer] [epochs]

import sys
import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.optimizers import Adam

# Function to define and train a neural network using Keras.
def nn_keras(training_file, test_file, layers, units_per_layer, epochs):
    # Read and process the training and test data, and obtain a class mapping.
    train_data, class_mapping = read_and_process_data(training_file)
    test_data, _ = read_and_process_data(test_file, class_mapping)
    
    # Normalize the data to have values between -1 and 1.
    train_data, test_data = normalize(train_data, test_data)
    
    # Determine the number of classes (K), input features (D), and hidden layer units (J).
    K, D = len(class_mapping), len(train_data[0]) - 1
    J = [units_per_layer] * layers
    J[0] = D
    J[-1] = K
    
    # Initialize target values for training data.
    t = initialize_targets(train_data, K)
    
    # Initialize weights for the neural network.
    b, w = initialize_weights(K, D, units_per_layer, layers)
    
    # Build the Keras model for the neural network.
    model = build_model(D, units_per_layer, K, layers)
    
    # Train the model with the training data for a specified number of epochs.
    train_model(model, train_data, t, epochs)
    
    # Test the model's performance on the test data.
    test_model(model, test_data)

# Function to read and process data from a file, optionally creating a class mapping.
def read_and_process_data(filepath, class_mapping=None):
    array = []
    if class_mapping is None:
        class_mapping = {}
        next_int = 0

    with open(filepath, 'r') as file:
        for line in file:
            line_split = line.split()
            temp = line_split[0:-1]
            class_label = line_split[-1]

            if class_label not in class_mapping:
                class_mapping[class_label] = next_int
                next_int += 1

            temp.append(class_mapping[class_label])
            array.append(temp)

    return np.array(array).astype(np.float64), class_mapping

# Function to normalize data to have values between -1 and 1.
def normalize(train, test):
    maximum = np.max(np.abs(train[:, :-1]))
    train[:, :-1] /= maximum
    test[:, :-1] /= maximum
    return train, test

# Function to initialize target values for training data.
def initialize_targets(train_data, K):
    t = np.zeros((len(train_data), K))
    t[np.arange(len(train_data), dtype=int), train_data[:, -1].astype(int)] = 1
    return t

# Function to initialize weights (b) for the neural network's bias terms.
def initialize_weights_b(layers, maxVal):
    b = np.zeros((layers, maxVal))
    for x in np.nditer(b, op_flags=['readwrite']):
        x[...] = np.random.uniform(-0.05, 0.05)
    return b

# Function to initialize weights (w) for the neural network's connections.
def initialize_weights_w(layers, maxVal):
    w = np.zeros((layers, maxVal, maxVal))
    for x in np.nditer(w, op_flags=['readwrite']):
        x[...] = np.random.uniform(-0.05, 0.05)
    return w

# Function to initialize weights (b and w) for the neural network's bias terms (b) and connections (w).
def initialize_weights(K, D, units_per_layer, layers):
    maxVal = max(K, D, units_per_layer)
    b = initialize_weights_b(layers, maxVal)
    w = initialize_weights_w(layers, maxVal)
    return b, w

# Function to build a Keras model for the neural network.
def build_model(D, units_per_layer, K, layers):
    model = Sequential()
    model.add(Dense(units=units_per_layer, input_dim=D, activation='sigmoid'))
    for _ in range(layers - 2):
        model.add(Dense(units=units_per_layer, activation='sigmoid'))
    model.add(Dense(units=K, activation='sigmoid'))
    model.compile(loss='categorical_crossentropy', optimizer=Adam())
    return model

# Function to train the Keras model with training data.
def train_model(model, train_data, t, epochs):
    model.fit(train_data[:, :-1], t, epochs=epochs)

# Function to test the model's performance on test data.
def test_model(model, test_data):
    total_correct = 0
    for n in range(len(test_data)):
        # Make predictions for each data point in the test data.
        predicted_probs = model.predict(np.array([test_data[n][:-1]]))[0]
        predict_class = np.argmax(predicted_probs)
        accuracy = 1 if test_data[n][-1] == predict_class else 0
        total_correct += accuracy
        object_id = n + 1
        predicted_class = predict_class
        true_class = int(test_data[n][-1])
        
        # Print the results for each data point.
        print('ID=%5d, predicted=%10s, true=%10s, accuracy=%4.2f' % (object_id, predicted_class, true_class, accuracy))
    
    # Calculate and print the classification accuracy.
    classification_accuracy = total_correct / len(test_data)
    print("classification accuracy=%6.4f" % classification_accuracy)

# Check if the command-line arguments are provided in the correct format.
if len(sys.argv) != 6:
    print("Error: Incorrect format!\nThe run command is: python3 nn_keras.py [path of training file] [path of test file] [layers] [units_per_layer] [rounds]")
else:
    # Parse command-line arguments.
    training_file = sys.argv[1]
    test_file = sys.argv[2]
    layers = int(sys.argv[3])
    units_per_layer = int(sys.argv[4])
    epochs = int(sys.argv[5])