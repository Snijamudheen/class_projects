# Nijamudheen, Shaheen
# 1002_101_057
# 2024_11_10
# Assignment_04_03

import numpy as np

class cl_world:
    def __init__(self, objects=[], canvases=[]):
        self.objects = objects
        self.canvases = canvases
        
        self.width = 0
        self.height = 0

        self.data = []
        self.vertex_list = []
        self.original_vertex_list = []
        self.edge_list = []
        self.translated_points = []
        self.draw_list = []
        
        self.window_dimension = [-1, -1, 1, 1]
        self.view_dimension = []
        self.viewport_dimension = []

        self.cam_info = []
        self.cam_frames = []
        self.cam_num = 0
        self.initial_camera = []
        self.camera = {}
        
        self.camera_name = ''
        self.camera_type = "parallel"
        
        self.VRP = [0, 0, 0]
        self.VPN = [0, 0, 1]
        self.VUP = [0, 1, 0]
        self.PRP = [0, 0, 1]
        self.VRC = [-1, 1, -1, 1, -1, 1]

        self.viewport = [0.1, 0.1, 0.4, 0.4]
        self.parallel_mat = []
        self.projMat = None
    
    def add_cameras(self, data, canvas):
        self.cam_info = data
        self.cam_num = len(data)
        self.width = canvas.cget("width")
        self.height = canvas.cget("height")

        titles = ["front", "side", "top", "perspective_1", "perspective_2"]
        self.viewport_titles = {}

        for i, camera_group in enumerate(data):
            for camera in camera_group:
                if camera[0] == 's':
                    view_dims = self.extract_list_data(camera)
                    self.view_dimension.append(view_dims)
                    self.viewport_titles[i] = titles[i] if i < len(titles) else "Viewport"
                    self.draw(canvas, vList=[], vPort=view_dims, view_name=self.viewport_titles[i])

        for camera_group in data:
            first_camera_flag = False
            for camera in camera_group:
                if camera[0] == 'c':
                    first_camera_flag = True

                if first_camera_flag:
                    if camera[0] == 'i':
                        self.camera_name = camera[1]
                    elif camera[0] == 't':
                        self.camera_type = camera[1]
                    elif camera[0] == 'r':
                        self.VRP = self.extract_list_data(camera)
                    elif camera[0] == 'n':
                        self.VPN = self.extract_list_data(camera)
                    elif camera[0] == 'u':
                        self.VUP = self.extract_list_data(camera)
                    elif camera[0] == 'p':
                        self.PRP = self.extract_list_data(camera)
                    elif camera[0] == 'w':
                        self.VRC = self.extract_list_data(camera)

            if not self.initial_camera:
                self.initial_camera = camera_group

            # Apply the appropriate projection matrix
            if self.camera_type == 'parallel':
                camera_data = {
                    "view_volume": self.VRC,  
                    "VRP": self.VRP,
                    "VPN": self.VPN,
                    "VUP": self.VUP,
                    "PRP": self.PRP
                }
                self.parallel_mat.append(self.parallel_projection(camera_data))
            else:
                camera_data = {
                    "view_volume": self.VRC,  
                    "VRP": self.VRP,
                    "VPN": self.VPN,
                    "VUP": self.VUP,
                    "PRP": self.PRP
                }
                self.parallel_mat.append(self.perspective_projection(camera_data))

                
    def parallel_projection(self, camera):
        umin, umax, vmin, vmax, nmin, nmax = camera["view_volume"]
        
        # Ensure all vectors have four components
        VRP = np.append(camera["VRP"], [1]) if len(camera["VRP"]) == 3 else np.array(camera["VRP"])
        VPN = np.append(camera["VPN"], [1]) if len(camera["VPN"]) == 3 else np.array(camera["VPN"])
        VUP = np.append(camera["VUP"], [1]) if len(camera["VUP"]) == 3 else np.array(camera["VUP"])
        PRP = np.append(camera["PRP"], [1]) if len(camera["PRP"]) == 3 else np.array(camera["PRP"])

        # Translate VRP to origin
        T1 = np.array([
            [1, 0, 0, -VRP[0]],
            [0, 1, 0, -VRP[1]],
            [0, 0, 1, -VRP[2]],
            [0, 0, 0, 1]
        ])

        # Rx: rotate around x-axis to bring VPN to xz plane
        a, b, c, w = np.ravel(VPN)
        temp_denom = np.sqrt(b * b + c * c)
        if temp_denom == 0:  # if b and c are zero, no rotation is needed
            Rx = np.eye(4)
        else:
            Rx = np.array([
                [1, 0, 0, 0],
                [0, c / temp_denom, -b / temp_denom, 0],
                [0, b / temp_denom, c / temp_denom, 0],
                [0, 0, 0, 1]
            ])
        
        # Ry: rotate around y-axis to align VPN with z-axis
        VPNpp = Rx @ VPN
        a, b, c, w = np.ravel(VPNpp)
        temp_denom = np.sqrt(a * a + c * c)
        if temp_denom == 0:
            Ry = np.eye(4)
        else:
            Ry = np.array([
                [c / temp_denom, 0, -a / temp_denom, 0],
                [0, 1, 0, 0],
                [a / temp_denom, 0, c / temp_denom, 0],
                [0, 0, 0, 1]
            ])

        # Rz: rotate around z axis to adjust the "up" direction (VUP)
        VUPpp = Rx @ VUP
        VUPppp = Ry @ VUPpp
        a, b, c, w = np.ravel(VUPppp)
        temp_denom = np.sqrt(a * a + b * b)
        if temp_denom == 0:
            Rz = np.eye(4)
        else:
            Rz = np.array([
                [b / temp_denom, -a / temp_denom, 0, 0],
                [a / temp_denom, b / temp_denom, 0, 0],
                [0, 0, 1, 0],
                [0, 0, 0, 1]
            ])

        # Shear: to align the Direction of Projection (DOP) with the z-axis
        shx = -(PRP[0] - (umin + umax) / 2) / PRP[2]
        shy = -(PRP[1] - (vmin + vmax) / 2) / PRP[2]
        Sh = np.array([
            [1, 0, shx, 0],
            [0, 1, shy, 0],
            [0, 0, 1, 0],
            [0, 0, 0, 1]
        ])

        # Translate: center of window on front plane to origin
        T2 = np.array([
            [1, 0, 0, -(umin + umax) / 2],
            [0, 1, 0, -(vmin + vmax) / 2],
            [0, 0, 1, -nmin],
            [0, 0, 0, 1]
        ])

        # Scale to achieve canonical view volume
        sx = 2 / (umax - umin)
        sy = 2 / (vmax - vmin)
        sz = 1 / (nmax - nmin)
        S = np.array([
            [sx, 0, 0, 0],
            [0, sy, 0, 0],
            [0, 0, sz, 0],
            [0, 0, 0, 1]
        ])

        # Composite matrix
        composite_matrix = S @ T2 @ Sh @ Rz @ Ry @ Rx @ T1
        return composite_matrix

    def perspective_projection(self, camera):
        umin, umax, vmin, vmax, nmin, nmax = camera["view_volume"]
        VRP, VPN, VUP, PRP = camera["VRP"], camera["VPN"], camera["VUP"], camera["PRP"]

        # Ensure all vectors are 4D by appending a 1 if they are 3D
        if len(VRP) == 3:
            VRP = np.append(VRP, 1)
        if len(VPN) == 3:
            VPN = np.append(VPN, 1)
        if len(VUP) == 3:
            VUP = np.append(VUP, 1)
        if len(PRP) == 3:
            PRP = np.append(PRP, 1)

        # translate VRP to origin
        T1 = np.array([
            [1, 0, 0, -VRP[0]],
            [0, 1, 0, -VRP[1]],
            [0, 0, 1, -VRP[2]],
            [0, 0, 0, 1]
        ])

        # Rx: rotate around x-axis to bring VPN to xz plane
        a, b, c, _ = np.ravel(VPN)
        temp_denom = np.sqrt(b * b + c * c)
        if temp_denom == 0:
            Rx = np.eye(4)
        else:
            Rx = np.array([
                [1, 0, 0, 0],
                [0, c / temp_denom, -b / temp_denom, 0],
                [0, b / temp_denom, c / temp_denom, 0],
                [0, 0, 0, 1]
            ])

        # Ry: rotate around y-axis to align VPN with z-axis
        VPNpp = Rx @ VPN
        a, b, c, _ = np.ravel(VPNpp)
        temp_denom = np.sqrt(a * a + c * c)
        if temp_denom == 0:
            Ry = np.eye(4)
        else:
            Ry = np.array([
                [c / temp_denom, 0, -a / temp_denom, 0],
                [0, 1, 0, 0],
                [a / temp_denom, 0, c / temp_denom, 0],
                [0, 0, 0, 1]
            ])

        # Rz: rotate around z-axis to adjust the "up" direction (VUP)
        VUPpp = Ry @ Rx @ VUP
        a, b, c, _ = np.ravel(VUPpp)
        temp_denom = np.sqrt(a * a + b * b)
        if temp_denom == 0:
            Rz = np.eye(4)
        else:
            Rz = np.array([
                [b / temp_denom, -a / temp_denom, 0, 0],
                [a / temp_denom, b / temp_denom, 0, 0],
                [0, 0, 1, 0],
                [0, 0, 0, 1]
            ])

        # translate PRP
        T2 = np.array([
            [1, 0, 0, -PRP[0]],
            [0, 1, 0, -PRP[1]],
            [0, 0, 1, -PRP[2]],
            [0, 0, 0, 1]
        ])

        # shear such that the center line of the view volume becomes the z axis
        shx = -(PRP[0] - (umin + umax) / 2) / PRP[2]
        shy = -(PRP[1] - (vmin + vmax) / 2) / PRP[2]
        Sh = np.array([
            [1, 0, shx, 0],
            [0, 1, shy, 0],
            [0, 0, 1, 0],
            [0, 0, 0, 1]
        ])

        # scale 1: scale such that the sides of the view volume become 45 degrees relative to z-axis
        sx1 = abs(PRP[2]) / ((umax - umin) / 2)
        sy1 = abs(PRP[2]) / ((vmax - vmin) / 2)
        S1 = np.array([
            [sx1, 0, 0, 0],
            [0, sy1, 0, 0],
            [0, 0, 1, 0],
            [0, 0, 0, 1]
        ])

        # scale 2: scale such that the view volume becomes canonical perspective volume
        sx2 = 1 / (-PRP[2] + nmax)
        sy2 = 1 / (-PRP[2] + nmax)
        sz2 = 1 / (-PRP[2] + nmax)
        S2 = np.array([
            [sx2, 0, 0, 0],
            [0, sy2, 0, 0],
            [0, 0, sz2, 0],
            [0, 0, 0, 1]
        ])

        # calculate zmin
        zmin = ((-PRP[2] + nmin) / (-PRP[2] + nmax))
        camera["zmin"] = zmin

        # Final composite matrix for perspective projection
        composite_matrix = S2 @ S1 @ Sh @ T2 @ Rz @ Ry @ Rx @ T1
        return composite_matrix

    def get_projectedpoints(self):
        temp = []
        for element in self.original_vertex_list:
            # Convert to homogeneous coordinate
            element = np.array(element + [1], dtype=float)
            # Apply perspective transformation
            pPoint = self.projMat.dot(element)
            # Normalize by w
            pPoint = pPoint / pPoint[3] if pPoint[3] != 0 else pPoint
            # Store projected 2D points
            temp.append(pPoint[:2].tolist())  # Use only x and y for 2D projection
        self.vertex_list = temp

        
    def rotation_matrix(self, A, B, axis, angle):
        # Convert angle to radians
        angle_rad = np.radians(angle)
        s, c = np.sin(angle_rad), np.cos(angle_rad)

        # Ensure axis is a numpy array
        axis = np.array(axis)

        # Rodrigues' rotation formula for arbitrary axis
        K = np.array([
            [0, -axis[2], axis[1]],
            [axis[2], 0, -axis[0]],
            [-axis[1], axis[0], 0]
        ])
        R = np.eye(3) + s * K + (1 - c) * np.dot(K, K)

        # Extend R to a 4x4 matrix for homogeneous coordinates
        R_homogeneous = np.eye(4)
        R_homogeneous[:3, :3] = R

        # Translation matrices to move A to origin and back
        T = np.eye(4)
        T_inv = np.eye(4)
        T[:3, 3] = -np.array(A)
        T_inv[:3, 3] = np.array(A)

        # Combine the transformations
        return T_inv.dot(R_homogeneous).dot(T)

    def apply_rotation_ui(self, axis, A, B, degree, steps, canvas):
        # Determine the rotation axis
        axis_map = {
            "X": [1, 0, 0],  # Rotate around X-axis
            "Y": [0, 1, 0],  # Rotate around Y-axis
            "Z": [0, 0, 1]   # Rotate around Z-axis
        }

        if axis in axis_map:
            N = axis_map[axis]
        elif axis == "AB":
            # Calculate the normalized direction vector N from points A and B
            N = np.array(B) - np.array(A)
            N /= np.linalg.norm(N)  # Normalize the direction vector
        else:
            print("Invalid axis")
            return

        # Perform the rotation in steps
        for step in range(1, steps + 1):
            current_degree = (degree / steps) * step
            self.rotate_vertices(A, B, N, current_degree, canvas)

    def rotate_vertices(self, A, B, axis, angle, canvas):
        # Construct the rotation matrix around the specified axis
        rotation_matrix = self.rotation_matrix(A, B, axis, angle)

        # Convert original vertices to float, apply the rotation, and store the results
        rotated_points = [np.dot(np.array([float(i) for i in vertex]), rotation_matrix).tolist() 
                        for vertex in self.original_vertex_list]

        # Update vertex lists with rotated points
        self.vertex_list = rotated_points
        self.original_vertex_list = rotated_points

        # Recalculate the projected vertices and redraw the canvas
        self.calculate_projected_vertices()
        canvas.delete("all")

        # Draw the updated vertices
        for i, element in enumerate(self.vertex_list):
            self.draw(canvas, element, self.view_dimension[i])

    def scaling(self, factors, ref_point, steps, canvas):
        # Unpack scaling factors, ensuring all axes have the same factor if only one is provided
        sx, sy, sz = factors if len(factors) > 1 else (factors[0],) * 3

        # Convert reference point to float values
        ref_x, ref_y, ref_z = map(float, ref_point)

        # Translate the object to the origin using the reference point
        self.translate_vertices(-ref_x, -ref_y, -ref_z)

        # Perform the scaling operation
        self.scale_vertices(sx, sy, sz, steps, canvas)

        # Translate the object back to its original position
        self.translate_vertices(ref_x, ref_y, ref_z)

        # Clear and redraw the canvas with the updated vertex list
        canvas.delete("all")
        for i, element in enumerate(self.vertex_list):
            self.draw(canvas, element, self.view_dimension[i])

    def scale_vertices(self, sx, sy, sz, steps, canvas):
        # Initialize scaling factors and points
        scale_factors = np.array([sx, sy, sz, 1.0])
        scaled_points = np.array(self.original_vertex_list, dtype=float)

        # Calculate the per-step scaling factors
        step_scale_factors = np.power(scale_factors, 1 / steps)

        # Apply scaling in multiple steps
        for step in range(steps):
            # Scale all points for the current step
            scaled_points *= step_scale_factors

            # Update vertex lists
            self.vertex_list = scaled_points.tolist()
            self.original_vertex_list = self.vertex_list

            # Recalculate projected vertices
            self.calculate_projected_vertices()

            # Clear the canvas and redraw
            canvas.delete("all")
            for i, element in enumerate(self.vertex_list):
                self.draw(canvas, element, self.view_dimension[i])

    def translation(self, tPoints, steps, canvas):
        """
        Translates the object in steps. Each step translates by a fraction of the total amount (Dx, Dy, Dz).
        """
        # Calculate the per-step translation values
        Dx, Dy, Dz = [float(t) / steps for t in tPoints]

        # Apply the translation in multiple steps
        for step in range(steps):
            self.translate_vertices(Dx, Dy, Dz)

            # Redraw the canvas after each step
            canvas.delete("all")
            for i, element in enumerate(self.vertex_list):
                self.draw(canvas, element, self.view_dimension[i])

    def translate_vertices(self, x, y, z):
        # Create translation vector and apply it to the original vertices
        tPoints = np.array([x, y, z, 0], dtype=float)
        points = np.array(self.original_vertex_list, dtype=float)
        
        # Update vertex list with translated points
        translated_points = points + tPoints
        self.vertex_list = translated_points.tolist()

        # Update the original vertex list and recalculate the projections
        self.original_vertex_list = self.vertex_list
        self.calculate_projected_vertices()
        
    def translate_points(self, vList, vPort):
        # Translate each point in vList based on the viewport dimensions
        return [self.translate_coordinate(point[0], point[1], vPort) for point in vList]

    def translate_coordinate(self, pwx, pwy, vd):
        # Extract window and viewport dimensions
        xwmin, ywmin, xwmax, ywmax = map(float, self.window_dimension)
        nxvmin, nyvmin, nxvmax, nyvmax = map(float, vd)
        
        # Convert point coordinates to float
        pwx, pwy = float(pwx), float(pwy)

        # Get screen dimensions
        screen_width, screen_height = float(self.width), float(self.height)

        # Calculate viewport bounds on the screen
        xvmin, xvmax = nxvmin * screen_width, nxvmax * screen_width
        yvmin, yvmax = nyvmin * screen_height, nyvmax * screen_height

        # Calculate scaling factors
        sx = (xvmax - xvmin) / (xwmax - xwmin)
        sy = (yvmax - yvmin) / (ywmax - ywmin)

        # Translate the coordinates
        psx = xvmin + sx * (pwx - xwmin)
        psy = yvmin + sy * (ywmax - pwy)

        return [psx, psy]

    def fly(self, canvas, point_a, point_b, steps=100, selected_view=""):
        # Calculate the incremental step for VRP movement
        step_size = [(end - start) / steps for start, end in zip(point_a, point_b)]
        
        # Identify the selected view index
        selected_view_index = None
        for i, camera_params in enumerate(self.cam_info):
            for param in camera_params:
                if param[0] == 'i' and param[1] == selected_view:
                    selected_view_index = i
                    break
            if selected_view_index is not None:
                break

        if selected_view_index is None:
            print("Selected view not found.")
            return

        # Main loop for 'flying' the camera
        for step in range(steps):
            # Update VRP based on the step
            self.VRP = [start + step * increment for start, increment in zip(point_a, step_size)]
            
            # Update camera parameters based on the selected view
            for camera_param in self.cam_info[selected_view_index]:
                key, value = camera_param[0], camera_param[1:]
                if key == 't':
                    self.camera_type = value[0]
                elif key == 'n':
                    self.VPN = self.extract_list_data(camera_param)
                elif key == 'u':
                    self.VUP = self.extract_list_data(camera_param)
                elif key == 'p':
                    self.PRP = self.extract_list_data(camera_param)
                elif key == 'w':
                    self.VRC = self.extract_list_data(camera_param)

            # Prepare the camera data dictionary
            camera_data = {
                "view_volume": self.VRC,
                "VRP": self.VRP,
                "VPN": self.VPN,
                "VUP": self.VUP,
                "PRP": self.PRP
            }

            # Update the projection matrix for the selected view
            self.parallel_mat[selected_view_index] = (
                self.parallel_projection(camera_data) if self.camera_type == 'parallel'
                else self.perspective_projection(camera_data)
            )

            # Recalculate projected vertices
            self.calculate_projected_vertices()

            # Clear and redraw the selected view only
            canvas.delete("all")
            view_name = self.viewport_titles[selected_view_index]
            dimension = self.viewport_dimensions(*self.view_dimension[selected_view_index][:4])
            canvas.create_rectangle(*dimension, outline='black', fill='white')
            self.draw(canvas, self.vertex_list[selected_view_index], self.view_dimension[selected_view_index], view_name=view_name)

            # Draw other views without updating vertices (to maintain their position)
            for i, vPort in enumerate(self.view_dimension):
                if i != selected_view_index:
                    self.draw(canvas, self.vertex_list[i], vPort, view_name=self.viewport_titles[i])

            # Update the display for each step
            canvas.update_idletasks()
            
    def clipping(self, p1, p2, perspective=False, zmin=0.1):
        # Unpack the points
        x1, y1, z1 = p1[:3]
        x2, y2, z2 = p2[:3]
        
        def clip_with_plane(value1, value2, min_val, max_val):
            t = None
            if value1 < min_val and value2 >= min_val:
                t = (min_val - value1) / (value2 - value1)
            elif value1 > max_val and value2 <= max_val:
                t = (max_val - value1) / (value2 - value1)
            return t

        def compute_intersection(x1, y1, z1, x2, y2, z2, t):
            x_new = x1 + t * (x2 - x1)
            y_new = y1 + t * (y2 - y1)
            z_new = z1 + t * (z2 - z1)
            return x_new, y_new, z_new

        def is_inside_parallel(x, y, z):
            return -1 <= x <= 1 and -1 <= y <= 1 and 0 <= z <= 1

        def is_inside_perspective(x, y, z):
            return -z <= x <= z and -z <= y <= z and zmin <= z <= 1

        # Check if both points are inside the volume (no clipping needed)
        if (not perspective and is_inside_parallel(x1, y1, z1) and is_inside_parallel(x2, y2, z2)) or \
        (perspective and is_inside_perspective(x1, y1, z1) and is_inside_perspective(x2, y2, z2)):
            return [[x1, y1, z1], [x2, y2, z2]]
        
        while True:
            if (not perspective and not is_inside_parallel(x1, y1, z1) and not is_inside_parallel(x2, y2, z2)) or \
            (perspective and not is_inside_perspective(x1, y1, z1) and not is_inside_perspective(x2, y2, z2)):
                return []  # Entire line is outside
            
            t_values = []
            
            # Clip against parallel or perspective volume boundaries
            if not perspective:
                # Parallel volume clipping boundaries
                t = clip_with_plane(x1, x2, -1, 1)
                if t is not None: t_values.append(t)
                t = clip_with_plane(y1, y2, -1, 1)
                if t is not None: t_values.append(t)
                t = clip_with_plane(z1, z2, 0, 1)
                if t is not None: t_values.append(t)
            else:
                # Perspective volume clipping boundaries
                t = clip_with_plane(x1, x2, -z1, z1)
                if t is not None: t_values.append(t)
                t = clip_with_plane(y1, y2, -z1, z1)
                if t is not None: t_values.append(t)
                t = clip_with_plane(z1, z2, zmin, 1)
                if t is not None: t_values.append(t)

            if t_values:
                t_min = min(t_values)  # Find the smallest t to clip at
                x1, y1, z1 = compute_intersection(x1, y1, z1, x2, y2, z2, t_min)
            else:
                return [[x1, y1, z1], [x2, y2, z2]]  # Return clipped points if within bounds

            # If both points are within bounds after clipping
            if (not perspective and is_inside_parallel(x1, y1, z1) and is_inside_parallel(x2, y2, z2)) or \
            (perspective and is_inside_perspective(x1, y1, z1) and is_inside_perspective(x2, y2, z2)):
                return [[x1, y1, z1], [x2, y2, z2]]

            # Perspective projection step: divide x and y by z after clipping
            if perspective:
                return [[x1 / z1, y1 / z1, z1], [x2 / z2, y2 / z2, z2]]
            else:
                return [[x1, y1, z1], [x2, y2, z2]]
            
    def is_outside_parallel(self, x, y, z):
        # Check if the point is outside the viewing volume
        if x < -1 or x > 1 or y < -1 or y > 1 or z < 0 or z > 1:
            return True
        return False

    def extract_list_data(self, data_list):
        # Use list comprehension to create the return list from the second element onward
        return [float(item) for item in data_list[1:]]

    def add_canvas(self, canvas):
        # Simplify the addition of a canvas and set the world reference
        self.canvases.append(canvas)
        canvas.world = self
        
    def calculate_projected_vertices(self):
        # Create the projected vertices using matrix multiplication
        self.vertex_list = [
            [np.dot(mat, np.array(vertex)).tolist() for vertex in self.original_vertex_list]
            for mat in self.parallel_mat
        ]

    def create_graphic_objects(self, canvas, data):
        # Clear the canvas and store the new data
        canvas.delete("all")
        self.data = data
        self.width = canvas.cget("width")
        self.height = canvas.cget("height")

        # Generate edges and vertices
        self.generate_edge_list()
        self.generate_vertex_list()

        # Draw each vertex using the corresponding view dimension
        for i, element in enumerate(self.vertex_list):
            self.draw(canvas, element, self.view_dimension[i])

    def draw(self, canvas, vList, vPort, view_name=""):
        # Translate points and create the drawing list
        tpoints = self.translate_points(vList, vPort)
        drawing = self.create_draw_list(vList, tpoints)
        
        # Get viewport dimensions
        dimension = self.viewport_dimensions(*vPort[:4])

        # Create the rectangle for the viewport
        self.objects.append(canvas.create_rectangle(*dimension, outline='black', fill='white'))

        # Add static text for the viewport title
        self.objects.append(canvas.create_text(
            dimension[0] + 5, dimension[1] + 5, anchor='nw', text=view_name
        ))

        # Draw the lines based on the draw list
        self.objects.extend(canvas.create_line(elements) for elements in drawing)


    def generate_vertex_list(self):
        # Extract vertex data, convert to float, and store it in original_vertex_list
        self.original_vertex_list = [
            [float(element[1]), float(element[2]), float(element[3]), 1.0] 
            for element in self.data if element[0] == 'v'
        ]
        # Calculate the projected vertices based on the initial data
        self.calculate_projected_vertices()


    def calculate_projected_vertices(self):
        # Create the projected vertices using matrix multiplication
        self.vertex_list = [
            [np.dot(mat, np.array(vertex)).tolist() for vertex in self.original_vertex_list]
            for mat in self.parallel_mat
        ]

    def generate_edge_list(self):
        # Generate the edge list by filtering the elements that start with 'f'
        self.edge_list = [element for element in self.data if element[0] == 'f']


    def viewport_dimensions(self, xmin, ymin, xmax, ymax):
        # Calculate dimensions based on the viewport and canvas size
        screen_width, screen_height = float(self.width), float(self.height)
        x = xmin * screen_width
        y = ymin * screen_height
        width = (xmax - xmin) * screen_width
        height = (ymax - ymin) * screen_height
        u, v = x + width, y + height

        # Store and return the dimensions
        self.viewport_dimension = [x, y, u, v]
        return self.viewport_dimension

    def create_draw_list(self, vList, tList):
        drawing = []

        for elements in self.edge_list:
            # Remove the first element if it is 'f'
            if elements[0] == 'f':
                elements = elements[1:]

            # Loop through each vertex in the face
            for i in range(3):
                x = int(elements[i]) - 1
                y = int(elements[0]) - 1 if i == 2 else int(elements[i + 1]) - 1

                point1, point2 = tList[x], tList[y]
                p1, p2 = vList[x], vList[y]

                # Check if the line needs to be clipped
                clip = self.clipping(p1, p2)

                # Add the line segment to the draw list if it isn't clipped
                if clip:
                    drawing.append([point1[0], point1[1], point2[0], point2[1]])

        return drawing

    def refresh_display(self, canvas, event):
        if self.objects:
            # Update canvas dimensions
            self.width = float(event.width)
            self.height = float(event.height)

            # Clear the canvas
            canvas.delete("all")

            # Redraw all the vertex elements
            for i, element in enumerate(self.vertex_list):
                self.draw(canvas, element, self.view_dimension[i])

            # Draw viewport rectangles
            for vPort in self.view_dimension:
                dimension = self.viewport_dimensions(*vPort[:4])
                self.objects.append(canvas.create_rectangle(*dimension, outline='black'))

            # Draw polygons from the draw list
            for polygon in self.draw_list:
                self.objects.append(canvas.create_polygon(polygon, outline='black', fill='red'))