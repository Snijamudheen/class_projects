// The MIT License (MIT)
// 
// Copyright (c) 2016 Trevor Bakker 
// 
// Permission is hereby granted, free of charge, to any person obtaining a copy
// of this software and associated documentation files (the "Software"), to deal
// in the Software without restriction, including without limitation the rights
// to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
// copies of the Software, and to permit persons to whom the Software is
// furnished to do so, subject to the following conditions:
// 
// The above copyright notice and this permission notice shall be included in
// all copies or substantial portions of the Software.
// 
// 
// THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
// IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
// FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
// AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
// LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
// THE SOFTWARE.

#define _GNU_SOURCE

#include <stdio.h>
#include <unistd.h>
#include <sys/wait.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <signal.h>

#define WHITESPACE " \t\n"      // We want to split our command line up into tokens
                                // so we need to define what delimits our tokens.
                                // In this case  white space
                                // will separate the tokens on our command line

#define MAX_COMMAND_SIZE 255    // The maximum command-line size

#define MAX_NUM_ARGUMENTS 5     // Mav shell only supports four arguments

//creating a linked list to store history variables and pointers
struct history{

  char *command;
  struct history *next;
  struct history *prev;
  pid_t pid; 

};


int main(){

  struct history *hist = NULL;
  char *command_string = ( char* ) malloc( MAX_COMMAND_SIZE );

  while(1){

    // Print out the msh prompt
    printf( "msh> " );

    // Read the command from the commandline.  The
    // maximum command that will be read is MAX_COMMAND_SIZE
    // This while command will wait here until the user
    // inputs something since fgets returns NULL when there
    // is no input
    while( !fgets ( command_string, MAX_COMMAND_SIZE, stdin ) );

    //trimming off the spaces and index as needed 
    while( strlen ( command_string ) > 0 && ( command_string[strlen(command_string) - 1] == ' ' || 
        command_string[strlen( command_string ) - 1] == '\n' ||
        command_string[strlen( command_string ) - 1] == '\t' ||
        command_string[strlen( command_string ) - 1] == '\r' ) ){

        command_string[strlen( command_string ) - 1] = '\0';

    }
    
    if( strlen(command_string) == 0 ){
      continue;
    }
    
    //prints history if !n is entered
    if( command_string[0] == '!' ){

      char *index = &(command_string[1]);
      int cmd = atoi(index);
      struct history* temp = hist;
      int counter = 1;
        
        while( temp != NULL && temp -> next != NULL && counter < 15 ){
          temp = temp -> next;
          counter++;
        }

        counter = 0;

        while( temp != NULL && counter < cmd ){
          counter++;
          temp = temp -> prev;
        }

        if(temp == NULL || cmd < 0){
          printf( "Command not in history.\n" );
          continue;
        }
        
        strcpy(command_string, temp -> command);
    }

    //putting the commands in history
    struct history *hist2 = (struct history*) malloc(sizeof(struct history));
    hist2 -> next = hist; 
    hist2 -> command = strdup(command_string);
    hist2 -> prev = NULL;
    hist2 -> pid = -1;
    
    //pointing at the new head of the linked list
    if( hist != NULL ){
      hist -> prev = hist2;
    }

    hist = hist2;
    
    //leaves the shell if user entered exit or quit by breaking out of the while loop
    if( strcmp(command_string, "quit") == 0 || strcmp(command_string, "exit") == 0) {
      break;
    }
    
    //checking if the entered command is history 
    if( strcmp(command_string, "history") == 0 || strcmp(command_string, "history -p") == 0 ){
      int showpid = 0;
            
      if( strcmp(command_string, "history -p") == 0 ){
        showpid = 1;
      }
      
      //pointer to walk through the history
      struct history *temp = hist;

      //if there is no history, it prints this message
      if( temp == NULL ){
        printf( "No history\n" );
      }
      
      //If there is history
      else{

        //integer to keep count the number of commands in history
        int counter = 1;

        //If there is a command present, it points to the next node and counts upto 15 commands 
        while( temp -> next != NULL && counter < 15){
          temp = temp -> next;
          counter++;
        }

        counter = 0;
        
        //printing history along with its pid in reverse order
        while( temp != NULL ){

          printf( "%2d: ", counter );
          counter++;

          if( showpid ){
          printf( "[%ld] ", (long)temp -> pid );
          }

          printf( "%s\n", temp -> command );
          temp = temp -> prev;

        }
      }
      continue;

    }

    //checking if command starts with cd
    if( strncmp(command_string, "cd ", 3) == 0 ){
      
      //location of the character after the space in "cd "
      char *dir = &(command_string[3]);

      //incase of error
      if( chdir(dir) == -1 ){
        printf( "Chdir failed\n" );
      }
      continue;

    }

    /* Parse input */
    char *token[MAX_NUM_ARGUMENTS];

    for( int i = 0; i < MAX_NUM_ARGUMENTS; i++ )
    {
      token[i] = NULL;
    }

    int token_count = 0;                                 
                                                           
    // Pointer to point to the token
    // parsed by strsep
    char *argument_ptr = NULL;                                         
                                                           
    char *working_string  = strdup( command_string );                

    // we are going to move the working_string pointer so
    // keep track of its original value so we can deallocate
    // the correct amount at the end
    char *head_ptr = working_string;

    // Tokenize the input strings with whitespace used as the delimiter
    while ( ( (argument_ptr = strsep(&working_string, WHITESPACE ) ) != NULL) && (token_count<MAX_NUM_ARGUMENTS)){

      token[token_count] = strndup( argument_ptr, MAX_COMMAND_SIZE );
      if( strlen( token[token_count] ) == 0 )
      {
        token[token_count] = NULL;
      }
        token_count++;
    }

    //creating a process named pid using fork
    pid_t pid = fork();

    //in the child process
    if( pid == 0 ){

      //takes arguments as individual strings in an array
      execvp( token[0], token );

      _exit(1);
    }
    
    //in the parent process
    else if( pid > 0 ){

      hist -> pid = pid;

      //declare an integer to store the status of the child
      int status;

      //waiting on specific child 
      waitpid(pid, &status, 0);

      //printing the exit status of the child
      if( WIFEXITED(status) ){

        int exit_status = WEXITSTATUS(status);

        if(exit_status == 1){
          fprintf( stdout, "%s: Command not found.\n", token[0] );
        }
        
      }
    }

    // Cleanup allocated memory
    for( int i = 0; i < MAX_NUM_ARGUMENTS; i++ )
    {
      if( token[i] != NULL )
      {
        free( token[i] );
      }
    }

    free( head_ptr );

  }

  free( command_string );
 
  //creating a pointer named temp to point to the node that needs to be freed
  struct history* temp;

  //As long as hist(the first node of the linked list) is not NULL, there is a node to be freed
  while( hist != NULL ){
      temp = hist;
      hist = hist -> next;
      free( temp -> command );
      free( temp );
  }

  return 0;
  // e2520ca2-76f3-90d6-0242ac120003
}
