import sys

# Initialize empty lists for training and test data
training_data = []
test_data = []

# Define the main function for the Naive Bayes classifier
def naive_bayes(training_file, test_file):
    # Load data from the provided training and test files
    load_data(training_file)
    load_data(test_file)

    # Calculate class-specific statistics from the training data
    data_info = calculate_class(training_data)

    # Perform the training phase using the calculated statistics
    training_phase(data_info)

    # Calculate and store predictions for the test data
    predictions = calculate_predictions(data_info, test_data)

    # Calculate and display classification accuracy based on predictions
    calculate_classification_accuracy(test_data, predictions)

# Function to display class-specific mean and standard deviation statistics
def training_phase(data_info):
    for label in sorted(data_info.keys()):
        for i, (mean, std, _) in enumerate(data_info[label]):
            print(f"class {label}, attribute {i + 1}, mean = {mean:.2f}, std = {std:.2f}")

# Function to load data from a file into the appropriate data list (training or test)
def load_data(filepath):
    list_data = []

    with open(filepath, "r") as file:
        for line in file:
            data_row = [float(value) for value in line.split()]
            list_data.append(data_row)

    if "training" in filepath:
        training_data.extend(list_data)
    else:
        test_data.extend(list_data)

# Function to calculate class-specific statistics from the training data
def calculate_class(data):
    class_dict = {}  
    for values in data:
        class_label = values[-1]
        if class_label not in class_dict:
            class_dict[class_label] = []
        class_dict[class_label].append(values[:-1])  

    information = {}  
    for class_label, attributes in class_dict.items():
        # Calculate mean, standard deviation, and count for each attribute
        attribute_information = [(calculate_mean(attr), calculate_stdev(attr), len(attr)) for attr in zip(*attributes)]
        information[class_label] = attribute_information

    return information

# Function to calculate the probability of a value using the Gaussian distribution
def gaussian_formula(num, mean, stdev):
    exponent = (-(((num - mean) ** 2) / (2 * (stdev ** 2))))
    probability = (1 / (stdev * (1.77245385091))) * (2.718281828459045 ** exponent)
    return probability

# Function to calculate predictions for the test data
def calculate_predictions(information, test_set):
    predictions = []

    for value in test_set:
        label_probability = calculate_class_probabilities(information, value)

        high_label = None       
        high_probability = 0    
        count = 0          

        for class_label, probability in label_probability.items():
            if high_label is None or probability > high_probability:
                high_probability = probability
                high_label = class_label
                count = 0
            elif probability == high_probability:
                count += 1

        predictions.append([high_label, high_probability, count])

    return predictions

# Function to calculate the conditional probabilities of classes given attributes
def calculate_class_probabilities(information, row):
    p_Ck_given_x = {}
    p_Ck = {}
    p_x = 0
    total_rows = len(training_data)

    for class_label, class_information in information.items():
        p_x_given_Ck = 1
        p_Ck[class_label] = class_information[0][2] / float(total_rows)
        for i in range(len(class_information)):
            p_x_given_Ck *= gaussian_formula(row[i], class_information[i][0], class_information[i][1])

        p_Ck_given_x[class_label] = p_x_given_Ck * p_Ck[class_label]
        p_x += p_Ck_given_x[class_label]

    # Normalize probabilities to ensure they sum up to 1
    for class_label in p_Ck_given_x:
        p_Ck_given_x[class_label] /= p_x

    return p_Ck_given_x

# Function to calculate and display classification accuracy
def calculate_classification_accuracy(test_set, predictions):
    correct = 0 
    total = len(test_set)  
    for i, (true_label, (high_label, high_probability, count)) in enumerate(zip(test_set, predictions), start=1):
        if true_label[-1] == high_label:
            accuracy = 1.0 if count == 0 else 1.0 / count
            accuracy_str = f"accuracy= {accuracy:.2f}"
            correct += 1
        else:
            accuracy_str = "accuracy= 0.00"

        print(f"ID= {i:5d}, predicted= {int(high_label)}, probability= {high_probability:.4f}, true= {int(true_label[-1])}, {accuracy_str}")

    accuracy = correct / total
    print(f"classification accuracy is {accuracy:.4f}")

# Function to calculate the mean of a list of numbers
def calculate_mean(numbers):
    return sum(numbers) / len(numbers)

# Function to calculate the standard deviation of a list of numbers
def calculate_stdev(numbers):
    sum_squared_deviation = 0
    mean = calculate_mean(numbers)
    count = len(numbers)

    for number in numbers:
        deviation = float(number) - mean
        sum_squared_deviation += deviation ** 2

    variance = sum_squared_deviation / (count - 1)
    stdev = variance ** 0.5

    # Apply a minimum threshold to standard deviation to prevent division by zero
    min_threshold = 0.01
    if stdev < min_threshold:
        stdev = min_threshold

    return stdev

# Entry point of the script
if __name__ == "__main__":
    if len(sys.argv) != 3:
        print("Error: Incorrect usage!")
        sys.exit(1)
    else:
        args = sys.argv
        training_file = args[1]
        test_file = args[2]

        # Call the main Naive Bayes function with the provided file paths
        naive_bayes(training_file, test_file)