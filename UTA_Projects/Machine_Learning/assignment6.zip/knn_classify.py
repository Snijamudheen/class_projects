# Name: Shaheen Nijamudheen
# UTA ID: 1002101057
# Run command on anaconda: python .\knn_classify_main.py .\[path of training file] .\[path of test file] [k]

import sys
import numpy as np

# Function to perform k-Nearest Neighbors classification
def knn_classify(training_file_path, test_file_path, k):
    # Load training and test data from files
    training_file = np.loadtxt(training_file_path, dtype=float)
    test_file = np.loadtxt(test_file_path, dtype=float)

    # Separate features and labels
    train_data = training_file[:, :-1]  # Extract features from training data
    test_data = test_file[:, :-1]  # Extract features from test data
    train_labels = training_file[:, -1].astype(int)  # Extract labels from training data

    # Standardize training and test data
    mean = np.mean(train_data, axis=0)  # Calculate mean for each feature
    std = np.std(train_data, axis=0, ddof=1)  # Calculate standard deviation for each feature
    std[std == 0] = 1  # Avoid division by zero
    train_data = (train_data - mean) / std  # Standardize training data
    test_data = (test_data - mean) / std  # Standardize test data

    correct_predictions = 0  # Initialize a counter for correct predictions

    for i, test_instance in enumerate(test_data):
        # Calculate Euclidean distances between the test instance and training instances
        distances = np.sum((train_data - test_instance) ** 2, axis=1)
        sorted_indices = np.argsort(distances)
        k_nearest_labels = train_labels[sorted_indices[:k]]  # Get labels of the k-nearest neighbors

        # Count occurrences of each label in the k-nearest neighbors
        unique_labels, label_counts = np.unique(k_nearest_labels, return_counts=True)
        max_count = np.max(label_counts)
        max_count_classes = unique_labels[label_counts == max_count]

        if len(max_count_classes) == 1:
            # If one class has the maximum count, predict that class
            predicted_class = max_count_classes[0]
            accuracy = 1.0 if predicted_class == test_file[i, -1].astype(int) else 0.0
        else:
            # If multiple classes have the same maximum count, choose one randomly
            accuracy = 1.0 / len(max_count_classes) if test_file[i, -1].astype(int) in max_count_classes else 0.0
            predicted_class = np.random.choice(max_count_classes)

        correct_predictions += accuracy

        # Print prediction details for the current test instance
        print("ID=%5d, predicted=%3d, true=%3d, accuracy=%4.2f" % (i + 1, int(predicted_class), int(test_file[i, -1]), accuracy))

    # Calculate classification accuracy
    classification_accuracy = correct_predictions / len(test_data)
    print('classification accuracy=%6.4f' % classification_accuracy)

# Check if command-line arguments are provided
if len(sys.argv) < 4:
    print("Not enough arguments")
    sys.exit(0)

train_file_path = sys.argv[1]  # Get the path to the training data file
test_file_path = sys.argv[2]  # Get the path to the test data file
k = int(sys.argv[3])  # Get the value of k for k-Nearest Neighbors