/* Name: Shaheen Nijamudheen */
/* ID: 1002101057 */
/* Coding Assignment 4 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void ReadFileIntoArray(int argc, char *argv[], int **AP, int **number)
{
    FILE *myFile;
    char file_name[100];
    char file_char[100];
    char *token;
    int sum = 0;
    
    // Check if the correct number of command line arguments is provided
    if (argc >= 2)
    {
        strcpy(file_name, argv[1]);      // Copy the file name from command line argument
        myFile = fopen(file_name, "r");  // Open the file for reading

        if(myFile == NULL)
        {
            printf("Failed to open the file.\n");
            exit(1);
        }
    }
    else
    {
        printf("File must be provied on command line...exiting\n");
        exit(1);
    }

    // Count the number of lines in the file
    while (fgets(file_char, sizeof(file_char) - 1, myFile))
    {
        sum++; 
    }

    **number = sum;                     // Store the number of lines in this sum pointer
    *AP = malloc(sum* sizeof(int));     // Allocate memory for the array based on the number of lines
    fseek(myFile, 0, SEEK_SET);             // Move the file pointer to the beginning of the file
    
    int i = 0;
    
    // Read each line from the file and convert it to an integer
    while (fgets(file_char, sizeof(file_char) - 1, myFile))
    {   
        token = strtok(file_char, " ");      // Split the line by spaces
        (*AP)[i] = atoi(file_char);          // Convert the token to an integer and store it in the array
        i++;
    }

    fclose(myFile);
}

void swap(int *SwapA, int *SwapB)
{
    int temp = *SwapA;
    *SwapA = *SwapB;
    *SwapB = temp;
}

int partition(int A[], int low, int high)
{
    int i, j = 0;

    #if QSM
    int middle = (high + low) / 2;
    swap(&A[middle], &A[high]);
    #elif QSRND
    int random = (rand() % (high - low + 1)) + low;
    swap(&A[random], &A[high]);
    #endif

    int pivot = A[high];

    i = (low - 1);

    for (j = low; j < high; j++)
    {
        if (A[j] < pivot)
        {
            i++;
            swap(&A[i], &A[j]);
        }
    }
    swap(&A[i + 1], &A[high]);

    return (i + 1);
}

void QuickSort(int A[], int low, int high)
{
    if (low < high)
    {
        int ndx = partition(A, low, high);

        QuickSort(A, low, ndx - 1);
        QuickSort(A, ndx + 1, high);
    }
}

void PrintArray(int ArrayToPrint[], int SizeAP)
{
    int i;

    for (i = 0; i < SizeAP; i++)
        printf("%d\n", ArrayToPrint[i]);  
}

int main(int argc, char *argv[])
{
    clock_t quick_start, quick_end;
    int *TempPtr = NULL;     // Temporary pointer to store the dynamically allocated array
    int elements = 0;
    int *elements_ptr = &elements;
    long int timer;
    long int total_runtime = 0;
    int i;
    int sum = 0;
    long int average = 0;
 
    // Check if the number of runs is specified on the command line
    if (argc < 3)
    {
        printf("Number of runs not specified on command line...defaulting to 10");
        sum = 10;
    }
    else
    {
        sum = atoi(argv[2]);
    }

    // Perform the specified number of runs
    for (i = 0; i < sum; i++)
    {  
        // Read file data into the array
        ReadFileIntoArray(argc, argv, &TempPtr, &elements_ptr);

        // Print the array before merge sort
        #ifdef PRINTARRAY
        PrintArray(TempPtr, elements);
        printf("\n");
        #endif

        // Capture the clock in a start time, then perform merge sort and finally record the end time
        quick_start = clock();
        QuickSort(TempPtr, 0, elements - 1);
        quick_end = clock();

        // Calculate the run time
        timer = quick_end - quick_start;

        printf("\nRun %d complete : %ld tics", (i + 1), timer);
        
        total_runtime += (timer);
        average = total_runtime / sum;

        // Print the array after merge sort
        #ifdef PRINTARRAY
        PrintArray(TempPtr, elements);
        printf("\n");
        #endif

        // Free the dynamically allocated memory for the array
        free(TempPtr);
    }
    
    printf("\nThe average run time for %d runs is %ld\n\n", sum, average);
    printf("\nProcessed %d records\n", elements);

    return 0;
}