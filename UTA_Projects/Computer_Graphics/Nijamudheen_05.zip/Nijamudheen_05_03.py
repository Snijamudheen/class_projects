# Nijamudheen, Shaheen
# 1002_101_057
# 2024_11_24
# Assignment_05_03

import numpy as np

class cl_world:
    def __init__(self, objects=[], canvases=[]):
        self.objects = objects
        self.canvases = canvases
        self.data = []
        self.vertex_list = []
        self.original_vertex_list = []
        self.edge_list = []
        self.window_dimension = [-1, -1, 1, 1]
        self.view_dimension = []
        self.translated_points = []
        self.draw_list = []
        self.width = 0
        self.height = 0
        self.viewport_dimensions = []

        self.camera_data = []
        self.camera_frames = []
        self.camera_num = 0
        self.initial_camera = []

        self.camera_name = ''
        self.camera_type = "parallel"
        self.VRP = [0, 0, 0]
        self.VPN = [0, 0, 1]
        self.VUP = [0, 1, 0]
        self.PRP = [0, 0, 1]
        self.VRC = [-1, 1, -1, 1, -1, 1]
        self.viewport = [0.1, 0.1, 0.4, 0.4]
        self.projection_matrix = []

        self.bezier_list = []
        self.bezier_points = []
        self.result = 0
        self.edge_connections = []
        self.bezier_control_points = []

    def add_cameras(self, data, canvas):
        self.camera_data = data
        self.camera_num = len(data)
        temp = []
        for element1 in data:
            for element2 in element1:
                if element2[0] == 's':
                    temp = self.extract_list(element2)
                    self.view_dimension.append(temp)
        self.width = canvas.cget("width")
        self.height = canvas.cget("height")

        for elements in self.view_dimension:
            a = elements
            dimension = self.translate_viewport(a[0], a[1], a[2], a[3])
            self.objects.append(canvas.create_rectangle(dimension[0], dimension[1], dimension[2], dimension[3], outline='black', fill='white'))

        for elem in data:
            flg = 0
            for element in elem:
                if element[0] == 'c':
                    flg += 1

                if flg == 1:
                    if element[0] == 'i':
                        self.camera_name = element[1]
                    elif element[0] == 't':
                        self.camera_type = element[1]
                    elif element[0] == 'r':
                        self.VRP = self.extract_list(element)
                    elif element[0] == 'n':
                        self.VPN = self.extract_list(element)
                    elif element[0] == 'u':
                        self.VUP = self.extract_list(element)
                    elif element[0] == 'p':
                        self.PRP = self.extract_list(element)
                    elif element[0] == 'w':
                        self.VRC = self.extract_list(element)

            if not self.initial_camera:
                self.initial_camera = elem

            camera_data = {
                "view_volume": self.VRC,
                "VRP": self.VRP,
                "VPN": self.VPN,
                "VUP": self.VUP,
                "PRP": self.PRP
            }

            if self.camera_type == "parallel":
                matTemp = self.parallel_projection(camera_data)
            elif self.camera_type == "perspective":
                matTemp = self.perspective_projection(camera_data)

            self.projection_matrix.append(matTemp)

    def fly_camera(self, canvas, point):
        for element in self.initial_camera:
            if element[0] == 'i':
                self.camera_name = element[1]
            elif element[0] == 't':
                self.camera_type = element[1]
            elif element[0] == 'r':
                self.VRP = point
            elif element[0] == 'n':
                self.VPN = self.extract_list(element)
            elif element[0] == 'u':
                self.VUP = self.extract_list(element)
            elif element[0] == 'p':
                self.PRP = self.extract_list(element)
            elif element[0] == 'w':
                self.VRC = self.extract_list(element)

        if self.camera_type == 'parallel':
            matTemp = self.parallel_projection(0)
        else:
            matTemp = self.perspective_projection(0)

        self.projection_matrix[0] = matTemp
        self.vertex_list = self.original_vertex_list
        self.generate_projected_vertices()
        i = 0
        for element in self.vertex_list:
            self.draw(canvas, element, self.view_dimension[i])
            i = i + 1
                    
    def fly(self, canvas, point_a, point_b, steps=100, selected_view=""):
        # Calculate the incremental step for VRP movement
        step_size = [(end - start) / steps for start, end in zip(point_a, point_b)]

        # Identify the selected view index
        selected_view_index = None
        for i, camera_params in enumerate(self.camera_data):
            for param in camera_params:
                if param[0] == 'i' and param[1] == selected_view:
                    selected_view_index = i
                    break
            if selected_view_index is not None:
                break

        if selected_view_index is None:
            print(f"Selected view '{selected_view}' not found.")
            return

        # Main loop for 'flying' the camera
        for step in range(steps):
            # Update VRP based on the step
            self.VRP = [start + step * increment for start, increment in zip(point_a, step_size)]

            # Update camera parameters for the selected view
            for camera_param in self.camera_data[selected_view_index]:
                key, value = camera_param[0], camera_param[1:]
                if key == 't':
                    self.camera_type = value[0]
                elif key == 'n':
                    self.VPN = self.extract_list(camera_param)
                elif key == 'u':
                    self.VUP = self.extract_list(camera_param)
                elif key == 'p':
                    self.PRP = self.extract_list(camera_param)
                elif key == 'w':
                    self.VRC = self.extract_list(camera_param)

            # Prepare the camera data dictionary for projection
            camera_data = {
                "view_volume": self.VRC,
                "VRP": self.VRP,
                "VPN": self.VPN,
                "VUP": self.VUP,
                "PRP": self.PRP
            }

            # Update the projection matrix for the selected view
            if self.camera_type == "parallel":
                self.projection_matrix[selected_view_index] = self.parallel_projection(camera_data)
            elif self.camera_type == "perspective":
                self.projection_matrix[selected_view_index] = self.perspective_projection(camera_data)

            # Recalculate projected vertices
            self.generate_projected_vertices()

            # Clear and redraw only the selected view
            canvas.delete("all")
            dimension = self.translate_viewport(*self.view_dimension[selected_view_index][:4])
            canvas.create_rectangle(*dimension, outline="black", fill="white")
            self.draw(canvas, self.vertex_list[selected_view_index], self.view_dimension[selected_view_index])

            # Draw other views without recalculating vertices (to maintain their position)
            for i, vPort in enumerate(self.view_dimension):
                if i != selected_view_index:
                    self.draw(canvas, self.vertex_list[i], vPort)

            # Update the display for the current step
            canvas.update_idletasks()

    def extract_list(self, input_list):
        return [float(item) for item in input_list[1:]]
        
    def parallel_projection(self, camera):
        umin, umax, vmin, vmax, nmin, nmax = camera["view_volume"]

        # Ensure all vectors have four components
        VRP = np.append(camera["VRP"], [1]) if len(camera["VRP"]) == 3 else np.array(camera["VRP"])
        VPN = np.append(camera["VPN"], [1]) if len(camera["VPN"]) == 3 else np.array(camera["VPN"])
        VUP = np.append(camera["VUP"], [1]) if len(camera["VUP"]) == 3 else np.array(camera["VUP"])
        PRP = np.append(camera["PRP"], [1]) if len(camera["PRP"]) == 3 else np.array(camera["PRP"])

        # Translate VRP to origin
        T1 = np.array([
            [1, 0, 0, -VRP[0]],
            [0, 1, 0, -VRP[1]],
            [0, 0, 1, -VRP[2]],
            [0, 0, 0, 1]
        ])

        # Rx: rotate around x-axis to bring VPN to xz plane
        a, b, c, w = np.ravel(VPN)
        temp_denom = np.sqrt(b * b + c * c)
        Rx = np.eye(4) if temp_denom == 0 else np.array([
            [1, 0, 0, 0],
            [0, c / temp_denom, -b / temp_denom, 0],
            [0, b / temp_denom, c / temp_denom, 0],
            [0, 0, 0, 1]
        ])

        # Ry: rotate around y-axis to align VPN with z-axis
        VPNpp = Rx @ VPN
        a, b, c, w = np.ravel(VPNpp)
        temp_denom = np.sqrt(a * a + c * c)
        Ry = np.eye(4) if temp_denom == 0 else np.array([
            [c / temp_denom, 0, -a / temp_denom, 0],
            [0, 1, 0, 0],
            [a / temp_denom, 0, c / temp_denom, 0],
            [0, 0, 0, 1]
        ])

        # Rz: rotate around z axis to adjust the "up" direction (VUP)
        VUPpp = Rx @ VUP
        VUPppp = Ry @ VUPpp
        a, b, c, w = np.ravel(VUPppp)
        temp_denom = np.sqrt(a * a + b * b)
        Rz = np.eye(4) if temp_denom == 0 else np.array([
            [b / temp_denom, -a / temp_denom, 0, 0],
            [a / temp_denom, b / temp_denom, 0, 0],
            [0, 0, 1, 0],
            [0, 0, 0, 1]
        ])

        # Shear: to align the Direction of Projection (DOP) with the z-axis
        shx = -(PRP[0] - (umin + umax) / 2) / PRP[2]
        shy = -(PRP[1] - (vmin + vmax) / 2) / PRP[2]
        Sh = np.array([
            [1, 0, shx, 0],
            [0, 1, shy, 0],
            [0, 0, 1, 0],
            [0, 0, 0, 1]
        ])

        # Translate: center of window on front plane to origin
        T2 = np.array([
            [1, 0, 0, -(umin + umax) / 2],
            [0, 1, 0, -(vmin + vmax) / 2],
            [0, 0, 1, -nmin],
            [0, 0, 0, 1]
        ])

        # Scale to achieve canonical view volume
        sx = 2 / (umax - umin)
        sy = 2 / (vmax - vmin)
        sz = 1 / (nmax - nmin)
        S = np.array([
            [sx, 0, 0, 0],
            [0, sy, 0, 0],
            [0, 0, sz, 0],
            [0, 0, 0, 1]
        ])

        # Composite matrix
        composite_matrix = S @ T2 @ Sh @ Rz @ Ry @ Rx @ T1
        return composite_matrix

    def perspective_projection(self, camera):
        umin, umax, vmin, vmax, nmin, nmax = camera["view_volume"]
        VRP, VPN, VUP, PRP = camera["VRP"], camera["VPN"], camera["VUP"], camera["PRP"]

        # Ensure all vectors are 4D by appending a 1 if they are 3D
        if len(VRP) == 3:
            VRP = np.append(VRP, 1)
        if len(VPN) == 3:
            VPN = np.append(VPN, 1)
        if len(VUP) == 3:
            VUP = np.append(VUP, 1)
        if len(PRP) == 3:
            PRP = np.append(PRP, 1)

        # translate VRP to origin
        T1 = np.array([
            [1, 0, 0, -VRP[0]],
            [0, 1, 0, -VRP[1]],
            [0, 0, 1, -VRP[2]],
            [0, 0, 0, 1]
        ])

        # Rx: rotate around x-axis to bring VPN to xz plane
        a, b, c, _ = np.ravel(VPN)
        temp_denom = np.sqrt(b * b + c * c)
        if temp_denom == 0:
            Rx = np.eye(4)
        else:
            Rx = np.array([
                [1, 0, 0, 0],
                [0, c / temp_denom, -b / temp_denom, 0],
                [0, b / temp_denom, c / temp_denom, 0],
                [0, 0, 0, 1]
            ])

        # Ry: rotate around y-axis to align VPN with z-axis
        VPNpp = Rx @ VPN
        a, b, c, _ = np.ravel(VPNpp)
        temp_denom = np.sqrt(a * a + c * c)
        if temp_denom == 0:
            Ry = np.eye(4)
        else:
            Ry = np.array([
                [c / temp_denom, 0, -a / temp_denom, 0],
                [0, 1, 0, 0],
                [a / temp_denom, 0, c / temp_denom, 0],
                [0, 0, 0, 1]
            ])

        # Rz: rotate around z-axis to adjust the "up" direction (VUP)
        VUPpp = Ry @ Rx @ VUP
        a, b, c, _ = np.ravel(VUPpp)
        temp_denom = np.sqrt(a * a + b * b)
        if temp_denom == 0:
            Rz = np.eye(4)
        else:
            Rz = np.array([
                [b / temp_denom, -a / temp_denom, 0, 0],
                [a / temp_denom, b / temp_denom, 0, 0],
                [0, 0, 1, 0],
                [0, 0, 0, 1]
            ])

        # translate PRP
        T2 = np.array([
            [1, 0, 0, -PRP[0]],
            [0, 1, 0, -PRP[1]],
            [0, 0, 1, -PRP[2]],
            [0, 0, 0, 1]
        ])

        # shear such that the center line of the view volume becomes the z axis
        shx = -(PRP[0] - (umin + umax) / 2) / PRP[2]
        shy = -(PRP[1] - (vmin + vmax) / 2) / PRP[2]
        Sh = np.array([
            [1, 0, shx, 0],
            [0, 1, shy, 0],
            [0, 0, 1, 0],
            [0, 0, 0, 1]
        ])

        # scale 1: scale such that the sides of the view volume become 45 degrees relative to z-axis
        sx1 = abs(PRP[2]) / ((umax - umin) / 2)
        sy1 = abs(PRP[2]) / ((vmax - vmin) / 2)
        S1 = np.array([
            [sx1, 0, 0, 0],
            [0, sy1, 0, 0],
            [0, 0, 1, 0],
            [0, 0, 0, 1]
        ])

        # scale 2: scale such that the view volume becomes canonical perspective volume
        sx2 = 1 / (-PRP[2] + nmax)
        sy2 = 1 / (-PRP[2] + nmax)
        sz2 = 1 / (-PRP[2] + nmax)
        S2 = np.array([
            [sx2, 0, 0, 0],
            [0, sy2, 0, 0],
            [0, 0, sz2, 0],
            [0, 0, 0, 1]
        ])

        # calculate zmin
        zmin = ((-PRP[2] + nmin) / (-PRP[2] + nmax))
        camera["zmin"] = zmin

        # Final composite matrix for perspective projection
        composite_matrix = S2 @ S1 @ Sh @ T2 @ Rz @ Ry @ Rx @ T1
        return composite_matrix

    def projected_points(self):
        self.vertex_list = [
            self.projection_matrix.dot(np.array(element, dtype=float))[:-1].tolist()
            for element in self.vertex_list
        ]

    def add_canvas(self, canvas):
        self.canvases.append(canvas)
        canvas.world = self

    def translation(self, tPoints, steps, canvas):
        """
        Applies translation transformation to the object.
        """
        # Compute step-wise translation increments for x, y, z
        step_increments = [t / steps for t in tPoints]

        # Perform translation step-by-step
        for _ in range(steps):
            # Compute the translation vector for the current step
            translation_vector = np.array(step_increments + [0], dtype=float)  # Translation vector in homogeneous coordinates

            # Apply the translation to the vertex list
            self.original_vertex_list = (np.array(self.original_vertex_list, dtype=float) + translation_vector).tolist()
            self.vertex_list = self.original_vertex_list.copy()

        # Refresh the display
        self.generate_projected_vertices()
        canvas.delete("all")

        # Draw the translated object on the canvas
        for i, element in enumerate(self.vertex_list):
            self.draw(canvas, element, self.view_dimension[i])

    def draw_translation(self, x, y, z):
        """
        Applies a translation transformation directly to the object.
        """
        # Create the translation vector in homogeneous coordinates
        translation_vector = np.array([x, y, z, 0], dtype=float)

        # Apply the translation to the original vertex list
        translated_points = np.array(self.original_vertex_list, dtype=float) + translation_vector

        # Update vertex lists with the translated points
        self.original_vertex_list = translated_points.tolist()
        self.vertex_list = self.original_vertex_list.copy()

        # Recalculate projected vertices
        self.generate_projected_vertices()

    def scaling(self, scale_factors, ref_point, steps, canvas):
        """
        Applies a scaling transformation to the object.
        """
        # Extract scale factors and reference point
        sx, sy, sz = scale_factors
        rx, ry, rz = ref_point

        # Perform scaling transformation step by step
        for _ in range(steps):
            # Translate to origin
            self.draw_translation(-rx, -ry, -rz)

            # Apply scaling
            scale_matrix = np.array([sx, sy, sz, 1], dtype=float)  # Scaling factors for x, y, z
            scaled_points = np.array(self.original_vertex_list, dtype=float) * scale_matrix

            # Update the vertex lists with the scaled points
            self.original_vertex_list = scaled_points.tolist()
            self.vertex_list = self.original_vertex_list.copy()

            # Translate back to the reference point
            self.draw_translation(rx, ry, rz)

        # Refresh the display
        self.generate_projected_vertices()
        canvas.delete("all")
        for i, element in enumerate(self.vertex_list):
            self.draw(canvas, element, self.view_dimension[i])

    def draw_scaling(self, factor, canvas):
        self.vertex_list = []
        Scalepoints = np.array(self.original_vertex_list, dtype=float)
        sFactor = np.array([factor, factor, factor, 1])
        translatedPoints = Scalepoints * sFactor
        self.original_vertex_list = translatedPoints.tolist()
        self.vertex_list = self.original_vertex_list
        self.generate_projected_vertices()
        i = 0
        for element in self.vertex_list:
            self.draw(canvas, element, self.view_dimension[i])
            i = i + 1

    def Rotate(self, A, B, line, angle, canvas):
        tempList = []
        rotatedPoints = []

        Mat = self.compute_rotation_matrix(A, B, angle)

        for element in self.original_vertex_list:
            element = [float(i) for i in element]
            tempList.append(element)

        for element in tempList:
            element = np.array(element)
            element = element.dot(Mat)
            temp = element
            temp = temp.tolist()
            rotatedPoints.append(temp)

        self.vertex_list = []
        self.vertex_list = rotatedPoints
        self.original_vertex_list = rotatedPoints
        self.generate_projected_vertices()
        canvas.delete("all")
        i = 0
        for element in self.vertex_list:
            self.draw(canvas, element, self.view_dimension[i])
            i = i + 1

    def apply_rotation_ui(self, selected_axis, A, B, angle, steps, canvas):
        """
        Rotates objects in the world based on the selected axis or line AB.
        Updates the canvas after rotation.
        """
        step_angle = angle / steps  # Divide angle into steps
        for step in range(steps):
            if selected_axis in ['X', 'Y', 'Z']:
                # Rotate around a single axis
                axis = [1, 0, 0] if selected_axis == 'X' else [0, 1, 0] if selected_axis == 'Y' else [0, 0, 1]
                self.rotate_around_axis(axis, step_angle)
            elif selected_axis == 'AB':
                # Rotate around a custom line defined by A and B
                self.rotate_around_line(A, B, step_angle)
            else:
                raise ValueError("Invalid rotation axis selected.")

        # Refresh canvas after applying rotation
        canvas.delete("all")
        self.refresh_display(canvas, None)

    def rotate_around_axis(self, axis, angle):
        """
        Rotates all vertices around a specified axis by a given angle.
        """
        angle_rad = np.radians(angle)
        rotation_matrix = np.eye(4)

        if axis == [1, 0, 0]:  # X-axis
            rotation_matrix = np.array([
                [1, 0, 0, 0],
                [0, np.cos(angle_rad), -np.sin(angle_rad), 0],
                [0, np.sin(angle_rad), np.cos(angle_rad), 0],
                [0, 0, 0, 1]
            ])
        elif axis == [0, 1, 0]:  # Y-axis
            rotation_matrix = np.array([
                [np.cos(angle_rad), 0, np.sin(angle_rad), 0],
                [0, 1, 0, 0],
                [-np.sin(angle_rad), 0, np.cos(angle_rad), 0],
                [0, 0, 0, 1]
            ])
        elif axis == [0, 0, 1]:  # Z-axis
            rotation_matrix = np.array([
                [np.cos(angle_rad), -np.sin(angle_rad), 0, 0],
                [np.sin(angle_rad), np.cos(angle_rad), 0, 0],
                [0, 0, 1, 0],
                [0, 0, 0, 1]
            ])

        # Apply rotation to all vertices
        for i in range(len(self.original_vertex_list)):
            self.original_vertex_list[i] = np.dot(rotation_matrix, self.original_vertex_list[i]).tolist()

        # Update the projected vertices
        self.generate_projected_vertices()

    def rotate_around_line(self, A, B, angle):
        """
        Rotates all vertices around a line defined by points A and B by a given angle.
        """
        # Translate A to the origin
        translation_to_origin = np.eye(4)
        translation_to_origin[:3, 3] = [-A[0], -A[1], -A[2]]

        # Compute the direction vector of the line
        direction = np.array(B) - np.array(A)
        direction = direction / np.linalg.norm(direction)

        # Compute rotation matrices around the line
        Rx, Ry, Rz = self.rotation_matrices_for_line(direction, angle)

        # Apply the transformations to all vertices
        for i in range(len(self.original_vertex_list)):
            v = np.array(self.original_vertex_list[i])
            v = np.dot(translation_to_origin, v)  # Translate to origin
            v = np.dot(Rx, np.dot(Ry, np.dot(Rz, v)))  # Apply rotations
            v = np.dot(np.linalg.inv(translation_to_origin), v)  # Translate back
            self.original_vertex_list[i] = v.tolist()

        # Update the projected vertices
        self.generate_projected_vertices()

    def rotation_matrices_for_line(self, direction, angle):
        """
        Computes rotation matrices for a line defined by a direction vector.
        """
        angle_rad = np.radians(angle)
        x, y, z = direction

        # Rotation around X-axis
        Ry = np.array([
            [np.cos(angle_rad), 0, np.sin(angle_rad), 0],
            [0, 1, 0, 0],
            [-np.sin(angle_rad), 0, np.cos(angle_rad), 0],
            [0, 0, 0, 1]
        ])

        # Rotation around Y-axis
        Rx = np.array([
            [1, 0, 0, 0],
            [0, np.cos(angle_rad), -np.sin(angle_rad), 0],
            [0, np.sin(angle_rad), np.cos(angle_rad), 0],
            [0, 0, 0, 1]
        ])

        # Rotation around Z-axis
        Rz = np.array([
            [np.cos(angle_rad), -np.sin(angle_rad), 0, 0],
            [np.sin(angle_rad), np.cos(angle_rad), 0, 0],
            [0, 0, 1, 0],
            [0, 0, 0, 1]
        ])

        return Rx, Ry, Rz

    def compute_rotation_matrix(self, point_n, point_m, angle_degrees):
        """
        Computes the rotation matrix for rotating about the axis defined by points N and M.
        """
        # Compute the axis vector components
        axis_x = float(point_m[0]) - float(point_n[0])
        axis_y = float(point_m[1]) - float(point_n[1])
        axis_z = float(point_m[2]) - float(point_n[2])

        # Compute the length of the axis vector
        axis_length = np.sqrt(axis_x**2 + axis_y**2 + axis_z**2)

        # Avoid division by zero for the perpendicular components
        perpendicular_length = np.sqrt(axis_y**2 + axis_z**2)
        if perpendicular_length == 0:
            perpendicular_length = 1

        # Translation matrix to bring point N to the origin
        translation_to_origin = np.array([
            [1.0, 0.0, 0.0, -point_n[0]],
            [0.0, 1.0, 0.0, -point_n[1]],
            [0.0, 0.0, 1.0, -point_n[2]],
            [0.0, 0.0, 0.0, 1.0]
        ])

        # Rotation around x-axis to align axis with xz plane
        rotation_x = np.array([
            [1.0, 0.0, 0.0, 0.0],
            [0.0, axis_z / perpendicular_length, -axis_y / perpendicular_length, 0.0],
            [0.0, axis_y / perpendicular_length, axis_z / perpendicular_length, 0.0],
            [0.0, 0.0, 0.0, 1.0]
        ])

        # Rotation around y-axis to align axis with z-axis
        rotation_y = np.array([
            [perpendicular_length / axis_length, 0.0, -axis_x / axis_length, 0.0],
            [0.0, 1.0, 0.0, 0.0],
            [axis_x / axis_length, 0.0, perpendicular_length / axis_length, 0.0],
            [0.0, 0.0, 0.0, 1.0]
        ])

        # Convert rotation angle to radians
        angle_radians = np.radians(angle_degrees)
        sin_theta = np.sin(angle_radians)
        cos_theta = np.cos(angle_radians)

        # Rotation about the z-axis
        rotation_z = np.array([
            [cos_theta, -sin_theta, 0.0, 0.0],
            [sin_theta, cos_theta, 0.0, 0.0],
            [0.0, 0.0, 1.0, 0.0],
            [0.0, 0.0, 0.0, 1.0]
        ])

        # Reverse rotations and translation
        reverse_rotation_y = np.linalg.inv(rotation_y)
        reverse_rotation_x = np.linalg.inv(rotation_x)
        reverse_translation = np.array([
            [1.0, 0.0, 0.0, point_n[0]],
            [0.0, 1.0, 0.0, point_n[1]],
            [0.0, 0.0, 1.0, point_n[2]],
            [0.0, 0.0, 0.0, 1.0]
        ])

        # Composite the transformation matrices
        rotation_matrix = (
            reverse_translation @ reverse_rotation_x @ reverse_rotation_y @ rotation_z @ rotation_y @ rotation_x @ translation_to_origin
        )

        # Handle edge cases for zero vector components
        if axis_y == 0 and axis_z == 0:
            rotation_matrix = np.array([
                [1.0, 0.0, 0.0, 0.0],
                [0.0, cos_theta, -sin_theta, 0.0],
                [0.0, sin_theta, cos_theta, 0.0],
                [0.0, 0.0, 0.0, 1.0]
            ])
        elif axis_x == 0 and axis_z == 0:
            rotation_matrix = np.array([
                [cos_theta, 0.0, sin_theta, 0.0],
                [0.0, 1.0, 0.0, 0.0],
                [-sin_theta, 0.0, cos_theta, 0.0],
                [0.0, 0.0, 0.0, 1.0]
            ])
        elif axis_x == 0 and axis_y == 0:
            rotation_matrix = np.array([
                [cos_theta, -sin_theta, 0.0, 0.0],
                [sin_theta, cos_theta, 0.0, 0.0],
                [0.0, 0.0, 1.0, 0.0],
                [0.0, 0.0, 0.0, 1.0]
            ])

        return rotation_matrix

    def create_graphic_objects(self, canvas, data):
        self.data = data
        self.width = canvas.cget("width")
        self.height = canvas.cget("height")
        self.create_edge_list()
        self.create_vertex_list()
        self.create_bezier_list()
        self.generate_bezier_points(self.result)
        canvas.delete("all")
        i = 0
        for element in self.vertex_list:
            self.draw(canvas, element, self.view_dimension[i])
            i = i+1

    def draw(self, canvas, vertex_list, viewport):
        """
        Draws the transformed objects onto the canvas based on the viewport dimensions.
        """
        # Translate points to the viewport
        translated_points = self.translate_points(vertex_list, viewport)

        # Create the list of drawable edges
        draw_list = self.create_draw_list(vertex_list, translated_points)

        # Compute the viewport rectangle dimensions
        viewport_dimensions = self.translate_viewport(viewport[0], viewport[1], viewport[2], viewport[3])
        
        # Draw the viewport rectangle
        self.objects.append(canvas.create_rectangle(
            viewport_dimensions[0], viewport_dimensions[1],
            viewport_dimensions[2], viewport_dimensions[3],
            outline="black", fill="white"
        ))

        # Draw all the edges within the viewport
        for edge in draw_list:
            self.objects.append(canvas.create_line(edge))

    def create_vertex_list(self):
        """
        Creates the list of vertices and initializes bezier-related lists.
        Extracts vertices and sets the resolution for rendering if specified.
        """
        self.vertex_list = []
        self.bezier_list = []
        vertices = []

        # Process the data to extract resolution and vertex information
        for entry in self.data:
            if entry[0] == 'n':  # Set resolution if specified
                self.result = int(entry[1])
            elif entry[0] == 'v':  # Add vertices to the list
                vertices.append([float(entry[1]), float(entry[2]), float(entry[3]), 1.0])

        # Store the original vertex list
        self.original_vertex_list = vertices

        # Project the vertices into view
        self.generate_projected_vertices()

    def create_bezier_list(self):
        """
        Extracts and creates the list of Bezier control points from the input data.
        """
        bezier_points = []

        # Iterate through the data to extract Bezier points
        for entry in self.data:
            if entry[0] == 'b':  # Check if the entry corresponds to a Bezier point
                bezier_points.append([float(entry[1]), float(entry[2]), float(entry[3])])

        # Store the extracted Bezier points
        self.bezier_list = bezier_points

    def generate_bezier_points(self, lim):
        total = len(self.bezier_list)
        bezier_control_points = []
        temp = []
        for i in range(0, total, 4):
            temp = []
            for j in range(i, (i+4)):
                temp.append(self.bezier_list[j])
            bezier_control_points.append(temp)

        self.bezier_control_points = bezier_control_points
        P_length = len(bezier_control_points)

        for i in range(0, P_length, 4):
            end = i + 4
            self.create_bezier_surface(bezier_control_points[i:end], lim)

    def bezier_increase(self, canvas):
        self.bezier_list = []
        self.bezier_points = []
        self.edge_connections = []
        self.bezier_control_points = []

        self.create_bezier_list()

        lim = self.result
        lim = lim +1
        self.result = lim

        if lim > 100:
            lim = 100
        self.result = lim

        self.generate_bezier_points(lim)

        canvas.delete("all")
        i = 0
        for element in self.vertex_list:
            self.draw(canvas, element, self.view_dimension[i])
            i = i + 1

    def bezier_decrease(self, canvas):
        self.bezier_list = []
        self.bezier_points = []
        self.edge_connections = []
        self.bezier_control_points = []

        self.create_bezier_list()

        lim = self.result
        lim = lim - 1
        self.result = lim


        if lim < 1:
            lim = 1
        self.result = lim

        self.generate_bezier_points(lim)

        canvas.delete("all")
        i = 0
        for element in self.vertex_list:
            self.draw(canvas, element, self.view_dimension[i])
            i = i + 1

    def create_bezier_surface(self, bezier_control_points, lim):
        lim += 1  # Increase the limit to include the endpoint
        uinc = 1.0 / (lim - 1)  # Increment for u
        u_values = np.linspace(0, 1, lim)  # Generate u values directly

        # Precompute Bernstein basis functions
        B = [
            [(1 - u) ** 3 for u in u_values],  # B0
            [3 * u * (1 - u) ** 2 for u in u_values],  # B1
            [3 * u ** 2 * (1 - u) for u in u_values],  # B2
            [u ** 3 for u in u_values],  # B3
        ]

        # Compute Bezier surface points
        points = []
        for i in range(lim):
            curves = [
                self.Curve(i, [bezier_control_points[row][col] for row in range(4)], B)
                for col in range(4)
            ]
            points.extend(
                [self.Curve(j, curves, B) for j in range(lim)]
            )

        # Update original vertex list
        start_index = len(self.original_vertex_list)
        for point in points:
            vertex = point + [1.0]
            self.original_vertex_list.append(vertex)

        # Generate edge connections
        line_list = []
        for i in range(lim * lim):
            if (i + 1) % lim != 0:  # Connect to the right neighbor
                line_list.append([i + start_index, i + 1 + start_index])
            if i + lim < lim * lim:  # Connect to the bottom neighbor
                line_list.append([i + start_index, i + lim + start_index])
            if i + lim + 1 < lim * lim and (i + 1) % lim != 0:  # Connect diagonally
                line_list.append([i + start_index, i + lim + 1 + start_index])

        self.edge_connections += line_list
        self.generate_projected_vertices()

    def Curve(self, t, c, B):
        c = np.array(c)
        # Compute the curve by summing the weighted control points
        curve = sum(np.multiply(c[i], B[i][t]) for i in range(4))
        return curve.tolist()

    def generate_projected_vertices(self):
        self.vertex_list = [
            [np.dot(mat, np.array(vertex)).tolist() for vertex in self.original_vertex_list]
            for mat in self.projection_matrix
        ]

    def create_edge_list(self):
        self.edge_list = []
        for element in self.data:
            if element[0] == 'f':
                self.edge_list.append(element)

    def translate_viewport(self, xmin, ymin, xmax, ymax):
        x = float(xmin)*float(self.width)
        y = float(ymin)*float(self.height)
        width = (float(xmax) - float(xmin))*float(self.width)
        height = (float(ymax) - float(ymin))*float(self.height)
        a = x+width
        b = y+height
        dimensions = [x, y, a, b]
        self.viewport_dimensions = dimensions
        return dimensions

    def translate_points(self, vList, vPort):
        return [self.translate_coordinate(point[0], point[1], vPort) for point in vList]

    def translate_coordinate(self, pwx, pwy, vd):
        pwx, pwy = float(pwx), float(pwy)
        xwmin, ywmin, xwmax, ywmax = map(float, self.window_dimension)
        nxvmin, nyvmin, nxvmax, nyvmax = map(float, vd)

        screen_width, screen_height = float(self.width), float(self.height)
        xvmin, xvmax = nxvmin * screen_width, nxvmax * screen_width
        yvmin, yvmax = nyvmin * screen_height, nyvmax * screen_height

        sx = (xvmax - xvmin) / (xwmax - xwmin)
        sy = (yvmax - yvmin) / (ywmax - ywmin)

        psx = xvmin + sx * (pwx - xwmin)
        psy = yvmin + sy * (ywmax - pwy)

        return [psx, psy]

    def create_draw_list(self, vList, tList):
        dlist = []

        def process_edge(x, y):
            point1, point2 = tList[x], tList[y]
            p1, p2 = vList[x], vList[y]

            clip = self.clipping(p1, p2)
            if clip:
                dlist.append([point1[0], point1[1], point2[0], point2[1]])

        # Process edges in self.edge_list
        for elements in self.edge_list:
            if elements[0] == 'f':
                elements = elements[1:]  # Remove 'f' element

            for i in range(3):
                x = int(elements[i]) - 1
                y = int(elements[0]) - 1 if i == 2 else int(elements[i + 1]) - 1
                process_edge(x, y)

        # Process edges in self.edge_connections
        for x, y in self.edge_connections:
            process_edge(x, y)

        return dlist

    def clipping(self, p1, p2, perspective=False, zmin=0.1):
        # Unpack the points
        x1, y1, z1 = p1[:3]
        x2, y2, z2 = p2[:3]
        
        def clip_with_plane(value1, value2, min_val, max_val):
            t = None
            if value1 < min_val and value2 >= min_val:
                t = (min_val - value1) / (value2 - value1)
            elif value1 > max_val and value2 <= max_val:
                t = (max_val - value1) / (value2 - value1)
            return t

        def compute_intersection(x1, y1, z1, x2, y2, z2, t):
            x_new = x1 + t * (x2 - x1)
            y_new = y1 + t * (y2 - y1)
            z_new = z1 + t * (z2 - z1)
            return x_new, y_new, z_new

        def is_inside_parallel(x, y, z):
            return -1 <= x <= 1 and -1 <= y <= 1 and 0 <= z <= 1

        def is_inside_perspective(x, y, z):
            return -z <= x <= z and -z <= y <= z and zmin <= z <= 1

        # Check if both points are inside the volume (no clipping needed)
        if (not perspective and is_inside_parallel(x1, y1, z1) and is_inside_parallel(x2, y2, z2)) or \
        (perspective and is_inside_perspective(x1, y1, z1) and is_inside_perspective(x2, y2, z2)):
            return [[x1, y1, z1], [x2, y2, z2]]
        
        while True:
            if (not perspective and not is_inside_parallel(x1, y1, z1) and not is_inside_parallel(x2, y2, z2)) or \
            (perspective and not is_inside_perspective(x1, y1, z1) and not is_inside_perspective(x2, y2, z2)):
                return []  # Entire line is outside
            
            t_values = []
            
            # Clip against parallel or perspective volume boundaries
            if not perspective:
                # Parallel volume clipping boundaries
                t = clip_with_plane(x1, x2, -1, 1)
                if t is not None: t_values.append(t)
                t = clip_with_plane(y1, y2, -1, 1)
                if t is not None: t_values.append(t)
                t = clip_with_plane(z1, z2, 0, 1)
                if t is not None: t_values.append(t)
            else:
                # Perspective volume clipping boundaries
                t = clip_with_plane(x1, x2, -z1, z1)
                if t is not None: t_values.append(t)
                t = clip_with_plane(y1, y2, -z1, z1)
                if t is not None: t_values.append(t)
                t = clip_with_plane(z1, z2, zmin, 1)
                if t is not None: t_values.append(t)

            if t_values:
                t_min = min(t_values)  # Find the smallest t to clip at
                x1, y1, z1 = compute_intersection(x1, y1, z1, x2, y2, z2, t_min)
            else:
                return [[x1, y1, z1], [x2, y2, z2]]  # Return clipped points if within bounds

            # If both points are within bounds after clipping
            if (not perspective and is_inside_parallel(x1, y1, z1) and is_inside_parallel(x2, y2, z2)) or \
            (perspective and is_inside_perspective(x1, y1, z1) and is_inside_perspective(x2, y2, z2)):
                return [[x1, y1, z1], [x2, y2, z2]]

            # Perspective projection step: divide x and y by z after clipping
            if perspective:
                return [[x1 / z1, y1 / z1, z1], [x2 / z2, y2 / z2, z2]]
            else:
                return [[x1, y1, z1], [x2, y2, z2]]
            
    def is_outside_parallel(self, x, y, z):
        # Check if the point is outside the viewing volume
        if x < -1 or x > 1 or y < -1 or y > 1 or z < 0 or z > 1:
            return True
        return False
    
    def refresh_display(self, canvas, event=None):
        """
        Redraws the objects on the canvas, updating dimensions if an event is provided.
        """
        # Update width and height based on the event or use the canvas dimensions
        if event:
            self.width = float(event.width)
            self.height = float(event.height)
        else:
            self.width = float(canvas.cget("width"))
            self.height = float(canvas.cget("height"))

        # Clear the canvas
        canvas.delete("all")

        # Redraw objects
        i = 0
        for element in self.vertex_list:
            self.draw(canvas, element, self.view_dimension[i])
            i += 1

        # Redraw viewports
        for a in self.view_dimension:
            dimension = self.translate_viewport(a[0], a[1], a[2], a[3])
            self.objects.append(canvas.create_rectangle(dimension[0], dimension[1], dimension[2], dimension[3], outline='black'))