import numpy as np
import sys

# Define symbols for different movements
movements = {"Up": "^", "Right": ">", "Down": "v", "Left": "<"}

# Function to calculate the transition probability given the next state, current state, and action probabilities
def calculate_transition_probability(next_state, current_state, move_probs):
    returnVal = 0
    for move, prob in move_probs.items():
        new_state = (current_state[0] + move[0], current_state[1] + move[1])
        # Check if the new state is valid, if not, stay in the current state
        if not is_valid_state(new_state):
            new_state = current_state
        if new_state == next_state:
            returnVal += prob
    return returnVal

# Function to calculate the transition probability for a specific action
def transition(next_state, current_state, action):
    move_probs = {}

    # Assign probabilities for each possible move based on the chosen action
    if action == "Up":
        move_probs = {(-1, 0): 0.8, (0, -1): 0.1, (0, 1): 0.1}
    elif action == "Left":
        move_probs = {(0, -1): 0.8, (-1, 0): 0.1, (1, 0): 0.1}
    elif action == "Down":
        move_probs = {(1, 0): 0.8, (0, -1): 0.1, (0, 1): 0.1}
    elif action == "Right":
        move_probs = {(0, 1): 0.8, (-1, 0): 0.1, (1, 0): 0.1}

    # Calculate and return the transition probability
    return calculate_transition_probability(next_state, current_state, move_probs)

# Function to check if a state is valid (within bounds and not blocked by an obstacle)
def is_valid_state(s):
    return 0 <= s[0] < len(data_file) and 0 <= s[1] < len(data_file[0]) and data_file[s[0]][s[1]] != 'X'

# Function to calculate the reward for a given state
def calculate_reward(state):
    if 0 <= state[0] < len(data_file) and 0 <= state[1] < len(data_file[0]):
        val = data_file[state[0]][state[1]]
        if val == '.':
            return ntr
        elif val == 'X':
            return 0
        else:
            return float(val)
    else:
        return 0

# Function to calculate the maximum expected utility for a state and action
def calculate_max(state, U, N, action):
    max_val = 0
    for i in range(N[0]):
        for j in range(N[1]):
            max_val += (transition((i, j), state, action) * U[i][j])
    return max_val

# Function for performing value iteration
def value_iteration(data_file, ntr, gamma, K):
    N = len(data_file), len(data_file[0])
    pi = np.chararray(N, unicode=True)
    Uprime = np.zeros(N)

    # Iterate K times to update the utility values
    for loop in range(K):
        U = Uprime.copy()
        for i in range(N[0]):
            for j in range(N[1]):
                try:
                    if data_file[i][j] == 'X':
                        Uprime[i][j] = 0
                        pi[i][j] = 'x'
                    elif data_file[i][j] != '.':
                        Uprime[i][j] = float(data_file[i][j])
                        pi[i][j] = 'o'
                    else:
                        maxVal = 0
                        # Calculate the maximum expected utility for each possible action
                        for action in movements:
                            val = calculate_max((i, j), U, N, action)
                            maxVal = max(val, maxVal)
                            if val == maxVal:
                                pi[i][j] = movements[action]
                        # Update the utility value using the Bellman equation
                        Uprime[i][j] = ntr + gamma * maxVal
                except ValueError:
                    Uprime[i][j] = 0
    return U, pi

# Function to read the environment file and return the data
def read_environment_file(filename):
    data_file = []
    with open(filename) as file:
        for line in file:
            row = line.strip().split(',')
            data_file.append(row)
    return data_file

# Check if the correct number of command line arguments is provided
if len(sys.argv) < 5:
    print("Not enough arguments")
    sys.exit(0)

# Get command line arguments
environment_file = sys.argv[1]
ntr = float(sys.argv[2])
gamma = float(sys.argv[3])
K = int(sys.argv[4])

# Read the environment file
data_file = read_environment_file(environment_file)

# Perform value iteration and get the resulting utilities and policy
utilities, policy = value_iteration(data_file, ntr, gamma, K)

# Print the resulting utilities
print("utilities:")
for i in range(len(utilities)):
    for j in range(len(utilities[0])):
        print("{:6.3f}".format(utilities[i][j]), end=' ')
    print()

# Print the resulting policy
print("\npolicy:")
for i in range(len(policy)):
    for j in range(len(policy[0])):
        print("{:6s}".format(policy[i][j]), end=' ')
    print()