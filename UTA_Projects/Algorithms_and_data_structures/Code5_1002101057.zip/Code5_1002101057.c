#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

#define MAX 50

typedef struct 
{
    char label[6];
    int distance;
    int visited;
    int previous;
} 
Vertex;

// Function to find the shortest path using Dijkstra's algorithm.
void DijkstraAlgorithm(Vertex VertexArray[], int AdjMatrix[MAX][MAX], int start_vertexVertex, int VertexCount) 
{
    int CurrentVertex = start_vertexVertex;
    VertexArray[start_vertexVertex].distance = 0;
    VertexArray[start_vertexVertex].previous = -1;
    VertexArray[start_vertexVertex].visited = 1;

    // Loop through all vertices (except the start_vertex) to find the shortest path.
    for (int x = 0; x < VertexCount - 1; x++)
    {
        for (int i = 0; i < VertexCount; i++)
        {
            // Check if there is a connection between the CurrentVertex and vertex i, and if i is not visited.
            if (AdjMatrix[CurrentVertex][i] != -1 && !VertexArray[i].visited)
            {
                // Calculate the new distance for vertex i if passing through the CurrentVertex is shorter.
                if (VertexArray[CurrentVertex].distance + AdjMatrix[CurrentVertex][i] < VertexArray[i].distance)
                {
                    VertexArray[i].distance = VertexArray[CurrentVertex].distance + AdjMatrix[CurrentVertex][i];
                    VertexArray[i].previous = CurrentVertex;
                }
            }
        } 

        // Find the unvisited vertex with the smallest distance and mark it as the new CurrentVertex.
        int SmallestVertexIndex = -1;
        int SmallestVertex = INT_MAX;

        for (int i = 0; i < VertexCount; i++)
        {
            if (!VertexArray[i].visited)
            {
                if (VertexArray[i].distance < SmallestVertex)
                {
                    SmallestVertex = VertexArray[i].distance;
                    SmallestVertexIndex = i;
                }
            }
        }

        CurrentVertex = SmallestVertexIndex;
        VertexArray[CurrentVertex].visited = 1;
    }
}

// Function to read the graph data from the file and initialize the VertexArray and AdjMatrix.
void File_Handler(const char filename[], Vertex VertexArray[], int AdjMatrix[MAX][MAX], int *VertexCount) 
{
    char file_line[30] = {};
    int count = 0;
    int index = 0; 
    int weight = 0;
    char *token;

    // Initialize the Adjacency Matrix with -1 (indicating no edge)
    for (int i = 0; i < MAX; i++) 
    {
        for (int j = 0; j < MAX; j++) 
        {
            AdjMatrix[i][j] = -1;
        }
    }

    FILE *FH = fopen(filename, "r");

    if (FH == NULL) 
    {
        printf("Error opening file %s.\n", filename);
        exit(1);
    }

    // Read graph data from the file
    while (fgets(file_line, sizeof(file_line) - 1, FH) != NULL) 
    {
        // Remove the trailing newline character, if present
        if (file_line[strlen(file_line) - 1] == '\n') 
        {
            file_line[strlen(file_line) - 1] = '\0';
        }

        // Parse the line and extract vertex label and its neighbors' indices and weights
        token = strtok(file_line, ",");
        strcpy(VertexArray[count].label, token);
        VertexArray[count].distance = INT_MAX;
        VertexArray[count].visited = 0;
        VertexArray[count].previous = -1;
        token = strtok(NULL, ",");

        while (token != NULL) 
        {
            index = atoi(token);
            token = strtok(NULL, ",");
            weight = atoi(token);
            AdjMatrix[count][index] = weight;
            token = strtok(NULL, ",");
        }

        count++;
    }

    fclose(FH);

    // Update the total number of vertices read from the file
    *VertexCount = count;
}

int main(int argc, char *argv[]) 
{
    if (argc != 2) 
    {
        printf("Usage: %s <filename>\n", argv[0]);
        return 1;
    }

    char* filename = argv[1];

    Vertex VertexArray[MAX] = {};
    int AdjMatrix[MAX][MAX] = {}; 
    int VertexCount = 0;
    
    // Read the graph from the specified file
    File_Handler(filename, VertexArray, AdjMatrix, &VertexCount);

    int start_vertexVertex = 0;
    int DestinationVertex = 0;
    char start_vertex[30] = "";
    char end_vertex[30] = "";

    #ifdef PRINTIT
    printf("\n");
    for (int i = 0; i < VertexCount; i++)
    {
        for (int j = 0; j < VertexCount; j++)
            printf("%5d\t", AdjMatrix[i][j]);
        printf("\n");
    }
    printf("\n"); 
    #endif

    printf("What is the starting vertex? ");
    scanf("%s", start_vertex);

    // Find the index of the starting vertex in the VertexArray.
    for (int i = 0; i < VertexCount; i++) 
    {     
        if ((strcmp(VertexArray[i].label, start_vertex)) == 0) 
        {
            start_vertexVertex = i;
        }
    }

    // Run Dijkstra's algorithm to find the shortest path.
    DijkstraAlgorithm(VertexArray, AdjMatrix, start_vertexVertex, VertexCount);

    #ifdef PRINTIT  
    // Print the calculated distances, previous vertices, and visited status of all vertices if PRINTIT is defined.
    printf("\n\nI\tL\tD\tP\tV\n");
    for (int i = 0; i < VertexCount; i++) 
    {
        printf("%d\t%s\t%d\t%d\t%d\n", i, VertexArray[i].label, VertexArray[i].distance, VertexArray[i].previous, VertexArray[i].visited);
    }
    printf("\n");
    #endif

    printf("What is the destination vertex? ");
    scanf("%s", end_vertex);

    // Find the index of the destination vertex in the VertexArray.
    for (int i = 0; i < VertexCount; i++) 
    {
        if ((strcmp(VertexArray[i].label, end_vertex)) == 0) 
        {
            DestinationVertex = i;
        }
    }

    // Trace back the shortest path from the destination vertex to the starting vertex.
    int path[MAX] = {};
    path[0] = DestinationVertex;
    path[1] = VertexArray[DestinationVertex].previous;
    int p_num = 2, current_pos = 1, s = 0;

    while (VertexArray[path[current_pos]].previous != -1) 
    {
        path[p_num] = VertexArray[path[current_pos]].previous;
        p_num++;
        current_pos++;
    }

    // Print the shortest path and its length.
    printf("The path from %s to %s is ", VertexArray[start_vertexVertex].label, VertexArray[DestinationVertex].label);

    for (s = p_num - 1; s >= 0; s--) 
    {
        if (s > 0) 
            printf("%s->", VertexArray[path[s]].label);
        else 
            printf("%s", VertexArray[path[s]].label);
    }

    printf(" and has a length of %d\n", VertexArray[DestinationVertex].distance);

    return 0;
}