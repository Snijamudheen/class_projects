/* Name: Shaheen Nijamudheen */
/* ID: 1002101057 */
/* Coding Assignment 3 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

void ReadFileIntoArray(int argc, char *argv[], int **AP, int **number)
{
    FILE *myFile;
    char file_name[100];
    char file_char[100];
    char *token;
    int counter = 0;
    
    // Check if the correct number of command line arguments is provided
    if (argc == 2)
    {
        strcpy(file_name, argv[1]);      // Copy the file name from command line argument
        myFile = fopen(file_name, "r");  // Open the file for reading

        if(myFile == NULL)
        {
            printf("Failed to open the file.\n");
            exit(1);
        }
    }
    else
    {
        printf("File must be provied on command line...exiting\n");
        exit(1);
    }

    // Count the number of lines in the file
    while (fgets(file_char, sizeof(file_char) - 1, myFile))
    {
        counter++; 
    }

    **number = counter;                     // Store the number of lines in this counter pointer
    *AP = malloc(counter* sizeof(int));     // Allocate memory for the array based on the number of lines
    fseek(myFile, 0, SEEK_SET);             // Move the file pointer to the beginning of the file
    
    int i = 0;
    
    // Read each line from the file and convert it to an integer
    while (fgets(file_char, sizeof(file_char) - 1, myFile))
    {   
        token = strtok(file_char, " ");      // Split the line by spaces
        (*AP)[i] = atoi(file_char);          // Convert the token to an integer and store it in the array
        i++;
    }

    fclose(myFile);
}

void insertionsort(int A[], int n)
{
    int i, key, j;

    for(j = 1; j < n; j++)
    {
        key = A[j];
        i = j - 1;

        while(i >= 0 && A[i] > key)
        {
            A[i + 1] = A[i];
            i = i - 1;
        }
        A[i + 1] = key; 
    }
}

void merge(int arr[], int left, int middle, int right)
{
    int i, j, k;
    int n1 = middle - left + 1;
    int n2 = right - middle;

    int L[n1], R[n2];

    for (i = 0; i < n1; i++)
    {
        L[i] = arr[left + i];
    }
    for (j = 0; j < n2; j++)
    {
        R[j] = arr[middle + 1 + j];
    }

    i = 0;
    j = 0;
    k = left;

    while(i < n1 && j < n2)
    {
        if (L[i] <= R[j])
        {
            arr[k] = L[i];
            i++;
        }
        else
        {
            arr[k] = R[j];
            j++;
        }
        k++;
    }

    while (i < n1)
    {
        arr[k] = L[i];
        i++;
        k++;
    }

    while (j < n2)
    {
        arr[k] = R[j];
        j++;
        k++;
    }
}

void mergeSort(int arr[], int L, int R)
{
    if (L < R)
    {
        int M = (L+R)/2;
        mergeSort(arr, L, M);
        mergeSort(arr,M+1, R);
        merge(arr, L, M, R);
    }
}

void PrintArray(int ArrayToPrint[], int SizeAP)
{
    int i;

    for (i = 0; i < SizeAP; i++)
        printf("%d\n", ArrayToPrint[i]);  
}

int main(int argc, char *argv[])
{
    clock_t insertion_start, insertion_end;
    clock_t merge_start, merge_end;
    int *TempPtr = NULL;     // Temporary pointer to store the dynamically allocated array
    int elements = 0;
    int *elements_ptr = &elements;

    // Read file data into the array
    ReadFileIntoArray(argc, argv, &TempPtr, &elements_ptr);

    // Print the array before merge sort
    #ifdef PRINTARRAY
    PrintArray(TempPtr, elements);
    printf("\n");
    #endif

    // Capture the clock in a start time, then perform merge sort and finally record the end time
    merge_start = clock();
    mergeSort(TempPtr, 0, elements - 1);
    merge_end = clock();

    // Print the array after merge sort
    #ifdef PRINTARRAY
    PrintArray(TempPtr, elements);
    printf("\n");
    #endif

    // Free the dynamically allocated memory for the array
    free(TempPtr);

    // Read file data into the array
    ReadFileIntoArray(argc, argv, &TempPtr, &elements_ptr);
    
    // Print the array before insertion sort
    #ifdef PRINTARRAY
    PrintArray(TempPtr, elements);
    printf("\n\n\n");
    #endif
    
    // Capture the clock in a start time, then perform insertion sort and finally record the end time
    insertion_start = clock();
    insertionsort(TempPtr, elements);
    insertion_end = clock();
    
    // Print the array after insertion sort
    #ifdef PRINTARRAY
    PrintArray(TempPtr, elements);
    printf("\n\n\n");
    #endif

    // Free the dynamically allocated memory for the array
    free(TempPtr);

    printf("Processed %d records\n", elements);
    printf("Merge Sort     = %ld\n", merge_end - merge_start);
    printf("Insertion Sort = %ld\n", insertion_end - insertion_start);

    return 0;
}