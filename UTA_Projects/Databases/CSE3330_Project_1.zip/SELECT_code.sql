--SQL QUERIES--

-- 2. Given a passenger’s last name and first name, retrieve all trains they are booked on

SELECT Train.Train_Number, Train.Train_Name, Train.Source_Station, Train.Destination_Station
FROM Train, Passenger, Booked
WHERE Passenger.SSN = Booked.Passenger_ssn
AND Booked.Train_Number = Train.Train_Number
AND Passenger.first_name = 'James'
AND Passenger.last_name = 'Butt';

-- 3. Given a day list the passengers traveling on that day with confirmed tickets. 

SELECT Passenger.first_name, Passenger.last_name 
FROM Passenger, Booked, Train, Train_status 
WHERE Passenger.SSN = Booked.Passenger_ssn 
AND Booked.Train_Number = Train.Train_Number 
AND Train.Train_Name = Train_status.Train_Name 
AND Train_status.TrainDate = 'Tuesday' 
AND Booked.Status = 'Booked';

-- 4. Display the train information (Train Number, Train Name, Source and Destination) and passenger information (Name, Address, Category, ticket status) of passengers who are between the ages of 50 to 60. 

SELECT Train.Train_Number, Train.Train_Name, Train.Source_Station, Train.Destination_Station,
       Passenger.first_name, Passenger.last_name, Passenger.address, 
       Booked.Ticket_Type, Booked.Status
FROM Train, Booked, Passenger
WHERE Passenger.SSN = Booked.Passenger_ssn
  AND Booked.Train_Number = Train.Train_Number
  AND (strftime('%Y', 'now') - strftime('%Y', Passenger.bdate)) BETWEEN 50 AND 60;

-- 5. List train name, day and number of passenger on that train. 

SELECT Train.Train_Name, Train_status.TrainDate, COUNT(Booked.Passenger_ssn) AS Number_of_Passengers
FROM Train, Booked, Train_status
WHERE Booked.Train_Number = Train.Train_Number
  AND Train.Train_Name = Train_status.Train_Name
  AND Booked.Status = 'Booked'
GROUP BY Train.Train_Name, Train_status.TrainDate;

-- 6. Enter a train name and retrieve all the passengers with confirmed status traveling on that train.

SELECT Passenger.first_name, Passenger.last_name 
FROM Passenger, Booked, Train 
WHERE Passenger.SSN = Booked.Passenger_ssn 
AND Booked.Train_Number = Train.Train_Number 
AND Train.Train_Name = 'Golden Arrow' 
AND Booked.Status = 'Booked';

-- 7. List passengers that are waitlisted including the name of the train.

SELECT Passenger.first_name, Passenger.last_name, Train.Train_Name 
FROM Passenger, Booked, Train 
WHERE Passenger.SSN = Booked.Passenger_ssn 
AND Booked.Train_Number = Train.Train_Number 
AND Booked.Status = 'WaitL';

-- 8. List passenger names in descending order that have '605' phone area code.

SELECT Passenger.first_name, Passenger.last_name 
FROM Passenger 
WHERE Passenger.phone2 LIKE '605%' 
ORDER BY Passenger.last_name DESC, Passenger.first_name DESC;

-- 9. List name of passengers that are traveling on Thursdays in ascending order.

SELECT Passenger.first_name, Passenger.last_name 
FROM Passenger, Booked, Train, Train_status 
WHERE Passenger.SSN = Booked.Passenger_ssn 
AND Booked.Train_Number = Train.Train_Number 
AND Train.Train_Name = Train_status.Train_Name 
AND Train_status.TrainDate = 'Thursday' 
ORDER BY Passenger.last_name ASC, Passenger.first_name ASC;