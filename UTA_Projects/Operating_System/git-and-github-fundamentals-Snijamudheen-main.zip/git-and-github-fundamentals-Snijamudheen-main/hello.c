#include <stdio.h>

int main( int argc, char * argv[] )
{
  
  printf("My name is Shaheen Nijamudheen. My NetID is sxn1057.\n");
  printf("Complete.");
  
  return 0;
}
