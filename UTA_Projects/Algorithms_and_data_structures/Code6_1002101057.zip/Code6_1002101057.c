// Coding Assignment 6
// ID: 1002101057
// Name: Shaheen Nijamudheen

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <time.h>
 
#define HASHTABLESIZE 30

typedef struct Argentina_football_players
{
    char *name;
    char *club;
    float height;
    int overall_rating;
    char position;
    struct Argentina_football_players *next_ptr;
}
ARGENTINA_FOOTBALL_PLAYERS;
 
/* This function creates an index corresponding to the input key */
int MyHashFunction(char *key) 
{
    int hash = 0;

    // Loop through each character of the key and sum their ASCII values
    for (int i = 0; key[i] != '\0'; i++) 
    {
        hash += key[i];
    }

    // Calculate the index in the hash table by taking the modulo with HASHTABLESIZE
    return hash % HASHTABLESIZE;
}

void AddNode(ARGENTINA_FOOTBALL_PLAYERS *NewNode, ARGENTINA_FOOTBALL_PLAYERS *Argentina_football_players[])
{
	int HashIndex = MyHashFunction(NewNode->name);
	
	/* a linked list does not exist for this cell of the array */
	if (Argentina_football_players[HashIndex] == NULL) 
	{
		#if PRINTINSERT
		printf("\nInserting %s at index %d\n", NewNode->name, HashIndex);
		#endif
		
		Argentina_football_players[HashIndex] = NewNode;
	}
	else   /* A Linked List is present at given index of Hash Table */ 
	{
		ARGENTINA_FOOTBALL_PLAYERS *TempPtr = Argentina_football_players[HashIndex];
	
		/* Traverse linked list */
		while (TempPtr->next_ptr != NULL) 
		{
			TempPtr = TempPtr->next_ptr;
		}

		TempPtr->next_ptr = NewNode;

		#if PRINTINSERT
		printf("\nInserting %s at index %d\n", NewNode->name, HashIndex);
		#endif
	}
}

void FreeDynamicMemory(ARGENTINA_FOOTBALL_PLAYERS *Argentina_football_players[])
{
	ARGENTINA_FOOTBALL_PLAYERS *TempPtr = NULL, *NextPtr = NULL;
	
	for (int i = 0; i < HASHTABLESIZE; i++)
	{
		TempPtr = Argentina_football_players[i];
 
		if (TempPtr != NULL) 
		{
			while (TempPtr != NULL) 
			{
				free(TempPtr->name);
				free(TempPtr->club);
				NextPtr = TempPtr->next_ptr;
				free(TempPtr);
				TempPtr = NextPtr;
			}	
		}
	}
}

int DeleteNode(ARGENTINA_FOOTBALL_PLAYERS *Argentina_football_players[])
{
    char LookupName[100] = {};
    int result = 0;

    printf("Enter the name of the Player you'd like to remove from the team: ");
    fgets(LookupName, sizeof(LookupName), stdin);
    LookupName[strcspn(LookupName, "\n")] = '\0';

    int HashIndex = MyHashFunction(LookupName);

    ARGENTINA_FOOTBALL_PLAYERS *TempPtr = Argentina_football_players[HashIndex];
    ARGENTINA_FOOTBALL_PLAYERS *PrevPtr = NULL;

    if (TempPtr == NULL)
    {
        printf("\n\nPlayer %s does not exist in the team\n\n", LookupName);
        result = 0;
    }
    else
    {
        while (TempPtr != NULL)
        {
            if (strcmp(TempPtr->name, LookupName) == 0)
            {
                if (TempPtr == Argentina_football_players[HashIndex])
                {
                    Argentina_football_players[HashIndex] = TempPtr->next_ptr;
                    printf("\nPlayer %s has been removed from the team\n\n", TempPtr->name);
                    free(TempPtr);
                    TempPtr = NULL;
                }
                else
                {
                    PrevPtr->next_ptr = TempPtr->next_ptr;
                    printf("\nPlayer %s has been removed from the team\n\n", TempPtr->name);
                    free(TempPtr);
                    TempPtr = NULL;
                }
                result = 1;
            }
            else
            {
                PrevPtr = TempPtr;
                TempPtr = TempPtr->next_ptr;
            }
        }

        if (result == 0)
        {
            printf("\n\nPlayer %s does not exist in the team\n\n", LookupName);
        }
    }
    return result;
}

/* display the contents of the Hash Table */
void DisplayHashTable(ARGENTINA_FOOTBALL_PLAYERS *Argentina_football_players[])
{
	int i;
	ARGENTINA_FOOTBALL_PLAYERS *TempPtr = NULL;
	
	for (i = 0; i < HASHTABLESIZE; i++) 
	{
		TempPtr = Argentina_football_players[i];

		printf("\nArgentina Football Players List[%d]-", i);
		
		if (TempPtr != NULL) 
        {
			while (TempPtr != NULL)
			{
				printf("%s|", TempPtr->name);
				TempPtr = TempPtr->next_ptr;
			}
		}
	}
}

void ShowByLetter(ARGENTINA_FOOTBALL_PLAYERS* Argentina_football_players[]) 
{
    int i;
    ARGENTINA_FOOTBALL_PLAYERS* TempPtr = NULL;
    char TempBuffer[100] = {}; 
    char LookupLetter = 'A';

    printf("\n\nEnter a letter of the alphabet: ");
    fgets(TempBuffer, sizeof(TempBuffer), stdin);

    if (strlen(TempBuffer) >= 1) 
	{
        LookupLetter = toupper(TempBuffer[0]);

        for (i = 0; i < HASHTABLESIZE; i++) 
		{
            TempPtr = Argentina_football_players[i];

            if (TempPtr != NULL) 
			{
                while (TempPtr != NULL) 
				{
                    if (toupper(TempPtr->name[0]) == LookupLetter) 
					{
                        printf("%s\n", TempPtr->name);
                    }
                    TempPtr = TempPtr->next_ptr;
                }
            }
        }
    } 
	else 
	{
        printf("Invalid input.\n");
    }
}

void ShowByName(ARGENTINA_FOOTBALL_PLAYERS* Argentina_football_players[]) 
{
    ARGENTINA_FOOTBALL_PLAYERS* TempPtr = NULL;
    char height[10] = {};
    char LookupName[100] = {};
    int FoundIt = 0;
    
    printf("\n\nEnter player's name: ");
    fgets(LookupName, sizeof(LookupName), stdin);
    LookupName[strlen(LookupName) - 1] = '\0';

	#if TIMING
	clock_t start, end;
	start = clock();
	#endif

    for (int i = 0; i < HASHTABLESIZE; i++) 
	{
        TempPtr = Argentina_football_players[i];

        if (TempPtr != NULL) 
		{
            while (TempPtr != NULL) 
			{
                if (strcmp(TempPtr->name, LookupName) == 0) 
				{
					#if TIMING
					end = clock();
					printf("\n\nSearch took %ld tics\n\n", end-start);
					#endif

                    FoundIt = 1;

                    printf("\n\n%s\n", LookupName);
                    printf("Club\t\t%s\n", TempPtr->club);
                    printf("Height\t\t");
                    sprintf(height, "%.2f", TempPtr->height);

                    for (int i = 0; i < strlen(height); i++) 
					{
                        if (height[i] == '.') 
						{
                            printf("\' ");
                        } 
						else 
						{
                            printf("%c", height[i]);
                        }
                    }

                    printf("\"\n");
                    printf("Overall rating\t%d\n", TempPtr->overall_rating);
                    printf("Position\t%c\n", TempPtr->position);
                }
                TempPtr = TempPtr->next_ptr;
            }
        }
    }
    
    if (FoundIt == 0)
        printf("\n\nPlayer %s not found in the team\n\n", LookupName);
}

void AddNewPlayer(ARGENTINA_FOOTBALL_PLAYERS* Argentina_football_players[]) 
{
    ARGENTINA_FOOTBALL_PLAYERS* NewNode;
    char TempBuffer[100] = {};

    NewNode = malloc(sizeof(ARGENTINA_FOOTBALL_PLAYERS));
    NewNode->next_ptr = NULL;

    printf("\n\nEnter new player's name: ");
    fgets(TempBuffer, sizeof(TempBuffer), stdin);
    TempBuffer[strlen(TempBuffer) - 1] = '\0'; 
    NewNode->name = malloc(strlen(TempBuffer) + 1);
    strcpy(NewNode->name, TempBuffer);

    printf("\n\nEnter %s's club: ", NewNode->name);
    fgets(TempBuffer, sizeof(TempBuffer), stdin);
    TempBuffer[strlen(TempBuffer) - 1] = '\0'; 
    NewNode->club = malloc(strlen(TempBuffer) + 1);
    strcpy(NewNode->club, TempBuffer);

    printf("\n\nEnter %s's height as feet.inches: ", NewNode->name);
    fgets(TempBuffer, sizeof(TempBuffer), stdin);
    sscanf(TempBuffer, "%f", &(NewNode->height));

    printf("\nEnter %s's overall rating: ", NewNode->name);
    fgets(TempBuffer, sizeof(TempBuffer), stdin);
    sscanf(TempBuffer, "%d", &(NewNode->overall_rating));

    printf("\nEnter %s's position - Midfielder(M), GoalKeeper(G), Forward(F), Defender(D), Striker(S): ", NewNode->name);
    fgets(TempBuffer, sizeof(TempBuffer), stdin);
    NewNode->position = toupper(TempBuffer[0]);

    AddNode(NewNode, Argentina_football_players);
}

int ReadFileIntoHashTable(int argc, char *argv[], ARGENTINA_FOOTBALL_PLAYERS *Argentina_football_players[])
{
	FILE *FH = NULL;
	char FileLine[100] = {};
	char *token = NULL;
	int counter = 0;
	int HashIndex = 0;
	ARGENTINA_FOOTBALL_PLAYERS *NewNode;

	if (argc > 1)
	{
		FH = fopen(argv[1], "r");

		if (FH == NULL)
		{
			perror("Exiting ");
			exit(0);
		}
		
		while (fgets(FileLine, sizeof(FileLine) - 1, FH))
		{
			if (FileLine[strlen(FileLine) - 1] == '\n')
			{
				FileLine[strlen(FileLine) - 1] = '\0';
			}

			token = strtok(FileLine, "|");

			NewNode = malloc(sizeof(ARGENTINA_FOOTBALL_PLAYERS));
			NewNode->next_ptr = NULL;

			NewNode->name = malloc(strlen(token)*sizeof(char) + 1);
			strcpy(NewNode->name, token);

			token = strtok(NULL, "|");
			NewNode->club = malloc(strlen(token)*sizeof(char) + 1);
			strcpy(NewNode->club, token);

			token = strtok(NULL, "|");
			NewNode->height = atof(token);

			token = strtok(NULL, "|");
			NewNode->overall_rating = atoi(token);

			token = strtok(NULL, "|");
			NewNode->position = *token;

			AddNode(NewNode, Argentina_football_players);

			counter++;
		}
	}
	else
	{
		printf("File must be provided on command line...exiting\n");
		exit(0);
	}
	
	fclose(FH);
	
	return counter;
}

int main(int argc, char *argv[]) 
{
	int MenuChoice = 0;
	int counter = 0;
	ARGENTINA_FOOTBALL_PLAYERS *Argentina_football_players[HASHTABLESIZE] = {};

	enum Menu {SHOWBYLETTER=1, SHOWBYNAME, COUNT, DISPLAY, ADD, DELETE, EXIT};
 
	counter = ReadFileIntoHashTable(argc, argv, Argentina_football_players);
 
	do
	{
		printf("\n\nArgentina Football Players Menu\n\n"
			   "1. Show all players in the team for a given letter\n"
			   "2. Look up an Argentina Football player by name\n"
			   "3. How many Argentina Football players are in the team?\n"
			   "4. Display the team\n"
			   "5. Add a new player to the team\n"
			   "6. Delete a player from the team\n"
			   "7. Exit\n\n"
			   "Enter menu choice ");
	
		scanf("%d", &MenuChoice);
		getchar();
		printf("\n\n");

		switch (MenuChoice)
		{	
			case SHOWBYLETTER:
				ShowByLetter(Argentina_football_players);
				break;
			case SHOWBYNAME:
				ShowByName(Argentina_football_players);
				break;
			case COUNT:
				printf("Your team has %d players\n", counter); 
				break;
 			case DISPLAY:
				DisplayHashTable(Argentina_football_players);
				break;
			case ADD:
				AddNewPlayer(Argentina_football_players);
				counter++;
				break;
			case DELETE:
				if (DeleteNode(Argentina_football_players))
				{
					counter--;
				}
				break;
			case EXIT:
				break;
			default : 
				printf("Invalid menu choice\n\n"); 
		}
	}
	while (MenuChoice != EXIT);
	
	FreeDynamicMemory(Argentina_football_players);

	return 0;
}			  
