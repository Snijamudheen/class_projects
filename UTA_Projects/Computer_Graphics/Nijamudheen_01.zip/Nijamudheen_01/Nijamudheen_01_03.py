# Nijamudheen, Shaheen
# 1002_101_057
# 2024_09_22
# Assignment_01_03

import numpy as np
import tkinter as tk
from tkinter import simpledialog, filedialog

class cl_world:
    def __init__(self):
        ################## Main Window ########################
        # Initialize the main window
        self.root = tk.Tk()
        self.root.title("Resizable Window")
        # Set the window geometry (Size) and Make it resizable
        self.root.geometry("400x600")
        self.root.resizable(True, True)
        ################### Top Panel ##########################
        # Create a top frame for the button
        self.top_frame = tk.Frame(self.root)
        self.top_frame.pack(side=tk.TOP, fill=tk.X)
        # Create a button in the top panel
        self.brwose_button = tk.Button(self.top_frame, text="Browse", fg="blue", command=self.browse_file_clicked)
        self.brwose_button.pack(side=tk.LEFT)
        self.draw_button = tk.Button(self.top_frame, text="Draw", command=self.draw_button_clicked)
        self.draw_button.pack(side=tk.LEFT, padx=10, pady=10)
        ################### Canvas #############################
        # Create a canvas to draw on
        self.canvas = tk.Canvas(self.root, bg="light goldenrod")
        self.canvas.pack(fill=tk.BOTH, expand=True)
        # Bind the resize event to redraw the canvas when window is resized
        self.canvas.bind("<Configure>", self.canvas_resized)
        #################### Bottom Panel #######################
        # Create a bottom frame for displaying messages
        self.bottom_frame = tk.Frame(self.root)
        self.bottom_frame.pack(side=tk.BOTTOM, fill=tk.X)
        # Create a label for showing messages and "Object is drawn"
        self.message_label = tk.Label(self.bottom_frame, text="")
        self.message_label.pack(padx=10, pady=10)

        # Data structures for vertices, faces, window, and viewport
        self.vertices = []
        self.faces = []
        self.window = []
        self.viewport = []

    def browse_file_clicked(self):
        self.file_path = tk.filedialog.askopenfilename(filetypes=[("allfiles", "*"), ("pythonfiles", "*.txt")])
        self.message_label.config(text=self.file_path)
        self.load_file(self.file_path)

    def load_file(self, filename):
        """ Loads vertices, faces, window, and viewport parameters from the file """
        self.vertices.clear()
        self.faces.clear()
        self.window.clear()
        self.viewport.clear()

        with open(filename, 'r') as file:
            for line in file:
                tokens = line.split()
                if tokens[0] == 'v':
                    # Store vertices (x, y, z)
                    self.vertices.append([float(tokens[1]), float(tokens[2]), float(tokens[3])])
                elif tokens[0] == 'f':
                    # Store faces as vertex indices
                    self.faces.append([int(tokens[1]), int(tokens[2]), int(tokens[3])])
                elif tokens[0] == 'w':
                    # Store window (xmin, ymin, xmax, ymax)
                    self.window = [float(tokens[1]), float(tokens[2]), float(tokens[3]), float(tokens[4])]
                elif tokens[0] == 's':
                    # Store viewport (xmin, ymin, xmax, ymax)
                    self.viewport = [float(tokens[1]), float(tokens[2]), float(tokens[3]), float(tokens[4])]

    def map_to_viewport(self, x_w, y_w):
        """ Maps window coordinates to viewport coordinates """
        x_min_w, y_min_w, x_max_w, y_max_w = self.window
        x_min_v, y_min_v, x_max_v, y_max_v = self.viewport

        # Map from window coordinates to normalized device coordinates (viewport)
        x_v = ((x_w - x_min_w) / (x_max_w - x_min_w)) * (x_max_v - x_min_v) + x_min_v
        y_v = ((y_w - y_min_w) / (y_max_w - y_min_w)) * (y_max_v - y_min_v) + y_min_v
        return x_v, y_v

    def draw_objects(self, event=None):
        """ Draws the objects on the canvas by mapping vertices to viewport """
        if not self.window or not self.viewport:
            print("Error: Window or viewport parameters missing.")
            return

        self.canvas.delete("all")

        # Draw a rectangular box to frame the object
        canvas_width = self.canvas.winfo_width()
        canvas_height = self.canvas.winfo_height()
        self.canvas.create_rectangle(50, 50, canvas_width - 50, canvas_height - 50, outline="black")

        # For each face, draw a polygon on the canvas using the mapped vertex coordinates
        for face in self.faces:
            points = []
            for vertex_index in face:
                x_w, y_w, _ = self.vertices[vertex_index - 1]  # Vertices are 1-based
                x_v, y_v = self.map_to_viewport(x_w, y_w)

                # Map viewport coordinates to canvas coordinates
                canvas_x = x_v * canvas_width
                canvas_y = (1 - y_v) * canvas_height  # Flip y-axis for canvas
                points.append((canvas_x, canvas_y))

            # Draw the polygon for the face
            if points:
                self.canvas.create_polygon(points, outline='black', fill='')
                
        self.message_label.config(text="Object is drawn")

    def draw_button_clicked(self):
        self.draw_objects()

    def canvas_resized(self, event=None):
        if self.canvas.find_all():
            self.draw_objects(event)


# Run the tkinter main loop
world = cl_world()
world.root.mainloop()
