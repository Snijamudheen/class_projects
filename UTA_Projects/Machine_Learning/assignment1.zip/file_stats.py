import sys

def Calculate(file_name):
    # Read and preprocess the file data
    with open(file_name) as f:
        lines = [line.strip() for line in f]

    # Convert data to floats and initialize variables
    file_info = [line.split() for line in lines]
    file_info = [[float(value) for value in row] for row in file_info]
    column_sums = [0] * len(file_info[0])
    column_means = []
    column_stdev = []

    # Calculate column sums
    for row in file_info:
        for col, value in enumerate(row):
            column_sums[col] += value

    total_rows = len(file_info)
    column_means = [col_sum / total_rows for col_sum in column_sums]

    # Calculate column standard deviations
    for col in range(len(file_info[0])):
        variance = sum((row_value - column_means[col]) ** 2 for row_value in [row[col] for row in file_info])
        variance /= total_rows - 1
        column_stdev.append(variance ** 0.5)

    # Create result list with column stats
    result = [{"column": i + 1, "mean": column_means[i], "std": column_stdev[i]} for i in range(len(column_sums))]
    return result

# Check if the correct number of command line arguments is provided
if len(sys.argv) != 2:
    print("Usage: python script_name.py filename")
else:
    # Get the filename from the command line argument
    file_name = sys.argv[1]
    # Calculate column statistics
    results = Calculate(file_name)

    # Print column statistics
    for result in results:
        print(f'Column {result["column"]}: mean = {result["mean"]:.4f}, std = {result["std"]:.4f}')
