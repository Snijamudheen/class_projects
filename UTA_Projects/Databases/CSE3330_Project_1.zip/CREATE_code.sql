CREATE TABLE Passenger (
    SSN INT PRIMARY KEY NOT NULL,
    first_name VARCHAR(50) NOT NULL,
    last_name VARCHAR(50) NOT NULL,
    address VARCHAR(255) NOT NULL,
    city VARCHAR(50) NOT NULL,
    county VARCHAR(50),
    phone2 VARCHAR(15) NOT NULL,
    bdate DATE NOT NULL
);

CREATE TABLE Train (
    Train_Number INT PRIMARY KEY NOT NULL,
    Train_Name VARCHAR(100) NOT NULL,
    Premium_Fair DECIMAL(10, 2),
    General_Fair DECIMAL(10, 2),
    Source_Station VARCHAR(100),
    Destination_Station VARCHAR(100),
    Available_on_Weekdays VARCHAR(255) NOT NULL
);

CREATE TABLE Booked (
    Passenger_ssn INT NOT NULL,
    Train_Number INT NOT NULL,
    Ticket_Type VARCHAR(50) NOT NULL,
    Status VARCHAR(20) NOT NULL,
    PRIMARY KEY (Passenger_ssn, Train_Number),
    FOREIGN KEY (Passenger_ssn) REFERENCES Passenger(SSN),
    FOREIGN KEY (Train_Number) REFERENCES Train(Train_Number)
);

CREATE TABLE Train_status (
    TrainDate VARCHAR(50) NOT NULL,
    Train_Name VARCHAR(100) NOT NULL,
    PremiumSeatsAvailable INT NOT NULL,
    GenSeatsAvailable INT NOT NULL,
    PremiumSeatsOccupied INT NOT NULL,
    GenSeatsOccupied INT NOT NULL
);