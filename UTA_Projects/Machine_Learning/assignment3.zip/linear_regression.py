import numpy as np

def linear_regression(training_file, test_file, degree, lambda1):
    # Read and process training data
    train_data = np.loadtxt(training_file)

    # Read and process test data
    test_data = np.loadtxt(test_file)

    # Extract outputs from training data
    outputs = train_data[:, -1]

    phi_nums = []
    for x in train_data[:, :-1]:
        phi = [1] + [x_i ** j for x_i in x for j in range(1, degree + 1)]
        phi_nums.append(phi)

    phi_nums = np.array(phi_nums)
    outputs = np.array(outputs)

    # Calculate weights using linear regression formula
    regularization_term = lambda1 * np.identity(phi_nums.shape[1])
    weights = np.dot(np.dot(np.linalg.pinv(np.dot(phi_nums.T, phi_nums) + regularization_term), phi_nums.T), outputs)

    # Print the calculated weights
    for i, weight in enumerate(weights):
        print("w{:d}={:.4f}".format(i, weight))

    # Use the calculated weights to make predictions on test data
    for i, x in enumerate(test_data):
        phi = [1] + [x_i ** j for x_i in x[:-1] for j in range(1, degree + 1)]
        result = np.dot(weights, phi)
        error = (result - x[-1]) ** 2

        # Print prediction results and errors
        print("ID={:5d}, output={:14.4f}, target value = {:10.4f}, squared error = {:0.4f}".format(i + 1, result, x[-1], error))