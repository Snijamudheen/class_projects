#Useful Code Examples
Hopefully you will find some usefulness in the following programs.  Their purpose is to demonstrate certain techniques and functionality you will need to complete assignment 1.

- [parse_command_line.c][01]: Demostrate reading a string and an integer from the command line
- [file_read.c][02]: Demonstrate reading a float, string and integer from a file

[01]: https://github.com/CSE3320/Assignment-1/blob/master/Useful-Examples/parse_command_line.c
[02]: https://github.com/CSE3320/Assignment-1/blob/master/Useful-Examples/file_read.c
