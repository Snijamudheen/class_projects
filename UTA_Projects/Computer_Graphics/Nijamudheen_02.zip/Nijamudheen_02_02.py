# Nijamudheen, Shaheen
# 1002_101_057
# 2024_10_06
# Assignment_02_02

import time
import tkinter as tk
from tkinter import filedialog
import os
import numpy as np
from math import cos, sin, radians
from numpy.linalg import norm

class cl_widgets:
    def __init__(self, ob_root_window, ob_world=[]):
        self.ob_root_window = ob_root_window
        self.ob_world = ob_world
        self.init_widgets()

    def init_widgets(self):
        self.menu = cl_menu(self)
        self.toolbar = cl_toolbar(self)
        self.buttons_panel_01 = cl_buttons_panel_01(self)
        self.buttons_panel_02 = cl_buttons_panel_02(self)
        self.buttons_panel_03 = cl_buttons_panel_03(self)
        self.statusBar_frame = cl_statusBar_frame(self.ob_root_window)
        self.statusBar_frame.pack(side=tk.BOTTOM, fill=tk.X)
        self.statusBar_frame.set('%s', 'This is the status bar')
        self.ob_canvas_frame = cl_canvas_frame(self)
        self.ob_world.add_canvas(self.ob_canvas_frame.canvas)

class cl_canvas_frame:
    def __init__(self, master):
        self.master = master
        self.canvas = tk.Canvas(master.ob_root_window, width=640, height=640, highlightthickness=0, bg="yellow")
        self.canvas.pack(expand=tk.YES, fill=tk.BOTH)

class cl_toolbar:
    def __init__(self, master):
        self.master = master
        self.init_toolbar()

    def init_toolbar(self):
        toolbar = tk.Frame(self.master.ob_root_window)
        toolbar.pack(side=tk.TOP, fill=tk.X)

        tk.Label(toolbar, text="Filename:").pack(side=tk.LEFT, padx=2, pady=2)

        self.var_filename = tk.StringVar()
        tk.Entry(toolbar, width=50, textvariable=self.var_filename).pack(side=tk.LEFT, padx=2, pady=2)
        tk.Button(toolbar, text="Browse", fg="blue", command=self.browse_file).pack(side=tk.LEFT, padx=2, pady=2)
        tk.Button(toolbar, text="Load", fg="red", command=self.load_file).pack(side=tk.LEFT, padx=2, pady=2)

    def browse_file(self):
        self.var_filename.set(filedialog.askopenfilename(filetypes=[("allfiles", "*"), ("txt files", "*.txt")]))

    def load_file(self):
        filename = self.var_filename.get()
        if os.path.exists(filename):
            self.master.ob_world.draw_objects(self.master.ob_canvas_frame.canvas, filename)
            self.master.statusBar_frame.set('%s', f"Loaded file: {filename}")
        else:
            self.master.statusBar_frame.set('%s', "File not found. Please browse and select a valid file.")

class cl_buttons_panel_01:
    def __init__(self, master):
        self.master = master
        self.init_rotation_panel()

    def init_rotation_panel(self):
        frame = tk.Frame(self.master.ob_root_window)
        frame.pack()

        tk.Label(frame, text="Rotation Axis: ").pack(side=tk.LEFT)

        self.rotation_var = tk.StringVar(value="X")
        for text, axis in [("X", "X"), ("Y", "Y"), ("Z", "Z"), ("Line AB", "AB")]:
            tk.Radiobutton(frame, text=text, variable=self.rotation_var, value=axis).pack(side=tk.LEFT)

        self.init_line_ab_entries(frame)
        self.init_degree_and_steps(frame)
        tk.Button(frame, text="Rotate", fg="blue", command=self.rotate).pack(side=tk.LEFT)

    def init_line_ab_entries(self, frame):
        tk.Label(frame, text="A:").pack(side=tk.LEFT)
        self.entryA = tk.Entry(frame, width=10)
        self.entryA.insert(0, "[0.0,0.0,0.0]")
        self.entryA.pack(side=tk.LEFT)

        tk.Label(frame, text="B:").pack(side=tk.LEFT)
        self.entryB = tk.Entry(frame, width=10)
        self.entryB.insert(0, "[1.0,1.0,1.0]")
        self.entryB.pack(side=tk.LEFT)

    def init_degree_and_steps(self, frame):
        # Degree
        tk.Label(frame, text="Degree:").pack(side=tk.LEFT)
        self.spinDegree = tk.Spinbox(frame, from_=0, to=360, width=5)
        self.spinDegree.pack(side=tk.LEFT)
        self.spinDegree.delete(0, "end")  # Clear previous value
        self.spinDegree.insert(0, "90")   # Default degree: 90

        # Steps
        tk.Label(frame, text="Steps:").pack(side=tk.LEFT)
        self.spinSteps = tk.Spinbox(frame, from_=1, to=100, width=5)
        self.spinSteps.pack(side=tk.LEFT)
        self.spinSteps.delete(0, "end")  # Clear previous value
        self.spinSteps.insert(0, "5")    # Default steps: 5

    def rotate(self):
        axis = self.rotation_var.get()  # Get the selected rotation axis (X, Y, Z, or AB)
        degree = float(self.spinDegree.get())  # Get the degree of rotation from the Spinbox
        steps = int(self.spinSteps.get())  # Get the number of steps for the rotation from the Spinbox

        if axis == "AB":
            A = eval(self.entryA.get())  # Extract point A from the input
            B = eval(self.entryB.get())  # Extract point B from the input
            self.master.ob_world.rotation(self.master.ob_canvas_frame.canvas, A, B, steps, degree, axis="AB")
        else:
            self.master.ob_world.rotation(self.master.ob_canvas_frame.canvas, None, None, steps, degree, axis)

class cl_buttons_panel_02:
    def __init__(self, master):
        self.master = master
        frame = tk.Frame(master.ob_root_window)
        frame.pack()

        # Scale options
        self.scalelabel = tk.Label(frame, text="Scale about point:")
        self.scalelabel.pack(side=tk.LEFT)

        self.entryscale = tk.Entry(frame, width=15)
        self.entryscale.pack(side=tk.LEFT)
        self.entryscale.insert(0, "[0.0,0.0,0.0]")

        self.scaleratio_label = tk.Label(frame, text="Scale Ratio:")
        self.scaleratio_label.pack(side=tk.LEFT)

        self.scale_ratio_var = tk.StringVar(value="All")

        # Radio button for "All"
        self.radio_all = tk.Radiobutton(frame, text="All", variable=self.scale_ratio_var, value="All")
        self.radio_all.pack(side=tk.LEFT)

        # Spinbox for All scaling (single value input)
        self.spinAll = tk.Spinbox(frame, from_=0.1, to=10.0, increment=0.1, width=5)
        self.spinAll.pack(side=tk.LEFT)
        self.spinAll.delete(0, "end")  # Clear previous value
        self.spinAll.insert(0, "1")  # Default "All" scaling factor: 1

        # Radio button for "[Sx, Sy, Sz]"
        self.radio_sxyz = tk.Radiobutton(frame, text="[Sx, Sy, Sz]", variable=self.scale_ratio_var, value="Sxyz")
        self.radio_sxyz.pack(side=tk.LEFT)

        # Entry for Sx, Sy, Sz scaling
        self.entryratio = tk.Entry(frame, width=10)
        self.entryratio.pack(side=tk.LEFT)
        self.entryratio.insert(0, "[1,1,1]")

        # Spinbox for Steps
        self.labelSteps = tk.Label(frame, text="Steps:")
        self.labelSteps.pack(side=tk.LEFT)
        self.spinSteps = tk.Spinbox(frame, from_=1, to=100, width=5)
        self.spinSteps.pack(side=tk.LEFT)
        self.spinSteps.delete(0, "end")  # Clear previous value
        self.spinSteps.insert(0, "4")  # Default steps: 4

        self.scale_button = tk.Button(frame, text="Scale", fg="blue", command=self.scale)
        self.scale_button.pack(side=tk.LEFT)

    def scale(self):
        scale_point = eval(self.entryscale.get())  # Point to scale around
        steps = int(self.spinSteps.get())  # Steps from spinbox

        # Use the "All" spinbox if it's not empty, otherwise use [Sx, Sy, Sz]
        if self.spinAll.get() != "":
            scale_factor = float(self.spinAll.get())
            scale_ratio = [scale_factor, scale_factor, scale_factor]
        else:
            scale_ratio = eval(self.entryratio.get())  # Scaling factors for X, Y, Z

        # Perform scaling operation
        self.master.ob_world.scale(scale_point, scale_ratio, steps, self.master.ob_canvas_frame.canvas)

        print(f"Scaling with ratio {scale_ratio} around {scale_point} in {steps} steps")

class cl_buttons_panel_03:
    def __init__(self, master):
        self.master = master
        frame = tk.Frame(master.ob_root_window)
        frame.pack()

        self.translabel = tk.Label(frame, text="Translation ([dx,dy,dz]):")
        self.translabel.pack(side=tk.LEFT)

        self.entrytrans = tk.Entry(frame, width=11)
        self.entrytrans.pack(side=tk.LEFT)
        self.entrytrans.insert(0, "[-.5,-.6,0.5]")

        # Spinbox for Steps (with up/down arrow)
        self.labelSteps = tk.Label(frame, text="Steps:")
        self.labelSteps.pack(side=tk.LEFT)
        self.spinSteps = tk.Spinbox(frame, from_=1, to=100, width=5)
        self.spinSteps.pack(side=tk.LEFT)
        self.spinSteps.delete(0, "end")  # Clear previous value
        self.spinSteps.insert(0, "4")  # Default steps: 4

        self.translate_button = tk.Button(frame, text="Translate", fg="blue", command=self.translate)
        self.translate_button.pack(side=tk.LEFT)

    def translate(self):
        translation = eval(self.entrytrans.get())  # Translation vector
        steps = int(self.spinSteps.get())  # Now using spinbox for steps
        self.master.ob_world.translate(translation, steps, self.master.ob_canvas_frame.canvas)
        print(f"Translating by {translation} in {steps} steps")

class cl_statusBar_frame(tk.Frame):
    def __init__(self, master):
        tk.Frame.__init__(self, master)
        self.label = tk.Label(self, bd=1, relief=tk.SUNKEN, anchor=tk.W)
        self.label.pack(fill=tk.X)

    def set(self, format, *args):
        self.label.config(text=format % args)
        self.label.update_idletasks()

class cl_menu:
    def __init__(self, master):
        self.master = master
        self.menu = tk.Menu(master.ob_root_window)
        master.ob_root_window.config(menu=self.menu)

    def menu_callback(self):
        self.master.statusBar_frame.set('%s', "called the menu callback!")

class cl_world:
    def __init__(self):
        self.canvases = []
        self.vertices = []
        self.faces = []
        self.window = []
        self.view = []

    def add_canvas(self, canvas): 
        self.canvases.append(canvas)

    def load_graphic_objects(self, canvas, filename): 
        """
        Load vertices and faces from a file, and display them on the canvas.
        """
        canvas.delete("all")
        self.objects = []
        self.vertex_global_array = [[0, 0, 0]]  # Reset the vertex array
        self.global_triangle = []
        self.global_window = []
        self.global_view = []

        array_vertex = np.array([[0, 0, 0]], dtype=float)
        with open(filename, "r") as file:
            for line in file:
                first_list = line.split()
                if first_list[0] == "v":  # Vertex
                    temp_array = [float(first_list[1]), float(first_list[2]), float(first_list[3])]
                    array_vertex = np.vstack([array_vertex, temp_array])
                    self.vertex_global_array.append(temp_array)  # Ensure vertices are stored as floats
                elif first_list[0] == "f":  # Face
                    temp_f = [int(x) for x in first_list[1:]]
                    self.global_triangle.append(temp_f)

        self.render_objects(canvas)  # Ensure to display objects after loading

    def render_objects(self, canvas):
        canvas.delete("all")
        if self.faces:
            for face in self.faces:
                points = []
                for vertex_index in face:
                    x, y, _ = self.vertices[vertex_index]
                    points.append((x + 320, y + 320))  # Shift to canvas center
                canvas.create_polygon(points, outline='black', fill='red')

    def rotate_objects(self, A, B, steps, degree, axis, canvas): 
        angle = radians(degree / steps)
        
        if axis in ["X", "Y", "Z"]:
            if axis == "X":
                rotation_matrix = np.array([[1, 0, 0],
                                            [0, cos(angle), -sin(angle)],
                                            [0, sin(angle), cos(angle)]])
            elif axis == "Y":
                rotation_matrix = np.array([[cos(angle), 0, sin(angle)],
                                            [0, 1, 0],
                                            [-sin(angle), 0, cos(angle)]])
            elif axis == "Z":
                rotation_matrix = np.array([[cos(angle), -sin(angle), 0],
                                            [sin(angle), cos(angle), 0],
                                            [0, 0, 1]])
            
        elif axis == "AB":
            A = np.array(A)
            B = np.array(B)
            rotation_axis = B - A
            rotation_axis = rotation_axis / norm(rotation_axis)

            K = np.array([[0, -rotation_axis[2], rotation_axis[1]],
                          [rotation_axis[2], 0, -rotation_axis[0]],
                          [-rotation_axis[1], rotation_axis[0], 0]])
            I = np.eye(3)
            rotation_matrix = I + sin(angle) * K + (1 - cos(angle)) * np.dot(K, K)
        
        for _ in range(steps):
            for i, vertex in enumerate(self.vertices):
                vertex = np.array(vertex) - A
                rotated_vertex = np.dot(rotation_matrix, vertex) + A
                self.vertices[i] = rotated_vertex.tolist()
            self.render_objects(canvas)

    def scale_objects(self, scale_point, scale_ratio, steps, canvas):  
        scale_factor = np.array(scale_ratio) ** (1 / steps)

        for _ in range(steps):
            for i, vertex in enumerate(self.vertices):
                vertex = np.array(vertex)
                scaled_vertex = scale_point + (vertex - scale_point) * scale_factor
                self.vertices[i] = scaled_vertex.tolist()
            self.render_objects(canvas)

    def translate_objects(self, translation, steps=100, canvas=None):  
        translation_step = np.array(translation, dtype=float) / steps

        for _ in range(steps):
            for i in range(1, len(self.vertex_global_array)):
                self.vertex_global_array[i][0] = float(self.vertex_global_array[i][0]) + translation_step[0]
                self.vertex_global_array[i][1] = float(self.vertex_global_array[i][1]) + translation_step[1]
                self.vertex_global_array[i][2] = float(self.vertex_global_array[i][2]) + translation_step[2]

            self.refresh_canvas_coordinates(canvas)  # Redraw after each step
            canvas.update()
            time.sleep(0.05)

    def refresh_canvas_coordinates(self, canvas):  
        self.render_objects(canvas)
