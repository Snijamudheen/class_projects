#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include <time.h>

#define MAX_MALLOC_COUNT 100000
#define MAX_ITERATIONS 10
#define MIN_SIZE 10
#define MAX_SIZE 10
#define INITIAL_MALLOC 100000
#define INCREMENT_SIZE 10

int main()
{
    clock_t start; // Starting time for performance measurement
    clock_t end; // End time for performance measurement
    double elapsed_time;
	
    start = clock(); // Get the starting time of the program
    void ** blocks = (void **)calloc(MAX_MALLOC_COUNT, sizeof(void *)); // Array of pointers for all allocated memory blocks
    size_t size = MIN_SIZE; 
	
	void* large_block = malloc(INITIAL_MALLOC); // Allocate an initial large block of memory
	free(large_block); // Free the large block immediately
	void* small_first = malloc(MIN_SIZE); // Allocate a small memory block
	void* small_second = malloc(MIN_SIZE); // Allocate another small memory block
	free(small_first); // Free the first small block

	for(int i = 0; i < MAX_MALLOC_COUNT; i++)
	{
        blocks[i] = malloc (size); // Allocate a block of memory of the current size
        size += INCREMENT_SIZE; // Increase the size of the next allocation by the increment value
		
		// If the size exceeds the maximum size
		if(size > MAX_SIZE)
		{
			size = MIN_SIZE;
		}
		
		// Generate a random number between 0 and 99
		int index = rand() % 100;
		
		if(index < 100)
		{
			index = rand() % (i+1); // Generate a random index of a block to free
			free(blocks[i]); // Free the memory block
			blocks[i] = NULL; // Set the pointer to NULL
		}
	}
	
    end = clock() - start; // Get the ending time of the program
    elapsed_time = ((double)end) / CLOCKS_PER_SEC; // Calculate the elapsed time in seconds
	
    printf("Elapsed time in seconds: %f\n", elapsed_time);
    free(blocks); // Free all allocated memory
	
    return 0;
}



