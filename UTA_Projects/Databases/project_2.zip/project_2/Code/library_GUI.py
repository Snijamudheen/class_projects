from tkinter import *
import sqlite3
from datetime import date, timedelta


# Requirement 1: Checkout Book and Trigger to Update Book_Copies
def check_out_window():
    ck_root = Toplevel()
    ck_root.title("Check Out Book")
    ck_root.geometry("400x300")

    Label(ck_root, text="Borrower Name:").grid(row=0, column=0)
    Label(ck_root, text="Book Title:").grid(row=1, column=0)
    Label(ck_root, text="Branch Name:").grid(row=2, column=0)

    borrower_name = Entry(ck_root, width=30)
    borrower_name.grid(row=0, column=1)
    book_title = Entry(ck_root, width=30)
    book_title.grid(row=1, column=1)
    branch_name = Entry(ck_root, width=30)
    branch_name.grid(row=2, column=1)

    Button(ck_root, text="Submit", command=lambda: check_out_book(borrower_name, book_title, branch_name, ck_root)).grid(
        row=3, column=0, columnspan=2, pady=10, ipadx=50
    )

def check_out_book(borrower_name, book_title, branch_name, window):
    conn = sqlite3.connect("LMS.db")
    cursor = conn.cursor()

    # Create trigger for updating Book_Copies
    cursor.execute("""
        CREATE TRIGGER IF NOT EXISTS update_copies AFTER INSERT ON BOOK_LOANS
        BEGIN
            UPDATE BOOK_COPIES
            SET No_Of_Copies = No_Of_Copies - 1
            WHERE Book_Id = NEW.Book_Id AND Branch_Id = NEW.Branch_Id;
        END;
    """)

    try:
        today = date.today()
        due_date = today + timedelta(days=14)

        # Fetch Borrower ID
        cursor.execute("SELECT Card_No FROM BORROWER WHERE Name=?", (borrower_name.get(),))
        borrower = cursor.fetchone()
        if not borrower:
            raise Exception("Borrower not found!")
        card_no = borrower[0]

        # Fetch Book ID
        cursor.execute("SELECT Book_Id FROM BOOK WHERE Title=?", (book_title.get(),))
        book = cursor.fetchone()
        if not book:
            raise Exception("Book not found!")
        book_id = book[0]

        # Fetch Branch ID
        cursor.execute("SELECT Branch_Id FROM LIBRARY_BRANCH WHERE Branch_Name=?", (branch_name.get(),))
        branch = cursor.fetchone()
        if not branch:
            raise Exception("Branch not found!")
        branch_id = branch[0]

        # Ensure the book is not already loaned by this borrower
        cursor.execute("""
            SELECT * FROM BOOK_LOANS 
            WHERE Book_Id = ? AND Card_No = ? AND Returned_date IS NULL
        """, (book_id, card_no))
        existing_loan = cursor.fetchone()
        if existing_loan:
            raise Exception("This book is already checked out by the borrower!")

        # Insert into BOOK_LOANS
        cursor.execute("""
            INSERT INTO BOOK_LOANS (Book_Id, Branch_Id, Card_No, Date_Out, Due_Date, Returned_date)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (book_id, branch_id, card_no, today, due_date, None))
        conn.commit()

        # Fetch updated Book_Copies
        cursor.execute("SELECT * FROM BOOK_COPIES WHERE Book_Id = ?", (book_id,))
        records = cursor.fetchall()
        result = "Book_Id | Branch_Id | No_Of_Copies\n"
        result += "\n".join([f"{r[0]}       | {r[1]}        | {r[2]}" for r in records])
        Label(window, text=result).grid(row=5, column=0, columnspan=2)

    except Exception as e:
        Label(window, text=f"Error: {e}").grid(row=5, column=0, columnspan=2)
    finally:
        conn.close()



# Requirement 2: Add New Borrower
def new_borrower_window():
    nb_root = Toplevel()
    nb_root.title("Add New Borrower")
    nb_root.geometry("400x300")

    Label(nb_root, text="Borrower Name:").grid(row=0, column=0)
    Label(nb_root, text="Address:").grid(row=1, column=0)
    Label(nb_root, text="Phone Number:").grid(row=2, column=0)

    name = Entry(nb_root, width=30)
    name.grid(row=0, column=1)
    address = Entry(nb_root, width=30)
    address.grid(row=1, column=1)
    phone = Entry(nb_root, width=30)
    phone.grid(row=2, column=1)

    Button(nb_root, text="Submit", command=lambda: add_borrower(name, address, phone, nb_root)).grid(
        row=3, column=0, columnspan=2, pady=10, ipadx=50
    )


def add_borrower(name, address, phone, window):
    conn = sqlite3.connect("LMS.db")
    cursor = conn.cursor()

    try:
        cursor.execute("SELECT IFNULL(MAX(Card_No), 0) + 1 FROM BORROWER")
        card_no = cursor.fetchone()[0]

        cursor.execute("INSERT INTO BORROWER (Card_No, Name, Address, Phone) VALUES (?, ?, ?, ?)",
                       (card_no, name.get(), address.get(), phone.get()))
        conn.commit()
        Label(window, text=f"Borrower Added! New Card No: {card_no}").grid(row=4, column=0, columnspan=2)
    except Exception as e:
        Label(window, text=f"Error: {e}").grid(row=4, column=0, columnspan=2)

    conn.close()


# Requirement 3: Add New Book
def new_book_window():
    nbk_root = Toplevel()
    nbk_root.title("Add New Book")
    nbk_root.geometry("400x300")

    Label(nbk_root, text="Title:").grid(row=0, column=0)
    Label(nbk_root, text="Author:").grid(row=1, column=0)
    Label(nbk_root, text="Publisher:").grid(row=2, column=0)

    title = Entry(nbk_root, width=30)
    title.grid(row=0, column=1)
    author = Entry(nbk_root, width=30)
    author.grid(row=1, column=1)
    publisher = Entry(nbk_root, width=30)
    publisher.grid(row=2, column=1)

    Button(nbk_root, text="Submit", command=lambda: add_book(title, author, publisher, nbk_root)).grid(
        row=3, column=0, columnspan=2, pady=10, ipadx=50
    )


def add_book(title, author, publisher, window):
    conn = sqlite3.connect("LMS.db")
    cursor = conn.cursor()

    try:
        cursor.execute("SELECT IFNULL(MAX(Book_Id), 0) + 1 FROM BOOK")
        book_id = cursor.fetchone()[0]

        cursor.execute("INSERT INTO BOOK (Book_Id, Title, book_publisher) VALUES (?, ?, ?)",
               (book_id, title.get(), publisher.get()))

        cursor.execute("INSERT INTO BOOK_AUTHORS (Book_Id, Author_Name) VALUES (?, ?)",
                       (book_id, author.get()))

        cursor.execute("SELECT Branch_Id FROM LIBRARY_BRANCH")
        branches = cursor.fetchall()
        for branch_id in branches:
            cursor.execute("INSERT INTO BOOK_COPIES (Book_Id, Branch_Id, No_Of_Copies) VALUES (?, ?, ?)",
                           (book_id, branch_id[0], 5))

        conn.commit()
        Label(window, text="Book Added Successfully!").grid(row=4, column=0, columnspan=2)
    except Exception as e:
        Label(window, text=f"Error: {e}").grid(row=4, column=0, columnspan=2)

    conn.close()


# Requirement 4: Loaned Copies Per Branch
def loaned_copies_window():
    lc_root = Toplevel()
    lc_root.title("Loaned Copies Per Branch")
    lc_root.geometry("400x300")

    Label(lc_root, text="Book Title:").grid(row=0, column=0)

    title = Entry(lc_root, width=30)
    title.grid(row=0, column=1)

    Button(lc_root, text="Submit", command=lambda: show_loaned_copies(title, lc_root)).grid(
        row=1, column=0, columnspan=2, pady=10, ipadx=50
    )


def show_loaned_copies(title, window):
    conn = sqlite3.connect("LMS.db")
    cursor = conn.cursor()

    try:
        cursor.execute("SELECT Book_Id FROM BOOK WHERE Title=?", (title.get(),))
        book_id = cursor.fetchone()[0]

        cursor.execute("SELECT Branch_Id, COUNT(*) FROM BOOK_LOANS WHERE Book_Id=? GROUP BY Branch_Id", (book_id,))
        records = cursor.fetchall()

        result = "Branch ID | Copies Loaned\n"
        result += "\n".join([f"{row[0]}        | {row[1]}" for row in records])
        Label(window, text=result).grid(row=2, column=0, columnspan=2)
    except Exception as e:
        Label(window, text=f"Error: {e}").grid(row=2, column=0, columnspan=2)

    conn.close()



# Requirement 5: List Late Book Loans
def date_range_window():
    dr_root = Toplevel()
    dr_root.title("Late Book Loans")
    dr_root.geometry("400x300")

    Label(dr_root, text="Enter Date Range (YYYY-MM-DD):").grid(row=0, column=0, columnspan=2)

    Label(dr_root, text="Start Date:").grid(row=1, column=0)
    Label(dr_root, text="End Date:").grid(row=2, column=0)

    start_date = Entry(dr_root, width=30)
    start_date.grid(row=1, column=1)
    end_date = Entry(dr_root, width=30)
    end_date.grid(row=2, column=1)

    Button(dr_root, text="Submit", command=lambda: list_late_loans(start_date.get(), end_date.get(), dr_root)).grid(
        row=3, column=0, columnspan=2, pady=10, ipadx=50
    )


def list_late_loans(start_date, end_date, window):
    conn = sqlite3.connect("LMS.db")
    cursor = conn.cursor()

    try:
        cursor.execute("""
            SELECT Book_Id, Branch_Id, Card_No, Due_Date, Returned_date,
                   JULIANDAY(Returned_date) - JULIANDAY(Due_Date) AS Days_Late
            FROM BOOK_LOANS
            WHERE Returned_date > Due_Date AND Due_Date BETWEEN ? AND ?
        """, (start_date, end_date))

        records = cursor.fetchall()

        result = "Book_Id | Branch_Id | Card_No | Days Late\n"
        result += "\n".join([f"{r[0]}        | {r[1]}        | {r[2]}     | {int(r[5])}" for r in records])
        Label(window, text=result).grid(row=4, column=0, columnspan=2)
    except Exception as e:
        Label(window, text=f"Error: {e}").grid(row=4, column=0, columnspan=2)

    conn.close()


# Requirement 6a: Borrower Late Fees View
def late_fees_window():
    lf_root = Toplevel()
    lf_root.title("Borrower Late Fees")
    lf_root.geometry("500x400")

    Label(lf_root, text="Search Borrower by ID, Name, or Leave Blank:").grid(row=0, column=0, columnspan=2)

    Label(lf_root, text="Borrower ID:").grid(row=1, column=0)
    Label(lf_root, text="Borrower Name:").grid(row=2, column=0)

    borrower_id = Entry(lf_root, width=30)
    borrower_id.grid(row=1, column=1)
    borrower_name = Entry(lf_root, width=30)
    borrower_name.grid(row=2, column=1)

    Button(lf_root, text="Search", command=lambda: show_late_fees(borrower_id.get(), borrower_name.get(), lf_root)).grid(
        row=3, column=0, columnspan=2, pady=10, ipadx=50
    )


def show_late_fees(borrower_id, borrower_name, window):
    conn = sqlite3.connect("LMS.db")
    cursor = conn.cursor()

    query = """
        SELECT BORROWER.Card_No, BORROWER.Name,
               COALESCE(SUM(JULIANDAY(BOOK_LOANS.Returned_date) - JULIANDAY(BOOK_LOANS.Due_Date)) * 0.5, 0) AS LateFee
        FROM BORROWER
        LEFT JOIN BOOK_LOANS ON BORROWER.Card_No = BOOK_LOANS.Card_No
        WHERE (? = '' OR BORROWER.Card_No = ?) AND (? = '' OR BORROWER.Name LIKE ?)
        GROUP BY BORROWER.Card_No, BORROWER.Name
        ORDER BY LateFee DESC;
    """

    cursor.execute(query, (borrower_id, borrower_id, borrower_name, f"%{borrower_name}%"))
    records = cursor.fetchall()

    result = "Card_No | Name     | LateFee\n"
    result += "\n".join([f"{r[0]}      | {r[1]} | ${r[2]:.2f}" for r in records])
    Label(window, text=result).grid(row=4, column=0, columnspan=2)

    conn.close()


# Requirement 6b: Book Information View
def book_info_window():
    bi_root = Toplevel()
    bi_root.title("Book Information")
    bi_root.geometry("500x400")

    Label(bi_root, text="Search Book by Borrower ID or Other Filters:").grid(row=0, column=0, columnspan=2)

    Label(bi_root, text="Borrower ID:").grid(row=1, column=0)
    Label(bi_root, text="Book ID:").grid(row=2, column=0)
    Label(bi_root, text="Book Title:").grid(row=3, column=0)

    borrower_id = Entry(bi_root, width=30)
    borrower_id.grid(row=1, column=1)
    book_id = Entry(bi_root, width=30)
    book_id.grid(row=2, column=1)
    book_title = Entry(bi_root, width=30)
    book_title.grid(row=3, column=1)

    Button(bi_root, text="Search", command=lambda: show_book_info(borrower_id.get(), book_id.get(), book_title.get(), bi_root)).grid(
        row=4, column=0, columnspan=2, pady=10, ipadx=50
    )


def show_book_info(borrower_id, book_id, book_title, window):
    conn = sqlite3.connect("LMS.db")
    cursor = conn.cursor()

    query = """
            SELECT DISTINCT BOOK.Book_Id, BOOK.Title,
                CASE
                    WHEN JULIANDAY(MAX(BOOK_LOANS.Returned_date)) - JULIANDAY(MAX(BOOK_LOANS.Due_Date)) > 0
                    THEN '$' || printf('%.2f', (JULIANDAY(MAX(BOOK_LOANS.Returned_date)) - JULIANDAY(MAX(BOOK_LOANS.Due_Date))) * 0.5)
                    ELSE 'Non-Applicable'
                END AS LateFee
            FROM BOOK
            LEFT JOIN BOOK_LOANS ON BOOK.Book_Id = BOOK_LOANS.Book_Id
            WHERE (? = '' OR BOOK_LOANS.Card_No = ?) AND (? = '' OR BOOK.Book_Id = ?) AND (? = '' OR BOOK.Title LIKE ?)
            GROUP BY BOOK.Book_Id, BOOK.Title
            ORDER BY LateFee DESC;
    """

    cursor.execute(query, (borrower_id, borrower_id, book_id, book_id, book_title, f"%{book_title}%"))
    records = cursor.fetchall()

    result = "Book_Id | Title       | LateFee\n"
    result += "\n".join([f"{r[0]}      | {r[1]} | {r[2]}" for r in records])
    Label(window, text=result).grid(row=5, column=0, columnspan=2)

    conn.close()
    
# Main GUI
def setup_gui():
    root = Tk()
    root.title("Library Management System")
    root.geometry("400x400")

    Button(root, text="Check Out Book", command=check_out_window).pack(pady=10)
    Button(root, text="Add New Borrower", command=new_borrower_window).pack(pady=10)
    Button(root, text="Add New Book", command=new_book_window).pack(pady=10)
    Button(root, text="Loaned Copies Per Branch", command=loaned_copies_window).pack(pady=10)
    Button(root, text="List Late Book Loans", command=date_range_window).pack(pady=10)
    Button(root, text="Borrower Late Fees", command=late_fees_window).pack(pady=10)
    Button(root, text="Book Information", command=book_info_window).pack(pady=10)

    root.mainloop()


setup_gui()