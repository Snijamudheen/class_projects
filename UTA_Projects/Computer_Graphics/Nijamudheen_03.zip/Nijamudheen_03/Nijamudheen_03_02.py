# Nijamudheen, Shaheen
# 1002_101_057
# 2024_10_20
# Assignment_03_02

import tkinter as tk
from tkinter import Toplevel, filedialog
from tkinter import messagebox

class cl_widgets:
    def __init__(self, ob_root_window, ob_world=[]):
        self.ob_root_window = ob_root_window
        self.ob_world = ob_world
        self.toolbar = cl_toolbar(self)
        self.rotate_bar = cl_buttons_panel_01(self)
        self.scale_bar = cl_buttons_panel_02(self)
        self.translate_bar = cl_buttons_panel_03(self)
        self.fly_bar = fly_panel(self)
        self.ob_canvas_frame = tk.Frame(ob_root_window)
        self.statusBar_frame = cl_statusBar_frame(self.ob_root_window)
        self.statusBar_frame.pack(side=tk.BOTTOM, fill=tk.X)
        self.statusBar_frame.set('%s', 'This is the status bar')
        self.cameras = []
        temp = []
        self.lines = []
        self.flg = 0

        filename = "cameras.txt"
        with open(filename) as textFile:
            lines = [line.split() for line in textFile]
        list = [x for x in lines if x != []]
        lines = list

        for elements in lines:
            if elements[0] == 'c':
                self.cameras.append(temp)
                temp = []
            temp.append(elements)
        self.cameras.append(temp)

        del self.cameras[0]

        self.ob_canvas_frame = cl_canvas_frame(self)
        self.ob_world.add_canvas(self.ob_canvas_frame.canvas)
        self.ob_world.add_cameras(self.cameras, self.ob_canvas_frame.canvas)

class cl_canvas_frame:
    def __init__(self, master):
        self.master = master
        self.canvas = tk.Canvas(master.ob_root_window, width=640, height=480, bg="yellow")
        self.canvas.pack(expand=tk.YES, fill=tk.BOTH)
        self.canvas.bind('<Configure>', self.canvas_resized_callback)

    def canvas_resized_callback(self, event):
        self.canvas.config(width=event.width - 4, height=event.height - 4)
        self.master.statusBar_frame.pack(side=tk.BOTTOM, fill=tk.X)
        self.master.statusBar_frame.set('%s', 'Canvas width = ' + str(self.canvas.cget("width")) +
                                        '   Canvas height = ' + str(self.canvas.cget("height")))
        self.canvas.pack()
        self.master.ob_world.refresh_display(self.master.ob_canvas_frame.canvas, event)

class cl_buttons_panel_01:
    def __init__(self, master):
        self.point1 = tk.StringVar()
        self.point1.set('[0.0,0.0,0.0]')
        self.point2 = tk.StringVar()
        self.point2.set('[1.0,1.0,1.0]')
        self.degree = tk.StringVar()
        self.degree.set('90')
        self.steps = tk.StringVar()
        self.steps.set('5')
        self.axis = tk.StringVar(value="Z")

        self.master = master
        self.rotate = tk.Frame(master.ob_root_window)

        # Axis selection (X, Y, Z, Line AB)
        self.axis_frame = tk.Frame(self.rotate)
        tk.Label(self.axis_frame, text="Rotation Axis:").pack(side=tk.LEFT)
        tk.Radiobutton(self.axis_frame, text="X", variable=self.axis, value="X").pack(side=tk.LEFT)
        tk.Radiobutton(self.axis_frame, text="Y", variable=self.axis, value="Y").pack(side=tk.LEFT)
        tk.Radiobutton(self.axis_frame, text="Z", variable=self.axis, value="Z").pack(side=tk.LEFT)
        tk.Radiobutton(self.axis_frame, text="Line AB", variable=self.axis, value="AB").pack(side=tk.LEFT)
        self.axis_frame.pack(side=tk.LEFT)

        # Points A and B input
        tk.Label(self.rotate, text="A:").pack(side=tk.LEFT)
        tk.Entry(self.rotate, textvariable=self.point1, width=15).pack(side=tk.LEFT)

        tk.Label(self.rotate, text="B:").pack(side=tk.LEFT)
        tk.Entry(self.rotate, textvariable=self.point2, width=15).pack(side=tk.LEFT)

        # Degree input with Spinbox
        tk.Label(self.rotate, text="Degree:").pack(side=tk.LEFT)
        tk.Spinbox(self.rotate, from_=0, to=360, textvariable=self.degree, width=5).pack(side=tk.LEFT)

        # Steps input with Spinbox
        tk.Label(self.rotate, text="Steps:").pack(side=tk.LEFT)
        tk.Spinbox(self.rotate, from_=1, to=100, textvariable=self.steps, width=5).pack(side=tk.LEFT)

        # Rotate button
        self.button = tk.Button(self.rotate, text="Rotate", width=8, command=self.rotation, fg="blue")
        self.button.pack(side=tk.LEFT, padx=2, pady=2)

        self.rotate.pack(side=tk.TOP, fill=tk.X)

    def rotation(self):
        angle = float(self.degree.get())
        steps = int(self.steps.get())

        # Remove the brackets and split the string by commas
        self.pointA = self.point1.get().strip("[]").split(',')
        self.pointB = self.point2.get().strip("[]").split(',')

        # Convert string values to floats
        A = [float(coord) for coord in self.pointA]
        B = [float(coord) for coord in self.pointB]

        # Get selected axis
        selected_axis = self.axis.get()

        # Print the details when the Rotate button is clicked
        print(f"Rotation button clicked!")
        print(f"Rotation Axis: {selected_axis}")
        print(f"Point A: {A}")
        print(f"Point B: {B}")
        print(f"Rotation Angle: {angle}")
        print(f"Steps: {steps}\n")

        # Assuming apply_rotation_ui method processes the rotation
        if self.master.flg > 0:
            self.master.ob_world.apply_rotation_ui(selected_axis, A, B, angle, steps, self.master.ob_canvas_frame.canvas)
            self.master.flg = 1

class cl_buttons_panel_02:
    def __init__(self, master):
        self.scale_type = tk.StringVar(value="All")
        self.scale_factor = tk.DoubleVar()
        self.scale_factor.set(1.25)
        self.sx_sy_sz = tk.StringVar()
        self.sx_sy_sz.set('[1,1,1]')
        self.ref_point = tk.StringVar()
        self.ref_point.set('[0.0,0.0,0.0]')
        self.steps = tk.StringVar()
        self.steps.set('4')

        self.master = master
        self.scale = tk.Frame(master.ob_root_window)

        # Scale ratio selection
        self.scale_type_frame = tk.Frame(self.scale)
        tk.Label(self.scale_type_frame, text="Scale Ratio:").pack(side=tk.LEFT)
        tk.Radiobutton(self.scale_type_frame, text="All", variable=self.scale_type, value="All").pack(side=tk.LEFT)

        # Spinbox for "All" scale factor
        tk.Spinbox(self.scale_type_frame, from_=0.1, to=10.0, increment=0.1, textvariable=self.scale_factor, width=5).pack(side=tk.LEFT)

        tk.Radiobutton(self.scale_type_frame, text="[Sx,Sy,Sz]", variable=self.scale_type, value="SxSySz").pack(side=tk.LEFT)
        tk.Entry(self.scale_type_frame, textvariable=self.sx_sy_sz, width=10).pack(side=tk.LEFT)
        self.scale_type_frame.pack(side=tk.LEFT)

        # Reference point input
        tk.Label(self.scale, text="Ref. Point:").pack(side=tk.LEFT)
        tk.Entry(self.scale, textvariable=self.ref_point, width=12).pack(side=tk.LEFT)

        # Steps input with Spinbox
        tk.Label(self.scale, text="Steps:").pack(side=tk.LEFT)
        tk.Spinbox(self.scale, from_=1, to=100, textvariable=self.steps, width=5).pack(side=tk.LEFT)

        # Scale button
        self.button = tk.Button(self.scale, text="Scale", width=8, command=self.scaling, fg="blue")
        self.button.pack(side=tk.LEFT, padx=2, pady=2)

        self.scale.pack(side=tk.TOP, fill=tk.X)

    def scaling(self):
        # Extract values from the input fields
        ref_point = [float(coord) for coord in self.ref_point.get().strip("[]").split(',')]
        steps = int(self.steps.get())

        # Get selected scale type and corresponding factors
        if self.scale_type.get() == "All":
            scale_factors = [float(self.scale_factor.get())] * 3
        else:
            scale_factors = [float(coord) for coord in self.sx_sy_sz.get().strip("[]").split(',')]

        # Print the details when the Scale button is clicked
        print(f"Scale button clicked!")
        print(f"Scale Type: {self.scale_type.get()}")
        print(f"Scale Factors: {scale_factors}")
        print(f"Reference Point: {ref_point}")
        print(f"Steps: {steps}\n")

        # Assuming master.ob_world.scaling applies the scaling operation
        if self.master.flg > 0:
            self.master.ob_world.scaling(scale_factors, ref_point, steps, self.master.ob_canvas_frame.canvas)
            self.master.flg = 1

class cl_buttons_panel_03:
    def __init__(self, master):
        self.master = master

        # Main Frame for translation widget
        self.translation = tk.Frame(master.ob_root_window)

        # Label for Translation (dx, dy, dz)
        self.heading = tk.Label(self.translation, text="Translation ([dx, dy, dz]): ")
        self.heading.pack(side=tk.LEFT)

        # Entry box for input
        self.points = tk.StringVar()
        self.points.set('[1,1,1]')
        self.entry = tk.Entry(self.translation, textvariable=self.points, width=10)
        self.entry.pack(side=tk.LEFT)

        # Label and Step Entry
        self.steps_label = tk.Label(self.translation, text="Steps")
        self.steps_label.pack(side=tk.LEFT)

        self.steps = tk.IntVar()
        self.steps.set(2)
        self.steps_entry = tk.Spinbox(self.translation, from_=1, to=100, textvariable=self.steps, width=3)
        self.steps_entry.pack(side=tk.LEFT)

        # Translate Button
        self.button = tk.Button(self.translation, text="Translate", width=8, command=self.translate, fg="blue")
        self.button.pack(side=tk.LEFT, padx=2)

        # Pack the translation frame
        self.translation.pack(side=tk.TOP, fill=tk.X)

    def translate(self):
        # Split and convert points input into float values
        self.translatePoints = self.points.get().strip('[]').split(',')
        Dx = float(self.translatePoints[0])
        Dy = float(self.translatePoints[1])
        Dz = float(self.translatePoints[2])

        # Get the number of steps from the spinbox (self.steps_entry)
        steps = self.steps.get()

        # Print the details when the Translate button is clicked
        print(f"Translate button clicked!")
        print(f"Translation: [{Dx}, {Dy}, {Dz}]")
        print(f"Steps: {steps}\n")

        if self.master.flg > 0:
            # Pass translation points and steps to the translation method
            self.master.ob_world.translation([Dx, Dy, Dz], steps, self.master.ob_canvas_frame.canvas)

class cl_statusBar_frame(tk.Frame):
    def __init__(self, master):
        tk.Frame.__init__(self, master)
        self.label = tk.Label(self, bd=1, relief=tk.SUNKEN, anchor=tk.W)
        self.label.pack(fill=tk.X)

    def set(self, format, *args):
        self.label.config(text=format % args)
        self.label.update_idletasks()

class cl_toolbar:
    def __init__(self, master):
        self.var_filename = tk.StringVar()
        self.var_filename.set('')
        self.lines = []
        self.master = master
        self.toolbar = tk.Frame(master.ob_root_window)

        # Filename label
        self.filename_label = tk.Label(self.toolbar, text="Filename:")
        self.filename_label.pack(side=tk.LEFT, padx=2)

        # Filename entry box
        self.filename_entry = tk.Entry(self.toolbar, textvariable=self.var_filename, width=40)
        self.filename_entry.pack(side=tk.LEFT, padx=2)

        # Browse button in blue font
        self.browse_button = tk.Button(self.toolbar, text="Browse", width=8, command=self.browse_file, fg="blue")
        self.browse_button.pack(side=tk.LEFT, padx=2)

        # Load button in red font
        self.load_button = tk.Button(self.toolbar, text="Load", width=8, command=self.toolbar_draw_callback, fg="red")
        self.load_button.pack(side=tk.LEFT, padx=2)

        self.toolbar.pack(side=tk.TOP, fill=tk.X)

    def toolbar_draw_callback(self):
        if self.lines:
            if self.master.flg > 0:
                self.master.ob_canvas_frame.canvas.delete("all")
            self.master.ob_world.create_graphic_objects(self.master.ob_canvas_frame.canvas, self.lines)
            self.master.flg = 1
        else:
            messagebox.showerror("Error", "No File Loaded")

    def browse_file(self):
        lines = []
        self.var_filename.set(filedialog.askopenfilename(filetypes=[("allfiles", "*"), ("pythonfiles", "*.txt")]))
        filename = self.var_filename.get()
        with open(filename) as textFile:
            lines = [line.split() for line in textFile]
        list = [x for x in lines if x != []]
        lines = list
        self.master.toolbar.lines = lines
        self.master.statusBar_frame.set('%s', "File Loaded")

class cl_canvas_frame:
    def __init__(self, master):
        self.master = master
        self.canvas = tk.Canvas(master.ob_root_window, width=640, height=480, bg="yellow")
        self.canvas.pack(expand=tk.YES, fill=tk.BOTH)
        self.canvas.bind('<Configure>', self.canvas_resized_callback)

    def canvas_resized_callback(self, event):
        self.canvas.config(width=event.width - 4, height=event.height - 4)
        
        # Update canvas dimensions
        canvas_width = self.canvas.cget("width")
        canvas_height = self.canvas.cget("height")
        
        # Retrieve the viewport dimensions from the world object
        viewport = self.master.ob_world.viewport
        viewport_xmin, viewport_ymin, viewport_xmax, viewport_ymax = viewport
        
        # Calculate the 2D viewport dimensions in pixels
        viewport_width = (viewport_xmax - viewport_xmin) * float(canvas_width)
        viewport_height = (viewport_ymax - viewport_ymin) * float(canvas_height)
        
        # Set the status bar text to include both canvas size and 2D viewport dimensions
        self.master.statusBar_frame.set('%s',
            f"Canvas width = {canvas_width}   Canvas height = {canvas_height}   "
            f"Viewport width = {viewport_width:.2f} px   Viewport height = {viewport_height:.2f} px"
        )
        
        self.canvas.pack()
        self.master.ob_world.refresh_display(self.master.ob_canvas_frame.canvas, event)

class fly_panel:
    def __init__(self, master):
        self.master = master
        self.points_a = tk.StringVar()
        self.points_b = tk.StringVar()
        self.steps = tk.StringVar()
        self.points_a.set('[0.0,0.0,0.0]')
        self.points_b.set('[1.0,1.0,1.0]')
        self.steps.set('10')

        # Dropdown options for camera view
        self.camera_option = tk.StringVar()
        self.camera_option.set("Parallel view")  # Default value

        # Fly Camera Button
        self.button = tk.Button(master.ob_root_window, text="Fly Camera...", command=self.open_fly_window, fg="blue")
        self.button.pack()

    def open_fly_window(self):
        # Create a new popup window for the Fly Camera options
        fly_window = Toplevel(self.master.ob_root_window)
        fly_window.title("Select Camera")

        # Adjust grid layout with padding and alignment
        fly_window.columnconfigure(0, pad=5)
        fly_window.columnconfigure(1, pad=5)
        fly_window.columnconfigure(2, pad=5)
        fly_window.columnconfigure(3, pad=5)
        fly_window.columnconfigure(4, pad=5)
        fly_window.columnconfigure(5, pad=5)

        # Select Camera to Fly label and dropdown
        camera_label = tk.Label(fly_window, text="Select Camera to Fly:")
        camera_label.grid(row=0, column=0, sticky='e')

        # Dropdown menu for selecting the camera view
        camera_menu = tk.OptionMenu(fly_window, self.camera_option, "Parallel view", "Perspective view")
        camera_menu.config(width=15)
        camera_menu.grid(row=0, column=1)

        # Current VRP ([x, y, z]) input
        vrp_label = tk.Label(fly_window, text="Current VRP([x,y,z]):")
        vrp_label.grid(row=0, column=2, sticky='e')

        vrp_entry = tk.Entry(fly_window, textvariable=self.points_a, width=15)
        vrp_entry.grid(row=0, column=3)

        # VRP 2 ([x, y, z]) input
        vrp2_label = tk.Label(fly_window, text="VRP 2([x,y,z]):")
        vrp2_label.grid(row=0, column=4, sticky='e')

        vrp2_entry = tk.Entry(fly_window, textvariable=self.points_b, width=15)
        vrp2_entry.grid(row=0, column=5)

        # Steps input
        steps_label = tk.Label(fly_window, text="Steps:")
        steps_label.grid(row=0, column=6, sticky='e')

        steps_entry = tk.Spinbox(fly_window, from_=1, to=100, textvariable=self.steps, width=5)
        steps_entry.grid(row=0, column=7)

        # Fly button to trigger camera fly
        fly_button = tk.Button(fly_window, text="Fly", command=self.fly, width=8, fg="blue")
        fly_button.grid(row=0, column=8, padx=10)

    def fly(self):
        # Parse the points and steps
        flyPoints_a = list(map(float, self.points_a.get().strip("[]").split(',')))
        flyPoints_b = list(map(float, self.points_b.get().strip("[]").split(',')))
        steps = int(self.steps.get())

        # Print the details when the Fly button is clicked
        print(f"Fly button clicked!")
        print(f"Camera View: {self.camera_option.get()}")
        print(f"VRP Point A: {flyPoints_a}")
        print(f"VRP Point B: {flyPoints_b}")
        print(f"Steps: {steps}\n")

        # Access ob_world and ob_canvas_frame via self.master
        self.master.ob_world.fly(self.master.ob_canvas_frame.canvas, flyPoints_a, flyPoints_b, steps)