# Nijamudheen, Shaheen
# 1002_101_057
# 2024_10_06
# Assignment_02_03

import time
import numpy as np
from math import radians, sin, cos

class cl_world:
    def __init__(self, objects=[], canvases=[], screen_width=0, screen_height=0):
        self.objects = objects
        self.canvases = canvases
        self.screen_width = screen_width
        self.screen_height = screen_height
        self.vertex_global_array = []
        self.global_triangle = []
        self.global_window = []
        self.global_view = []

    def add_canvas(self, canvas):
        self.canvases.append(canvas)
        canvas.world = self

    def translate(self, translation, steps=100, canvas=None):
        translation = np.array(translation, dtype=float) / steps
        for _ in range(steps):
            for i in range(1, len(self.vertex_global_array)):
                self.vertex_global_array[i] = np.add(self.vertex_global_array[i], translation).tolist()
            self.update_canvas_coordinates(canvas)
            canvas.update()
            time.sleep(0.05)

    def scale(self, scale_point, scale_ratio, steps=100, canvas=None):
        scale_ratio = np.array(scale_ratio, dtype=float)
        temp_scale_ratio = scale_ratio ** (1 / steps)

        for _ in range(steps):
            self.apply_scaling(scale_point, temp_scale_ratio, canvas)
            self.update_canvas_coordinates(canvas)
            canvas.update()
            time.sleep(0.05)

    def apply_scaling(self, scale_point, scale_ratio, canvas):
        translate_matrix = np.array([[1, 0, -scale_point[0]], [0, 1, -scale_point[1]], [0, 0, 1]], dtype=float)
        reverse_translate = np.array([[1, 0, scale_point[0]], [0, 1, scale_point[1]], [0, 0, 1]], dtype=float)
        scale_matrix = np.array([[scale_ratio[0], 0, 0], [0, scale_ratio[1], 0], [0, 0, 1]])

        for i in range(1, len(self.vertex_global_array)):
            vertex = np.append(self.vertex_global_array[i][:2], [1])
            scaled_vertex = np.dot(reverse_translate, np.dot(scale_matrix, np.dot(translate_matrix, vertex)))
            self.vertex_global_array[i] = scaled_vertex[:2].tolist()

    def rotation(self, canvas, A, B, steps, degree, axis="X"):
        degree_step = degree / steps

        if axis == "AB":
            for _ in range(steps):
                self.rotate_around_line_AB(A, B, degree_step)
                self.update_canvas_coordinates(canvas)
                canvas.update()
        else:
            for _ in range(steps):
                self.rotate_around_axis(axis, degree_step)
                self.update_canvas_coordinates(canvas)
                canvas.update()

    def rotate_around_axis(self, axis, degree_step):
        theta = radians(degree_step)
        rotation_matrix = {
            "X": np.array([[1, 0, 0], [0, cos(theta), -sin(theta)], [0, sin(theta), cos(theta)]]),
            "Y": np.array([[cos(theta), 0, sin(theta)], [0, 1, 0], [-sin(theta), 0, cos(theta)]]),
            "Z": np.array([[cos(theta), -sin(theta), 0], [sin(theta), cos(theta), 0], [0, 0, 1]])
        }[axis]

        for i in range(1, len(self.vertex_global_array)):
            point = np.array(self.vertex_global_array[i][:3])
            rotated_point = np.dot(rotation_matrix, point)
            self.vertex_global_array[i][:3] = rotated_point.tolist()

    def rotate_around_line_AB(self, A, B, degree_step):
        A, B = np.array(A), np.array(B)
        axis = B - A
        axis /= np.linalg.norm(axis)

        theta = radians(degree_step)
        K = np.array([[0, -axis[2], axis[1]], [axis[2], 0, -axis[0]], [-axis[1], axis[0], 0]])
        R = np.eye(3) + sin(theta) * K + (1 - cos(theta)) * np.dot(K, K)

        for i in range(1, len(self.vertex_global_array)):
            point = self.vertex_global_array[i][:3] - A
            rotated_point = np.dot(R, point) + A
            self.vertex_global_array[i][:3] = rotated_point.tolist()

    def update_canvas_coordinates(self, canvas):
        xwmin, xwmax = float(self.global_window[0]), float(self.global_window[2])
        ywmin, ywmax = float(self.global_window[1]), float(self.global_window[3])

        nxvmin, nxvmax = float(self.global_view[0]), float(self.global_view[2])
        nyvmin, nyvmax = float(self.global_view[1]), float(self.global_view[3])

        self.screen_width = int(canvas.cget("width"))
        self.screen_height = int(canvas.cget("height"))
        xvmin, xvmax = int(nxvmin * self.screen_width), int(nxvmax * self.screen_width)
        yvmin, yvmax = int(nyvmin * self.screen_height), int(nyvmax * self.screen_height)
        sx, sy = (xvmax - xvmin) / (xwmax - xwmin), (yvmax - yvmin) / (ywmax - ywmin)

        for i in range(len(self.global_triangle)):
            list_drawing = []
            for vertex_index in self.global_triangle[i]:
                temp_index = int(vertex_index)
                psx = xvmin + int(sx * (self.vertex_global_array[temp_index][0] - xwmin))
                psy = yvmin + int(sy * (ywmax - self.vertex_global_array[temp_index][1]))
                list_drawing.extend([psx, psy])
            canvas.coords(self.objects[i + 1], list_drawing)

    def draw_objects(self, canvas, filename):
        """
        Load vertices, triangles, window, and view data from the file and render them on the canvas.
        """
        canvas.delete("all")  # Clear canvas
        self.objects = []
        self.vertex_global_array = [[0, 0, 0]]  # Reset the vertex array
        self.global_triangle = []
        self.global_window = []
        self.global_view = []
        
        array_vertex = np.array([[0, 0, 0]], dtype=float)
        array_triangle = []
        array_window = []
        array_view = []
        
        # Open the file and read data
        with open(filename, "r") as file:
            for line in file:
                first_list = line.split()
                if len(first_list) == 0:
                    continue

                if first_list[0] == "v":  # Vertex data
                    temp_array = np.array([[float(first_list[1]), float(first_list[2]), float(first_list[3])]], dtype=float)
                    temp_array_global = [float(first_list[1]), float(first_list[2]), float(first_list[3])]
                    array_vertex = np.concatenate((array_vertex, temp_array))
                    self.vertex_global_array.append(temp_array_global)
                    
                elif first_list[0] == "f":  # Face data
                    temp_f = [int(idx) for idx in first_list[1:]]
                    array_triangle.append(temp_f)
                    self.global_triangle.append(temp_f)
                    
                elif first_list[0] == "w":  # Window data
                    array_window = [float(coord) for coord in first_list[1:]]
                    self.global_window = array_window
                    
                elif first_list[0] == "s":  # Viewport data
                    array_view = [float(coord) for coord in first_list[1:]]
                    self.global_view = array_view
        
        # Ensure that we have proper window and view data to compute scaling
        if not array_window or not array_view:
            print("Invalid window or viewport data.")
            return

        # Extract window and viewport coordinates
        xwmin, xwmax = array_window[0], array_window[2]
        ywmin, ywmax = array_window[1], array_window[3]
        
        nxvmin, nxvmax = array_view[0], array_view[2]
        nyvmin, nyvmax = array_view[1], array_view[3]

        # Compute actual viewport coordinates based on canvas dimensions
        self.screen_width = int(canvas.cget("width"))
        self.screen_height = int(canvas.cget("height"))
        
        xvmin = int(nxvmin * self.screen_width)
        xvmax = int(nxvmax * self.screen_width)
        yvmin = int(nyvmin * self.screen_height)
        yvmax = int(nyvmax * self.screen_height)

        # Scaling factors for transforming window to viewport
        sx = (xvmax - xvmin) / (xwmax - xwmin)
        sy = (yvmax - yvmin) / (ywmax - ywmin)

        # Create rectangle representing the viewport
        self.objects.append(canvas.create_rectangle(xvmin, yvmin, xvmax, yvmax, outline='black'))

        # Draw each face (triangle) on the canvas
        for i, triangle in enumerate(array_triangle):
            list_drawing = []
            for vertex_index in triangle:
                temp_index = int(vertex_index)
                psx = xvmin + int(sx * (array_vertex[temp_index][0] - xwmin))
                psy = yvmin + int(sy * (ywmax - array_vertex[temp_index][1]))  # Invert y-axis
                
                list_drawing.append(psx)
                list_drawing.append(psy)
            
            # Alternate colors for polygons based on index
            fill_color = 'red' if i % 2 == 0 else 'red'
            self.objects.append(canvas.create_polygon(list_drawing, outline='black', fill=fill_color, width=1))

    def display_objects_on_canvas(self, canvas, event):
        if self.objects:
            # ratio between previous canvas and current canvas
            ratio_width = float(event.width / self.screen_width)
            ratio_height = float(event.height / self.screen_height)
            # Loop through all objects
            for i in range(0, len(self.objects)):
                temp = canvas.coords(self.objects[i])
                # for the viewpoint
                if i == 0:
                    canvas.coords(self.objects[i], (temp[0] * ratio_width), (temp[1] * ratio_height),
                                (temp[2] * ratio_width), (temp[3] * ratio_height))
                # for 3 vertices of polygon object
                else:
                    canvas.coords(self.objects[i], (temp[0] * ratio_width), (temp[1] * ratio_height),
                                (temp[2] * ratio_width), (temp[3] * ratio_height),
                                (temp[4] * ratio_width), (temp[5] * ratio_height))
            self.screen_width = event.width
            self.screen_height = event.height

    def scale(self, scale_point, scale_ratio, steps=100, canvas=None):
        scale_ratio = np.array(scale_ratio, dtype=float)
        temp_scale_ratio = scale_ratio ** (1 / steps)

        for _ in range(steps):
            self.scaling(canvas, scale_point, temp_scale_ratio)
            self.update_canvas_coordinates(canvas)  # Redraw after each step
            canvas.update()
            time.sleep(0.05)  # Optional delay for visual effect

    def scaling(self, canvas, point, scale_ratio):
        # Check if global_window is populated; if not, set default values
        if not self.global_window:
            self.global_window = [0, 1, 0, 1]  # Default window values [xwmin, ywmin, xwmax, ywmax]

        # Check if global_view is populated; if not, set default values
        if not self.global_view:
            self.global_view = [0, 1, 0, 1]  # Default viewport values [nxvmin, nyvmin, nxvmax, nyvmax]

        # Measure increment
        xwmin = float(self.global_window[0])
        xwmax = float(self.global_window[2])
        ywmin = float(self.global_window[1])
        ywmax = float(self.global_window[3])

        # Define normalized viewport coordinates
        nxvmin = float(self.global_view[0])
        nxvmax = float(self.global_view[2])
        nyvmin = float(self.global_view[1])
        nyvmax = float(self.global_view[3])

        # Find actual viewport coordinates
        self.screen_width = int(canvas.cget("width"))
        self.screen_height = int(canvas.cget("height"))
        xvmin = int(nxvmin * self.screen_width)
        xvmax = int(nxvmax * self.screen_width)
        yvmin = int(nyvmin * self.screen_height)
        yvmax = int(nyvmax * self.screen_height)

        sx = (xvmax - xvmin) / (xwmax - xwmin)
        sy = (yvmax - yvmin) / (ywmax - ywmin)

        translate_matrix = np.array([[1, 0, -point[0]], [0, 1, -point[1]], [0, 0, 1]], dtype=float)
        translate_reverse = np.array([[1, 0, point[0]], [0, 1, point[1]], [0, 0, 1]], dtype=float)

        scale_ratio_matrix = np.array([[scale_ratio[0], 0, 0], [0, scale_ratio[1], 0], [0, 0, 1]])

        # Apply scaling
        for i in range(len(self.global_triangle)):
            list_drawing = []
            for j in range(len(self.global_triangle[i])):
                temp_index = int(self.global_triangle[i][j])
                temp_array = np.array([[self.vertex_global_array[temp_index][0]], [self.vertex_global_array[temp_index][1]], [1]], dtype=float)
                temp_points = translate_matrix.dot(temp_array)
                temp_scale = scale_ratio_matrix.dot(temp_points)
                final_point = translate_reverse.dot(temp_scale)

                psx = xvmin + int(sx * (float(final_point[0][0]) - xwmin))
                psy = yvmin + int(sy * (ywmax - float(final_point[1][0])))
                list_drawing.append(psx)
                list_drawing.append(psy)

            canvas.coords(self.objects[i + 1], list_drawing[0], list_drawing[1], list_drawing[2], list_drawing[3], list_drawing[4], list_drawing[5])

        # Update vertex global array
        for i in range(1, len(self.vertex_global_array)):
            vertex_current_array = np.array([[self.vertex_global_array[i][0]], [self.vertex_global_array[i][1]], [1]], dtype=float)
            vertex_translate = translate_matrix.dot(vertex_current_array)
            vertex_scale = scale_ratio_matrix.dot(vertex_translate)
            vertex_final = translate_reverse.dot(vertex_scale)
            self.vertex_global_array[i][0] = vertex_final[0][0]
            self.vertex_global_array[i][1] = vertex_final[1][0]

    def rotation(self, canvas, A, B, steps, degree, axis="X"):
        degree_step = float(degree / steps)

        if axis == "AB":
            # Rotate around line AB
            for i in range(steps):
                self.rotate_around_line_AB(canvas, A, B, degree_step)
                canvas.update()
        else:
            # Rotate around a specific axis (X, Y, or Z)
            for i in range(steps):
                self.rotate_around_axis(canvas, axis, degree_step)
                canvas.update()

    def rotate_around_axis(self, canvas, axis, degree_step):
        theta = radians(degree_step)  # Convert degrees to radians

        if axis == "X":
            # X-axis rotation matrix
            rotation_matrix = np.array([[1, 0, 0],
                                        [0, cos(theta), -sin(theta)],
                                        [0, sin(theta), cos(theta)]])
        elif axis == "Y":
            # Y-axis rotation matrix
            rotation_matrix = np.array([[cos(theta), 0, sin(theta)],
                                        [0, 1, 0],
                                        [-sin(theta), 0, cos(theta)]])
        elif axis == "Z":
            # Z-axis rotation matrix
            rotation_matrix = np.array([[cos(theta), -sin(theta), 0],
                                        [sin(theta), cos(theta), 0],
                                        [0, 0, 1]])

        # Apply the rotation matrix to each vertex
        for j in range(1, len(self.vertex_global_array)):
            point = np.array(self.vertex_global_array[j][:3], dtype=float)  # Take only the first 3 components
            rotated_point = rotation_matrix.dot(point)
            self.vertex_global_array[j][0] = rotated_point[0]
            self.vertex_global_array[j][1] = rotated_point[1]
            self.vertex_global_array[j][2] = rotated_point[2]

        # Recalculate canvas coordinates
        self.update_canvas_coordinates(canvas)

    def rotate_around_line_AB(self, canvas, A, B, degree):
        # Normalize the axis of rotation
        A = np.array(A)
        B = np.array(B)
        axis = B - A
        axis = axis / np.linalg.norm(axis)

        theta = radians(degree)

        # Rodrigues' rotation formula components
        K = np.array([[0, -axis[2], axis[1]],
                    [axis[2], 0, -axis[0]],
                    [-axis[1], axis[0], 0]])
        R = np.eye(3) + sin(theta) * K + (1 - cos(theta)) * np.dot(K, K)

        # Apply the rotation to each vertex
        for j in range(1, len(self.vertex_global_array)):
            point = np.array(self.vertex_global_array[j][:3], dtype=float)
            point = point - A  # Translate to origin
            rotated_point = np.dot(R, point) + A  # Apply rotation and translate back
            self.vertex_global_array[j][0] = rotated_point[0]
            self.vertex_global_array[j][1] = rotated_point[1]
            self.vertex_global_array[j][2] = rotated_point[2]

        self.update_canvas_coordinates(canvas)